USE hospitality_s2;

SELECT GuestName, Merit
FROM GUEST
WHERE Merit < (SELECT AVG(Merit) - 0.08 FROM GUEST)
ORDER BY Merit ASC, GuestID;
