USE hospitality_s2;

CREATE OR REPLACE VIEW GUEST_DETAIL (GuestID, GuestName, PackageID, ReviewScore) AS
SELECT g.GuestID, g.GuestName, r.PackageID, r.ReviewScore
FROM GUEST g
JOIN RESERVATION r ON r.GuestID = g.GuestID
WHERE g.HotelID = 'S2C';

SELECT GuestID, GuestName, PackageID, ReviewScore
FROM GUEST_DETAIL
ORDER BY PackageID, GuestID;
