USE hospitality_s2;

SELECT g.GuestID,
       g.GuestName,
       r.ReviewScore,
       CASE
           WHEN r.ReviewScore >= 88 THEN 'Excellent'
           WHEN r.ReviewScore >= 73 THEN 'Good'
           WHEN r.ReviewScore >= 58 THEN 'Fair'
           WHEN r.ReviewScore >= 43 THEN 'Basic'
           ELSE 'Followup'
       END AS Grade
FROM RESERVATION r
JOIN GUEST g ON g.GuestID = r.GuestID
WHERE r.PackageID = 'S203'
ORDER BY r.ReviewScore ASC, g.GuestID;
