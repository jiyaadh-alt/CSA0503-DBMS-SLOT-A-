USE hospitality_s2;

SELECT g.GuestName, g.HotelID, g.Merit
FROM GUEST g
WHERE g.Merit < (
    SELECT AVG(g2.Merit) - 0.04
    FROM GUEST g2
    WHERE g2.HotelID = g.HotelID
)
ORDER BY g.HotelID, g.GuestID;
