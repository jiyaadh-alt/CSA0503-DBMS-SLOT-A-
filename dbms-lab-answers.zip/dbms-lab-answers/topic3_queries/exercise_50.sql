USE hospitality_s2;

SELECT g.GuestName, SUM(p.NightUnits) AS TotalNightUnits
FROM GUEST g
JOIN RESERVATION r ON r.GuestID = g.GuestID
JOIN PACKAGE p ON p.PackageID = r.PackageID
GROUP BY g.GuestID, g.GuestName
HAVING SUM(p.NightUnits) > 5
ORDER BY TotalNightUnits DESC, g.GuestID;
