USE hospitality_s2;

SELECT p.Title, p.NightUnits, r.ReviewScore
FROM GUEST g
JOIN RESERVATION r ON r.GuestID = g.GuestID
JOIN PACKAGE p ON p.PackageID = r.PackageID
WHERE g.GuestID = 1203
ORDER BY r.ReviewScore ASC, p.PackageID;
