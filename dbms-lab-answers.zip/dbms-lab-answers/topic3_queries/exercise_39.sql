USE hospitality_s2;

SELECT p.PackageID,
       p.Title,
       COUNT(*) AS Guests,
       ROUND(AVG(r.ReviewScore), 2) AS AvgReviewScore
FROM PACKAGE p
JOIN RESERVATION r ON r.PackageID = p.PackageID
GROUP BY p.PackageID, p.Title
HAVING COUNT(*) >= 3
ORDER BY AvgReviewScore ASC, p.PackageID;
