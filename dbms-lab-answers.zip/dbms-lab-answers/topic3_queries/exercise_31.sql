USE hospitality_s2;

SELECT HotelID,
       COUNT(*) AS GuestCount,
       ROUND(AVG(Merit), 2) AS AvgMerit,
       MIN(Merit) AS MinMerit
FROM GUEST
GROUP BY HotelID
ORDER BY HotelID;
