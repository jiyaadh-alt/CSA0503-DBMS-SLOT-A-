USE hospitality_s2;

SELECT HotelID,
       GuestName,
       Merit,
       DENSE_RANK() OVER (PARTITION BY HotelID ORDER BY Merit ASC) AS UnitRank
FROM GUEST
ORDER BY HotelID, UnitRank, GuestID;
