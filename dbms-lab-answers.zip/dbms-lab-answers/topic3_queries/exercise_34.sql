USE hospitality_s2;

SELECT g.GuestName, h.HostName
FROM GUEST g
LEFT JOIN HOST h ON h.HostID = g.AssignedHost
WHERE h.HostID IS NULL
ORDER BY g.GuestID;
