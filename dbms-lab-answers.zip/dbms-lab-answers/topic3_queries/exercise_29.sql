USE hospitality_s2;

SELECT GuestID, GuestName, Merit
FROM GUEST
WHERE City = 'Hubballi'
  AND Merit >= 5.74
ORDER BY GuestName, GuestID;
