USE hospitality_s2;

SELECT g1.GuestID AS GuestID1,
       g1.GuestName AS GuestName1,
       g2.GuestID AS GuestID2,
       g2.GuestName AS GuestName2,
       g1.HotelID
FROM GUEST g1
JOIN GUEST g2 ON g2.HotelID = g1.HotelID AND g2.GuestID > g1.GuestID
WHERE g1.HotelID = 'S2C'
ORDER BY g1.GuestID, g2.GuestID;
