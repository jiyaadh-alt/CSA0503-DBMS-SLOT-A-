USE hospitality_s2;

SELECT h.HotelName, COUNT(o.HostID) AS HostCount
FROM HOTEL h
LEFT JOIN HOST o ON o.HotelID = h.HotelID
GROUP BY h.HotelID, h.HotelName
ORDER BY HostCount DESC, h.HotelName;
