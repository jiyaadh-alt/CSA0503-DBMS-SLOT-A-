USE hospitality_s2;

SELECT DISTINCT g.GuestID, g.GuestName
FROM GUEST g
WHERE g.GuestID IN (
    SELECT r.GuestID
    FROM RESERVATION r
    WHERE r.PackageID = 'S203'
)
ORDER BY g.GuestID DESC;
