USE hospitality_s2;

SELECT p.PackageID
FROM PACKAGE p
WHERE NOT EXISTS (
    SELECT 1
    FROM RESERVATION r
    JOIN GUEST g ON g.GuestID = r.GuestID
    WHERE r.PackageID = p.PackageID
      AND g.HotelID = 'S2C'
)
ORDER BY p.PackageID;
