USE hospitality_s2;

WITH scored AS (
    SELECT r.PackageID,
           g.GuestID,
           g.GuestName,
           r.ReviewScore,
           RANK() OVER (PARTITION BY r.PackageID ORDER BY r.ReviewScore ASC) AS score_rank
    FROM RESERVATION r
    JOIN GUEST g ON g.GuestID = r.GuestID
    WHERE r.ReviewScore IS NOT NULL
)
SELECT PackageID, GuestName, ReviewScore
FROM scored
WHERE score_rank = 1
ORDER BY PackageID, GuestID;
