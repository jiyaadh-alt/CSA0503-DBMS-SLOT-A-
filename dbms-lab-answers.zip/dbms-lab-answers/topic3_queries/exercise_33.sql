USE hospitality_s2;

SELECT g.GuestID, g.GuestName, h.HotelName
FROM GUEST g
JOIN HOTEL h ON h.HotelID = g.HotelID
WHERE g.HotelID = 'S2C'
ORDER BY g.GuestID DESC;
