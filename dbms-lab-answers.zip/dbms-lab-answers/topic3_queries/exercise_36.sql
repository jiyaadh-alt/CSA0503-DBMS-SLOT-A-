USE hospitality_s2;

SELECT u.PackageID, u.HostName
FROM (
    SELECT p.PackageID, NULL AS HostName
    FROM PACKAGE p
    LEFT JOIN HOST h ON h.HostID = p.HostID
    WHERE h.HostID IS NULL
    UNION
    SELECT NULL AS PackageID, h.HostName
    FROM HOST h
    LEFT JOIN PACKAGE p ON p.HostID = h.HostID
    WHERE p.PackageID IS NULL
) AS u
ORDER BY (u.PackageID IS NULL) DESC, u.PackageID;
