USE hospitality_s2;

SELECT HostName, Salary
FROM HOST
WHERE Salary < ALL (
    SELECT Salary
    FROM HOST
    WHERE HotelID = 'S2C'
      AND Grade = 'Lead Host'
)
ORDER BY Salary ASC, HostID;
