USE hospitality_s2;

SELECT h.HotelID, h.HostName, h.Salary
FROM HOST h
WHERE NOT EXISTS (
    SELECT 1
    FROM HOST h2
    WHERE h2.HotelID = h.HotelID
      AND h2.Salary < h.Salary
)
ORDER BY h.HotelID, h.HostID;
