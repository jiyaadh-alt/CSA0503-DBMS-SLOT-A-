USE hospitality_s2;

SELECT g.GuestName,
       g.HotelID AS GuestHotelID,
       p.PackageID,
       p.HotelID AS PackageHotelID
FROM GUEST g
JOIN PACKAGE p ON p.HotelID = g.HotelID
WHERE g.HotelID = 'S2C'
  AND EXISTS (
      SELECT 1
      FROM RESERVATION r
      WHERE r.GuestID = g.GuestID
        AND r.PackageID = p.PackageID
  )
ORDER BY g.GuestID, p.PackageID;
