USE hospitality_s2;

SELECT g.GuestName
FROM GUEST g
WHERE NOT EXISTS (
    SELECT 1
    FROM PACKAGE p
    WHERE p.HotelID = 'S2C'
      AND NOT EXISTS (
          SELECT 1
          FROM RESERVATION r
          WHERE r.GuestID = g.GuestID
            AND r.PackageID = p.PackageID
      )
)
ORDER BY g.GuestID;
