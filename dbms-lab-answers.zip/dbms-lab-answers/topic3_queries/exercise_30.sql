USE hospitality_s2;

SELECT GuestName, BirthDate
FROM GUEST
WHERE BirthDate >= '2005-01-01'
  AND BirthDate < '2006-01-01'
  AND GuestName NOT LIKE '%z'
ORDER BY BirthDate, GuestID;
