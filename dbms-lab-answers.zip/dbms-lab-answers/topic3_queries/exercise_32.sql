USE hospitality_s2;

SELECT HotelID, COUNT(*) AS GuestCount
FROM GUEST
GROUP BY HotelID
HAVING COUNT(*) >= 4
ORDER BY GuestCount DESC, HotelID;
