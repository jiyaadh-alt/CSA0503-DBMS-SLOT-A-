# Topic 3 explanation notes

## Exercise 35
`COUNT(*)` counts rows in the grouped result, not non-NULL host values. A hotel with no
hosts still produces one NULL-extended row from the `LEFT JOIN`, so `COUNT(*)` would
report 1 instead of 0. Counting the nullable key `o.HostID` (NULL on that row) correctly
returns 0 while preserving the empty hotel unit.

## Exercise 36
The two `LEFT JOIN`s keep only rows with no host match on the package side and no
package match on the host side — the two halves of a full outer join's symmetric
difference. A matched row has a non-NULL `h.HostID` in the first branch and a non-NULL
`p.PackageID` in the second, so both `IS NULL` filters reject it. Matched rows are
excluded because the exercise asks only for unmatched records; including them would
reconstruct the ordinary inner join instead of the outer-join leftover.

## Exercise 43
The outer `NOT EXISTS` keeps a guest only if there is no S2C package for which the
inner `NOT EXISTS` fails to find a reservation. If a new S2C package is added and a
guest has no link to it, the inner test becomes TRUE for that package, the outer
predicate becomes FALSE, and that guest disappears from the result. Adding an
unlinked package can therefore only shrink the answer, never enlarge it; a guest
returns only after being linked to every S2C package again (or the package is removed).

## Exercise 46
`< ALL` over an empty set is vacuously TRUE, so if hotel S2C has no `Lead Host` row,
every host satisfies the predicate and the query returns all hosts rather than none.
With a non-empty comparison set, a host must be paid less than the minimum Lead Host
salary.

## Exercise 47
`UNION` removes duplicate city values, so a city reported by both S2C and S2A (for
example Mysuru or Mangaluru) appears once. `UNION ALL` keeps every row from both
branches, so such shared cities would appear twice — once per hotel — and the result
would no longer be a set of distinct cities. It also skips the deduplication work.

## Exercise 50
`SUM` adds the `NightUnits` value of every joined reservation row separately. Repeated
unit values are each counted: two packages of 4 contribute 8, not 4. Nothing is
deduplicated, and guests with no reservations contribute nothing because the joins
produce no rows for them.

## Exercise 51
No. `GUEST_DETAIL` is based on a join of `GUEST` and `RESERVATION`, omits mandatory base
columns (`HotelID`, `Gender`, `Merit`), and filters on `HotelID = 'S2C'`. A row inserted
through the view cannot supply those NOT NULL columns or create the reservation row,
and there is no `WITH CHECK OPTION` enforcing the S2C predicate. MySQL treats this
multi-table join view as non-updatable; a complete new guest must be inserted into
`GUEST` (and any link into `RESERVATION`) directly.

## Exercise 52
Each row of `HOTEL_SUMMARY` summarizes many `GUEST` rows via `GROUP BY`, and `Guests`
and `AvgMerit` are computed values rather than stored columns. There is no unique,
reversible mapping from a summary row back to base rows, so MySQL rejects INSERT,
UPDATE and DELETE against the view; the underlying `HOTEL` and `GUEST` tables must be
changed instead.

## Exercise 53
`DENSE_RANK()` gives guests with equal `Merit` in the same hotel the same rank and does
not leave gaps afterwards: ranks go 1, 1, 2 rather than `RANK()`'s 1, 1, 3. The lowest
Merit always receives rank 1, and if several guests tie there, all of them share rank 1
instead of one being chosen arbitrarily.
