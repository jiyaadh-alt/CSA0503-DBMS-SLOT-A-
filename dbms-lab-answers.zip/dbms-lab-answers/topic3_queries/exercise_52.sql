USE hospitality_s2;

CREATE OR REPLACE VIEW HOTEL_SUMMARY (HotelName, Guests, AvgMerit) AS
SELECT h.HotelName, COUNT(g.GuestID) AS Guests, AVG(g.Merit) AS AvgMerit
FROM HOTEL h
LEFT JOIN GUEST g ON g.HotelID = h.HotelID
GROUP BY h.HotelID, h.HotelName;

SELECT HotelName, Guests, ROUND(AvgMerit, 2) AS AvgMerit
FROM HOTEL_SUMMARY
WHERE AvgMerit < 8.04
ORDER BY AvgMerit, HotelName;
