CREATE DATABASE IF NOT EXISTS hospitality_ex24;
USE hospitality_ex24;

DROP TABLE IF EXISTS SELECTED_GUEST;
DROP TABLE IF EXISTS GUEST;

CREATE TABLE GUEST (
    GuestID      INT           NOT NULL,
    GuestName    VARCHAR(45)   NOT NULL,
    HotelID      CHAR(4)       NOT NULL,
    Gender       CHAR(1)       NOT NULL,
    BirthDate    DATE          NULL,
    City         VARCHAR(30)   NULL,
    Merit        DECIMAL(4,2)  NOT NULL,
    AssignedHost INT           NULL,
    PRIMARY KEY (GuestID),
    CONSTRAINT ck_guest_gender CHECK (Gender IN ('M','F')),
    CONSTRAINT ck_guest_merit CHECK (Merit BETWEEN 0 AND 10)
) ENGINE = InnoDB;

INSERT INTO GUEST (GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost) VALUES
    (1201, 'Abeer',  'S2A', 'M', '2005-03-14', 'Mysuru',    8.66, 122),
    (1202, 'Bina',   'S2A', 'F', '2005-11-02', 'Mangaluru', 9.09, 122),
    (1203, 'Charan', 'S2A', 'M', '2004-07-23', 'Mysuru',    6.82, 123),
    (1204, 'Diya',   'S2B', 'F', '2005-01-30', 'Hubballi',  7.89, 222),
    (1205, 'Eshwar', 'S2B', 'M', '2004-09-17', 'Mysuru',    8.04, 222),
    (1206, 'Fara',   'S2C', 'F', '2005-05-05', 'Belagavi',  7.34, 322),
    (1207, 'Girish', 'S2C', 'M', '2004-12-25', 'Mangaluru', 5.89, 322),
    (1208, 'Hina',   'S2A', 'F', '2005-08-19', 'Hubballi',  9.42, 123),
    (1209, 'Inder',  'S2B', 'M', '2005-02-11', 'Belagavi',  6.19, NULL),
    (1210, 'Juhi',   'S2C', 'F', '2004-10-08', 'Mysuru',    7.99, NULL);

CREATE TABLE SELECTED_GUEST AS
SELECT GuestID, GuestName, Merit
FROM GUEST
WHERE Merit >= 8.99;

SELECT GuestID, GuestName, Merit
FROM SELECTED_GUEST
ORDER BY GuestID;

SHOW CREATE TABLE SELECTED_GUEST;

SHOW INDEX FROM SELECTED_GUEST;

SELECT COUNT(*) AS primary_key_count
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'hospitality_ex24'
  AND TABLE_NAME = 'SELECTED_GUEST'
  AND INDEX_NAME = 'PRIMARY';
