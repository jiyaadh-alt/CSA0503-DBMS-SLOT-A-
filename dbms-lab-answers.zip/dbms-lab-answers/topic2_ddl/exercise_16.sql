CREATE DATABASE IF NOT EXISTS hospitality_ex16;
USE hospitality_ex16;

DROP TABLE IF EXISTS RESERVATION;
DROP TABLE IF EXISTS PACKAGE;
DROP TABLE IF EXISTS GUEST;
DROP TABLE IF EXISTS HOST;
DROP TABLE IF EXISTS HOTEL;

CREATE TABLE HOTEL (
    HotelID   CHAR(4)      NOT NULL,
    HotelName VARCHAR(45)  NOT NULL,
    Block     CHAR(1)      NULL,
    HeadID    INT          NULL,
    PRIMARY KEY (HotelID),
    UNIQUE KEY uq_hotel_name (HotelName)
) ENGINE = InnoDB;

CREATE TABLE HOST (
    HostID   INT          NOT NULL,
    HostName VARCHAR(45)  NOT NULL,
    HotelID  CHAR(4)      NOT NULL,
    Grade    VARCHAR(20)  NOT NULL,
    Salary   INT          NOT NULL,
    JoinDate DATE         NULL,
    PRIMARY KEY (HostID),
    UNIQUE KEY uq_host_name (HostName),
    CONSTRAINT fk_host_hotel FOREIGN KEY (HotelID) REFERENCES HOTEL (HotelID),
    CONSTRAINT ck_host_salary CHECK (Salary > 0)
) ENGINE = InnoDB;

CREATE TABLE GUEST (
    GuestID      INT           NOT NULL,
    GuestName    VARCHAR(45)   NOT NULL,
    HotelID      CHAR(4)       NOT NULL,
    Gender       CHAR(1)       NOT NULL,
    BirthDate    DATE          NULL,
    City         VARCHAR(30)   NULL,
    Merit        DECIMAL(4,2)  NOT NULL,
    AssignedHost INT           NULL,
    PRIMARY KEY (GuestID),
    CONSTRAINT fk_guest_hotel FOREIGN KEY (HotelID) REFERENCES HOTEL (HotelID),
    CONSTRAINT fk_guest_host FOREIGN KEY (AssignedHost) REFERENCES HOST (HostID),
    CONSTRAINT ck_guest_gender CHECK (Gender IN ('M','F')),
    CONSTRAINT ck_guest_merit CHECK (Merit BETWEEN 0 AND 10)
) ENGINE = InnoDB;

CREATE TABLE PACKAGE (
    PackageID  CHAR(4)      NOT NULL,
    Title      VARCHAR(45)  NOT NULL,
    NightUnits TINYINT      NOT NULL,
    HotelID    CHAR(4)      NOT NULL,
    HostID     INT          NULL,
    PRIMARY KEY (PackageID),
    CONSTRAINT fk_package_hotel FOREIGN KEY (HotelID) REFERENCES HOTEL (HotelID),
    CONSTRAINT fk_package_host FOREIGN KEY (HostID) REFERENCES HOST (HostID),
    CONSTRAINT ck_package_nightunits CHECK (NightUnits BETWEEN 1 AND 5)
) ENGINE = InnoDB;

CREATE TABLE RESERVATION (
    GuestID     INT       NOT NULL,
    PackageID   CHAR(4)   NOT NULL,
    Term        INT       NULL,
    ReviewScore TINYINT   NULL,
    PRIMARY KEY (GuestID, PackageID),
    CONSTRAINT fk_res_guest FOREIGN KEY (GuestID) REFERENCES GUEST (GuestID),
    CONSTRAINT fk_res_package FOREIGN KEY (PackageID) REFERENCES PACKAGE (PackageID),
    CONSTRAINT ck_res_score CHECK (ReviewScore BETWEEN 0 AND 100)
) ENGINE = InnoDB;

INSERT INTO HOTEL (HotelID, HotelName, Block, HeadID) VALUES
    ('S2A', 'City Unit',    'A', 121),
    ('S2B', 'Resort Unit',  'B', 221),
    ('S2C', 'Airport Unit', 'C', 321),
    ('S2D', 'Heritage Unit','D', NULL);

INSERT INTO HOST (HostID, HostName, HotelID, Grade, Salary, JoinDate) VALUES
    (121, 'Ms. Nila',   'S2A', 'Lead Host',    187000, '2008-06-12'),
    (122, 'Mr. Ravi',   'S2A', 'Senior Host',  134000, '2014-07-01'),
    (123, 'Ms. Tara',   'S2A', 'Junior Host',   80000, '2021-01-18'),
    (221, 'Mr. Arun',   'S2B', 'Lead Host',    178000, '2010-08-09'),
    (222, 'Mr. Keshav', 'S2B', 'Junior Host',   74000, '2022-06-20'),
    (321, 'Ms. Rani',   'S2C', 'Lead Host',    170000, '2009-12-01'),
    (322, 'Mr. Sameer', 'S2C', 'Junior Host',   71000, '2023-02-15');

INSERT INTO GUEST (GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost) VALUES
    (1201, 'Abeer',  'S2A', 'M', '2005-03-14', 'Mysuru',    8.66, 122),
    (1202, 'Bina',   'S2A', 'F', '2005-11-02', 'Mangaluru', 9.09, 122),
    (1203, 'Charan', 'S2A', 'M', '2004-07-23', 'Mysuru',    6.82, 123),
    (1204, 'Diya',   'S2B', 'F', '2005-01-30', 'Hubballi',  7.89, 222),
    (1205, 'Eshwar', 'S2B', 'M', '2004-09-17', 'Mysuru',    8.04, 222),
    (1206, 'Fara',   'S2C', 'F', '2005-05-05', 'Belagavi',  7.34, 322),
    (1207, 'Girish', 'S2C', 'M', '2004-12-25', 'Mangaluru', 5.89, 322),
    (1208, 'Hina',   'S2A', 'F', '2005-08-19', 'Hubballi',  9.42, 123),
    (1209, 'Inder',  'S2B', 'M', '2005-02-11', 'Belagavi',  6.19, NULL),
    (1210, 'Juhi',   'S2C', 'F', '2004-10-08', 'Mysuru',    7.99, NULL);

INSERT INTO PACKAGE (PackageID, Title, NightUnits, HotelID, HostID) VALUES
    ('S201', 'City Break',    4, 'S2A', 122),
    ('S202', 'Business Stay', 4, 'S2A', 121),
    ('S203', 'Weekend Stay',  3, 'S2A', 123),
    ('S204', 'Beach Escape',  4, 'S2B', 221),
    ('S205', 'Spa Retreat',   3, 'S2B', 222),
    ('S206', 'Airport Stop',  4, 'S2C', 321),
    ('S207', 'Heritage Tour', 2, 'S2C', NULL);

INSERT INTO RESERVATION (GuestID, PackageID, Term, ReviewScore) VALUES
    (1201, 'S201', 3, 86), (1205, 'S205', 3, 64),
    (1201, 'S202', 3, 74), (1206, 'S206', 3, 72),
    (1201, 'S203', 3, 89), (1207, 'S206', 3, 37),
    (1202, 'S201', 3, 93), (1207, 'S207', 3, 53),
    (1202, 'S202', 3, 87), (1208, 'S201', 3, 96),
    (1203, 'S201', 3, 45), (1208, 'S202', 3, 92),
    (1203, 'S203', 3, 60), (1208, 'S203', 3, 95),
    (1204, 'S204', 3, 79), (1209, 'S204', 3, 47),
    (1204, 'S201', 3, 70), (1210, 'S206', 3, 81),
    (1205, 'S204', 3, 56), (1210, 'S203', 3, 77);

SELECT 'HOTEL' AS table_name, COUNT(*) AS row_count FROM HOTEL
UNION ALL SELECT 'HOST', COUNT(*) FROM HOST
UNION ALL SELECT 'GUEST', COUNT(*) FROM GUEST
UNION ALL SELECT 'PACKAGE', COUNT(*) FROM PACKAGE
UNION ALL SELECT 'RESERVATION', COUNT(*) FROM RESERVATION;
