CREATE DATABASE IF NOT EXISTS hospitality_ex27;
USE hospitality_ex27;

DROP TABLE IF EXISTS PAYMENT_RECEIPT;
DROP TABLE IF EXISTS GUEST;

CREATE TABLE GUEST (
    GuestID   INT          NOT NULL,
    GuestName VARCHAR(45)  NOT NULL,
    PRIMARY KEY (GuestID)
) ENGINE = InnoDB;

INSERT INTO GUEST (GuestID, GuestName) VALUES
    (1201, 'Abeer'),
    (1202, 'Bina'),
    (1203, 'Charan');

CREATE TABLE PAYMENT_RECEIPT (
    ReceiptNo INT            NOT NULL AUTO_INCREMENT,
    GuestID   INT            NOT NULL,
    Amount    DECIMAL(10,2)  NOT NULL,
    PRIMARY KEY (ReceiptNo),
    CONSTRAINT fk_receipt_guest FOREIGN KEY (GuestID) REFERENCES GUEST (GuestID)
) ENGINE = InnoDB AUTO_INCREMENT = 70221;

INSERT INTO PAYMENT_RECEIPT (GuestID, Amount) VALUES
    (1201, 1500.00),
    (1202, 2250.50),
    (1203, 980.00);

SELECT 'generated IDs for the three requested receipts' AS checkpoint,
       ReceiptNo, GuestID, Amount
FROM PAYMENT_RECEIPT
ORDER BY ReceiptNo;

START TRANSACTION;
INSERT INTO PAYMENT_RECEIPT (GuestID, Amount)
VALUES (1201, 10.00);
SELECT ROW_COUNT() AS rolled_back_insert_rows;
ROLLBACK;

SELECT AUTO_INCREMENT AS next_value_after_rollback
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'hospitality_ex27'
  AND TABLE_NAME = 'PAYMENT_RECEIPT';

INSERT INTO PAYMENT_RECEIPT (GuestID, Amount)
VALUES (1202, 75.00);

SELECT 'final receipts showing the auto-increment gap' AS checkpoint,
       ReceiptNo, GuestID, Amount
FROM PAYMENT_RECEIPT
ORDER BY ReceiptNo;
