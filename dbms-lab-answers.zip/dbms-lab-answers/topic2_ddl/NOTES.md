# Topic 2 answer script notes

Reload `sql/00_baseline.sql` before any script that begins with `USE hospitality_s2;`. Scripts that create tables use their own lab database so the shared baseline is not overwritten.

## 15

Builds HOTEL and HOST in `hospitality_ex15` with primary keys, unique names, a NOT NULL host name and grade, a positive-salary CHECK, and HOST.HotelID as a foreign key. DESCRIBE and SHOW CREATE TABLE expose the enforced structure.

## 16

Builds the complete five-table schema in `hospitality_ex16` with domain CHECKs, the composite RESERVATION key, all reference keys except HOTEL.HeadID, baseline data, and UNION ALL row counts.

## 17

Drops and re-adds `fk_hotel_head` with ALTER TABLE, then rolls back an update that supplies a nonexistent HeadID. Staged creation breaks the cycle: create HOTEL without the HeadID FK, create HOST with its HOTEL FK, load hosts, and only then add HOTEL.HeadID as an FK.

## 18

Runs four independent invalid inserts in transactions and rolls each one back. The reported violations are `ck_guest_merit`, `ck_package_nightunits`, `fk_res_package`, and `uq_hotel_name`. The baseline PackageID is CHAR(4), so the requested ZZ999 is passed through LEFT(...,4) as ZZ99 to test the FK instead of a length error.

## 19

Uses an isolated GUEST copy to add a nullable UNIQUE Phone, widen City, rename Merit to MeritValue, and drop Phone, with DESCRIBE and SHOW CREATE TABLE after each ALTER. UNIQUE indexes in MySQL permit multiple NULL values, so the existing NULL phones do not conflict.

## 20

Applies a 7% raise to Junior Hosts inside a transaction, reports `ROW_COUNT()` and rounded new salaries, then rolls back; three rows are updated.

## 21

Lists reservations with ReviewScore < 42, deletes them in a transaction, reports `ROW_COUNT()`, verifies zero remain, rolls back, and verifies the original low-score row is restored.

## 22

Uses EX22_HOST, EX22_GUEST, and EX22_RESERVATION copies with only the references needed for the experiment. Each of the three experiments drops and recreates the copies. RESTRICT rejects deleting host 123; SET NULL keeps both guests and their reservations while nulling AssignedHost; CASCADE removes guests 1203 and 1208 and their reservation rows.

## 23

Adds hotel NEW, inserts guests 1211 and 1212 in one INSERT statement, and uses INSERT SELECT to create both S203 reservations in term 6 with NULL ReviewScore.

## 24

Builds SELECTED_GUEST with CREATE TABLE AS SELECT for Merit >= 8.99. SHOW CREATE TABLE, SHOW INDEX, and the PRIMARY index count demonstrate that CTAS copies data and column definitions but not the primary key.

## 25

Creates `hospitality_auditor` with the clearly labeled placeholder password `LabPlaceholderOnly#2026`. GRANTs give SELECT on GUEST plus SELECT and column-level UPDATE on RESERVATION. SQL SECURITY DEFINER probe procedures execute with the auditor's privileges to show a score update succeeding, a DELETE failing, and the update failing after column-level UPDATE is revoked. Run with an account that can create users and DEFINER procedures. Replace the placeholder before any non-lab use.

## 26

Raises S201 scores with LEAST(100, ReviewScore + 5), sets a savepoint, deletes S207 reservations before their parent package, rolls back only those deletes, commits, and confirms S207 and its reservations remain.

## 27

Creates PAYMENT_RECEIPT with `ReceiptNo` auto-incrementing from 70221, inserts three receipts without IDs, and displays the generated values. A rolled-back insert consumes 70224 and the next insert receives 70225: MySQL does not reuse auto-increment values allocated to rolled-back statements.

## 28

Creates a BEFORE UPDATE trigger that raises SQLSTATE 45000 with a reservation-specific SIGNAL message when GuestID or PackageID changes. The attempted move from 1201 to 1206 on S202 is rejected, while a ReviewScore-only update succeeds.

## MySQL version caveats

Use MySQL 8.0.16 or later for enforced CHECK constraints; earlier 8.0 releases parse but ignore them. `RENAME COLUMN` and column-level privileges require MySQL 8.0 features. `DELIMITER` statements are mysql-client directives, so run these files with the mysql command-line client rather than a driver that executes statements one at a time. Exercise 25 may require SET_USER_ID or equivalent privilege to create procedures with a non-current DEFINER.
