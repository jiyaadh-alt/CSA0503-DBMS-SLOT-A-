USE hospitality_s2;

DROP PROCEDURE IF EXISTS ex25_retry_after_revoke;
DROP PROCEDURE IF EXISTS ex25_delete_probe;
DROP PROCEDURE IF EXISTS ex25_update_score;
DROP PROCEDURE IF EXISTS ex25_select_guest;
DROP USER IF EXISTS 'hospitality_auditor'@'localhost';

CREATE USER 'hospitality_auditor'@'localhost'
IDENTIFIED BY 'LabPlaceholderOnly#2026';

GRANT SELECT ON hospitality_s2.GUEST
TO 'hospitality_auditor'@'localhost';

GRANT SELECT, UPDATE (ReviewScore) ON hospitality_s2.RESERVATION
TO 'hospitality_auditor'@'localhost';

SHOW GRANTS FOR 'hospitality_auditor'@'localhost';

SELECT 'LabPlaceholderOnly#2026 is a lab placeholder, not a real secret' AS password_notice;

DELIMITER $$
CREATE DEFINER = 'hospitality_auditor'@'localhost'
PROCEDURE ex25_select_guest()
SQL SECURITY DEFINER
BEGIN
    SELECT COUNT(*) AS guest_rows_visible
    FROM hospitality_s2.GUEST;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'hospitality_auditor'@'localhost'
PROCEDURE ex25_update_score()
SQL SECURITY DEFINER
BEGIN
    START TRANSACTION;
    UPDATE hospitality_s2.RESERVATION
    SET ReviewScore = 85
    WHERE GuestID = 1201 AND PackageID = 'S201';
    SELECT 'ALLOWED before REVOKE' AS result, ROW_COUNT() AS changed_rows;
    SELECT ReviewScore AS score_during_probe
    FROM hospitality_s2.RESERVATION
    WHERE GuestID = 1201 AND PackageID = 'S201';
    ROLLBACK;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'hospitality_auditor'@'localhost'
PROCEDURE ex25_delete_probe()
SQL SECURITY DEFINER
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'DENIED' AS result,
               'DELETE privilege was not granted to hospitality_auditor' AS detail;
    END;

    START TRANSACTION;
    DELETE FROM hospitality_s2.RESERVATION
    WHERE GuestID = 1201 AND PackageID = 'S201';
    COMMIT;
    SELECT 'UNEXPECTED' AS result,
           'DELETE succeeded without DELETE privilege' AS detail;
END$$
DELIMITER ;

GRANT EXECUTE ON PROCEDURE hospitality_s2.ex25_select_guest TO 'hospitality_auditor'@'localhost';
GRANT EXECUTE ON PROCEDURE hospitality_s2.ex25_update_score TO 'hospitality_auditor'@'localhost';
GRANT EXECUTE ON PROCEDURE hospitality_s2.ex25_delete_probe TO 'hospitality_auditor'@'localhost';

CALL ex25_select_guest();
CALL ex25_update_score();
CALL ex25_delete_probe();

REVOKE UPDATE (ReviewScore) ON hospitality_s2.RESERVATION
FROM 'hospitality_auditor'@'localhost';

SHOW GRANTS FOR 'hospitality_auditor'@'localhost';

DELIMITER $$
CREATE PROCEDURE ex25_retry_after_revoke()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'DENIED after REVOKE UPDATE' AS result,
               'column-level UPDATE (ReviewScore) is no longer granted' AS detail;
    END;

    CALL ex25_update_score();
    SELECT 'UNEXPECTED' AS result,
           'update still allowed after REVOKE UPDATE' AS detail;
END$$
DELIMITER ;

CALL ex25_retry_after_revoke();

SELECT COUNT(*) AS reservation_rows_preserved
FROM hospitality_s2.RESERVATION;

DROP PROCEDURE IF EXISTS ex25_retry_after_revoke;
DROP PROCEDURE IF EXISTS ex25_delete_probe;
DROP PROCEDURE IF EXISTS ex25_update_score;
DROP PROCEDURE IF EXISTS ex25_select_guest;
