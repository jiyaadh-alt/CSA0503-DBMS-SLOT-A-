USE hospitality_s2;

DROP PROCEDURE IF EXISTS ex22_restrict;

SELECT 'EXPERIMENT 1: RESTRICT' AS experiment;

DROP TABLE IF EXISTS EX22_RESERVATION;
DROP TABLE IF EXISTS EX22_GUEST;
DROP TABLE IF EXISTS EX22_HOST;

CREATE TABLE EX22_HOST (
    HostID   INT          NOT NULL,
    HostName VARCHAR(45)  NOT NULL,
    HotelID  CHAR(4)      NOT NULL,
    Grade    VARCHAR(20)  NOT NULL,
    Salary   INT          NOT NULL,
    JoinDate DATE         NULL,
    PRIMARY KEY (HostID)
) ENGINE = InnoDB;

CREATE TABLE EX22_GUEST (
    GuestID      INT           NOT NULL,
    GuestName    VARCHAR(45)   NOT NULL,
    HotelID      CHAR(4)       NOT NULL,
    Gender       CHAR(1)       NOT NULL,
    BirthDate    DATE          NULL,
    City         VARCHAR(30)   NULL,
    Merit        DECIMAL(4,2)  NOT NULL,
    AssignedHost INT           NULL,
    PRIMARY KEY (GuestID),
    CONSTRAINT fk_ex22_guest_host FOREIGN KEY (AssignedHost)
        REFERENCES EX22_HOST (HostID) ON DELETE RESTRICT
) ENGINE = InnoDB;

CREATE TABLE EX22_RESERVATION (
    GuestID     INT       NOT NULL,
    PackageID   CHAR(4)   NOT NULL,
    Term        INT       NULL,
    ReviewScore TINYINT   NULL,
    PRIMARY KEY (GuestID, PackageID),
    CONSTRAINT fk_ex22_res_guest FOREIGN KEY (GuestID)
        REFERENCES EX22_GUEST (GuestID) ON DELETE CASCADE
) ENGINE = InnoDB;

INSERT INTO EX22_HOST (HostID, HostName, HotelID, Grade, Salary, JoinDate)
SELECT HostID, HostName, HotelID, Grade, Salary, JoinDate FROM HOST;

INSERT INTO EX22_GUEST (GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost)
SELECT GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost FROM GUEST;

INSERT INTO EX22_RESERVATION (GuestID, PackageID, Term, ReviewScore)
SELECT GuestID, PackageID, Term, ReviewScore FROM RESERVATION;

SELECT 'RESTRICT before delete' AS checkpoint,
       (SELECT COUNT(*) FROM EX22_HOST WHERE HostID = 123) AS host_123_rows,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE AssignedHost = 123) AS guest_rows_assigned_123,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE GuestID IN (1203, 1208)) AS tracked_guest_rows,
       (SELECT COUNT(*) FROM EX22_RESERVATION WHERE GuestID IN (1203, 1208)) AS tracked_reservation_rows;

DELIMITER $$
CREATE PROCEDURE ex22_restrict()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'REJECTED' AS result,
               'fk_ex22_guest_host' AS constraint_name,
               'RESTRICT kept HOST 123 because GUEST rows still reference it' AS detail;
    END;

    START TRANSACTION;
    DELETE FROM EX22_HOST WHERE HostID = 123;
    COMMIT;
    SELECT 'UNEXPECTED' AS result,
           'host delete succeeded under RESTRICT' AS detail;
END$$
DELIMITER ;

CALL ex22_restrict();

SELECT 'RESTRICT after delete attempt' AS checkpoint,
       (SELECT COUNT(*) FROM EX22_HOST WHERE HostID = 123) AS host_123_rows,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE AssignedHost = 123) AS guest_rows_assigned_123,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE GuestID IN (1203, 1208)) AS tracked_guest_rows,
       (SELECT COUNT(*) FROM EX22_RESERVATION WHERE GuestID IN (1203, 1208)) AS tracked_reservation_rows;

SELECT 'RESTRICT guest detail' AS checkpoint,
       GuestID, GuestName, AssignedHost
FROM EX22_GUEST
WHERE GuestID IN (1203, 1208)
ORDER BY GuestID;

SELECT 'EXPERIMENT 2: SET NULL' AS experiment;

DROP TABLE IF EXISTS EX22_RESERVATION;
DROP TABLE IF EXISTS EX22_GUEST;
DROP TABLE IF EXISTS EX22_HOST;

CREATE TABLE EX22_HOST (
    HostID   INT          NOT NULL,
    HostName VARCHAR(45)  NOT NULL,
    HotelID  CHAR(4)      NOT NULL,
    Grade    VARCHAR(20)  NOT NULL,
    Salary   INT          NOT NULL,
    JoinDate DATE         NULL,
    PRIMARY KEY (HostID)
) ENGINE = InnoDB;

CREATE TABLE EX22_GUEST (
    GuestID      INT           NOT NULL,
    GuestName    VARCHAR(45)   NOT NULL,
    HotelID      CHAR(4)       NOT NULL,
    Gender       CHAR(1)       NOT NULL,
    BirthDate    DATE          NULL,
    City         VARCHAR(30)   NULL,
    Merit        DECIMAL(4,2)  NOT NULL,
    AssignedHost INT           NULL,
    PRIMARY KEY (GuestID),
    CONSTRAINT fk_ex22_guest_host FOREIGN KEY (AssignedHost)
        REFERENCES EX22_HOST (HostID) ON DELETE SET NULL
) ENGINE = InnoDB;

CREATE TABLE EX22_RESERVATION (
    GuestID     INT       NOT NULL,
    PackageID   CHAR(4)   NOT NULL,
    Term        INT       NULL,
    ReviewScore TINYINT   NULL,
    PRIMARY KEY (GuestID, PackageID),
    CONSTRAINT fk_ex22_res_guest FOREIGN KEY (GuestID)
        REFERENCES EX22_GUEST (GuestID) ON DELETE CASCADE
) ENGINE = InnoDB;

INSERT INTO EX22_HOST (HostID, HostName, HotelID, Grade, Salary, JoinDate)
SELECT HostID, HostName, HotelID, Grade, Salary, JoinDate FROM HOST;

INSERT INTO EX22_GUEST (GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost)
SELECT GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost FROM GUEST;

INSERT INTO EX22_RESERVATION (GuestID, PackageID, Term, ReviewScore)
SELECT GuestID, PackageID, Term, ReviewScore FROM RESERVATION;

SELECT 'SET NULL before delete' AS checkpoint,
       (SELECT COUNT(*) FROM EX22_HOST WHERE HostID = 123) AS host_123_rows,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE AssignedHost = 123) AS guest_rows_assigned_123,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE GuestID IN (1203, 1208)) AS tracked_guest_rows,
       (SELECT COUNT(*) FROM EX22_RESERVATION WHERE GuestID IN (1203, 1208)) AS tracked_reservation_rows;

START TRANSACTION;
DELETE FROM EX22_HOST WHERE HostID = 123;
SELECT ROW_COUNT() AS host_rows_deleted;
COMMIT;

SELECT 'SET NULL after delete' AS checkpoint,
       (SELECT COUNT(*) FROM EX22_HOST WHERE HostID = 123) AS host_123_rows,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE AssignedHost = 123) AS guest_rows_assigned_123,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE GuestID IN (1203, 1208)) AS tracked_guest_rows,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE GuestID IN (1203, 1208) AND AssignedHost IS NULL) AS guests_set_to_null,
       (SELECT COUNT(*) FROM EX22_RESERVATION WHERE GuestID IN (1203, 1208)) AS tracked_reservation_rows;

SELECT 'SET NULL guest detail' AS checkpoint,
       GuestID, GuestName, AssignedHost
FROM EX22_GUEST
WHERE GuestID IN (1203, 1208)
ORDER BY GuestID;

SELECT 'EXPERIMENT 3: CASCADE' AS experiment;

DROP TABLE IF EXISTS EX22_RESERVATION;
DROP TABLE IF EXISTS EX22_GUEST;
DROP TABLE IF EXISTS EX22_HOST;

CREATE TABLE EX22_HOST (
    HostID   INT          NOT NULL,
    HostName VARCHAR(45)  NOT NULL,
    HotelID  CHAR(4)      NOT NULL,
    Grade    VARCHAR(20)  NOT NULL,
    Salary   INT          NOT NULL,
    JoinDate DATE         NULL,
    PRIMARY KEY (HostID)
) ENGINE = InnoDB;

CREATE TABLE EX22_GUEST (
    GuestID      INT           NOT NULL,
    GuestName    VARCHAR(45)   NOT NULL,
    HotelID      CHAR(4)       NOT NULL,
    Gender       CHAR(1)       NOT NULL,
    BirthDate    DATE          NULL,
    City         VARCHAR(30)   NULL,
    Merit        DECIMAL(4,2)  NOT NULL,
    AssignedHost INT           NULL,
    PRIMARY KEY (GuestID),
    CONSTRAINT fk_ex22_guest_host FOREIGN KEY (AssignedHost)
        REFERENCES EX22_HOST (HostID) ON DELETE CASCADE
) ENGINE = InnoDB;

CREATE TABLE EX22_RESERVATION (
    GuestID     INT       NOT NULL,
    PackageID   CHAR(4)   NOT NULL,
    Term        INT       NULL,
    ReviewScore TINYINT   NULL,
    PRIMARY KEY (GuestID, PackageID),
    CONSTRAINT fk_ex22_res_guest FOREIGN KEY (GuestID)
        REFERENCES EX22_GUEST (GuestID) ON DELETE CASCADE
) ENGINE = InnoDB;

INSERT INTO EX22_HOST (HostID, HostName, HotelID, Grade, Salary, JoinDate)
SELECT HostID, HostName, HotelID, Grade, Salary, JoinDate FROM HOST;

INSERT INTO EX22_GUEST (GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost)
SELECT GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost FROM GUEST;

INSERT INTO EX22_RESERVATION (GuestID, PackageID, Term, ReviewScore)
SELECT GuestID, PackageID, Term, ReviewScore FROM RESERVATION;

SELECT 'CASCADE before delete' AS checkpoint,
       (SELECT COUNT(*) FROM EX22_HOST WHERE HostID = 123) AS host_123_rows,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE AssignedHost = 123) AS guest_rows_assigned_123,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE GuestID IN (1203, 1208)) AS tracked_guest_rows,
       (SELECT COUNT(*) FROM EX22_RESERVATION WHERE GuestID IN (1203, 1208)) AS tracked_reservation_rows;

START TRANSACTION;
DELETE FROM EX22_HOST WHERE HostID = 123;
SELECT ROW_COUNT() AS host_rows_deleted;
COMMIT;

SELECT 'CASCADE after delete' AS checkpoint,
       (SELECT COUNT(*) FROM EX22_HOST WHERE HostID = 123) AS host_123_rows,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE AssignedHost = 123) AS guest_rows_assigned_123,
       (SELECT COUNT(*) FROM EX22_GUEST WHERE GuestID IN (1203, 1208)) AS tracked_guest_rows,
       (SELECT COUNT(*) FROM EX22_RESERVATION WHERE GuestID IN (1203, 1208)) AS tracked_reservation_rows;

SELECT 'CASCADE guest detail' AS checkpoint,
       GuestID, GuestName, AssignedHost
FROM EX22_GUEST
WHERE GuestID IN (1203, 1208)
ORDER BY GuestID;

SELECT 'CASCADE reservation detail' AS checkpoint,
       GuestID, PackageID, ReviewScore
FROM EX22_RESERVATION
WHERE GuestID IN (1203, 1208)
ORDER BY GuestID, PackageID;

DROP PROCEDURE IF EXISTS ex22_restrict;
