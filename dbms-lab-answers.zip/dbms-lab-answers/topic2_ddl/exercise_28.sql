USE hospitality_s2;

DROP PROCEDURE IF EXISTS ex28_rejected_update;
DROP TRIGGER IF EXISTS trg_reservation_immutable_id;

DELIMITER $$
CREATE TRIGGER trg_reservation_immutable_id
BEFORE UPDATE ON RESERVATION
FOR EACH ROW
BEGIN
    IF NEW.GuestID <> OLD.GuestID OR NEW.PackageID <> OLD.PackageID THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Reservation identity is immutable: create a new reservation for a different guest or package.';
    END IF;
END$$
DELIMITER ;

SELECT GuestID, PackageID, Term, ReviewScore
FROM RESERVATION
WHERE GuestID = 1201 AND PackageID = 'S202';

DELIMITER $$
CREATE PROCEDURE ex28_rejected_update()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'REJECTED' AS result,
               'Reservation identity is immutable: create a new reservation for a different guest or package.' AS signal_message;
    END;

    START TRANSACTION;
    UPDATE RESERVATION
    SET GuestID = 1206
    WHERE GuestID = 1201 AND PackageID = 'S202';
    COMMIT;
    SELECT 'UNEXPECTED' AS result,
           'identifier change was allowed' AS detail;
END$$
DELIMITER ;

CALL ex28_rejected_update();

SELECT 'after rejected identifier change' AS checkpoint,
       GuestID, PackageID, Term, ReviewScore
FROM RESERVATION
WHERE PackageID = 'S202' AND GuestID IN (1201, 1206)
ORDER BY GuestID;

UPDATE RESERVATION
SET ReviewScore = 76
WHERE GuestID = 1201 AND PackageID = 'S202';

SELECT 'after permitted score-only update' AS checkpoint,
       GuestID, PackageID, Term, ReviewScore
FROM RESERVATION
WHERE GuestID = 1201 AND PackageID = 'S202';

DROP PROCEDURE IF EXISTS ex28_rejected_update;
