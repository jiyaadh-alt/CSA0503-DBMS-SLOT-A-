USE hospitality_s2;

START TRANSACTION;

UPDATE HOST
SET Salary = ROUND(Salary * 1.07)
WHERE Grade = 'Junior Host';

SELECT ROW_COUNT() AS updated_rows;

SELECT HostID, HostName, ROUND(Salary, 2) AS NewSalary
FROM HOST
WHERE Grade = 'Junior Host'
ORDER BY HostID;

ROLLBACK;

SELECT HostID, HostName, Salary AS RestoredSalary
FROM HOST
WHERE Grade = 'Junior Host'
ORDER BY HostID;
