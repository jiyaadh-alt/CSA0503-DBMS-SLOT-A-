USE hospitality_s2;

START TRANSACTION;

UPDATE RESERVATION
SET ReviewScore = LEAST(100, ReviewScore + 5)
WHERE PackageID = 'S201';

SELECT ROW_COUNT() AS s201_scores_updated;

SAVEPOINT before_s207_delete;

DELETE FROM RESERVATION
WHERE PackageID = 'S207';

SELECT ROW_COUNT() AS s207_reservations_deleted;

DELETE FROM PACKAGE
WHERE PackageID = 'S207';

SELECT ROW_COUNT() AS s207_package_deleted;

SELECT 'deletes visible before savepoint rollback' AS checkpoint,
       (SELECT COUNT(*) FROM PACKAGE WHERE PackageID = 'S207') AS s207_packages,
       (SELECT COUNT(*) FROM RESERVATION WHERE PackageID = 'S207') AS s207_reservations;

ROLLBACK TO SAVEPOINT before_s207_delete;

COMMIT;

SELECT GuestID, ReviewScore AS S201Score
FROM RESERVATION
WHERE PackageID = 'S201'
ORDER BY GuestID;

SELECT PackageID, Title, NightUnits
FROM PACKAGE
WHERE PackageID = 'S207';

SELECT COUNT(*) AS s207_reservations_remaining
FROM RESERVATION
WHERE PackageID = 'S207';
