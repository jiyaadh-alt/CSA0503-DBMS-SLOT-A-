USE hospitality_s2;

SHOW CREATE TABLE HOTEL;

ALTER TABLE HOTEL DROP FOREIGN KEY fk_hotel_head;

ALTER TABLE HOTEL
    ADD CONSTRAINT fk_hotel_head FOREIGN KEY (HeadID) REFERENCES HOST (HostID);

SHOW CREATE TABLE HOTEL;

DROP PROCEDURE IF EXISTS ex17_nonexistent_head;

DELIMITER $$
CREATE PROCEDURE ex17_nonexistent_head()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'REJECTED' AS result,
               'fk_hotel_head' AS violated_constraint,
               'HeadID must match an existing HOST.HostID' AS detail;
    END;

    START TRANSACTION;
    UPDATE HOTEL SET HeadID = 99999 WHERE HotelID = 'S2D';
    COMMIT;
    SELECT 'UNEXPECTED' AS result,
           'nonexistent HeadID was accepted' AS detail;
END$$
DELIMITER ;

CALL ex17_nonexistent_head();

DROP PROCEDURE IF EXISTS ex17_nonexistent_head;

SELECT HotelID, HotelName, HeadID
FROM HOTEL
ORDER BY HotelID;
