USE hospitality_s2;

DELETE FROM RESERVATION
WHERE GuestID IN (1211, 1212) AND PackageID = 'S203';

DELETE FROM GUEST
WHERE GuestID IN (1211, 1212);

DELETE FROM HOTEL
WHERE HotelID = 'NEW';

INSERT INTO HOTEL (HotelID, HotelName, Block, HeadID)
VALUES ('NEW', 'Extension Unit', 'E', NULL);

INSERT INTO GUEST (GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost) VALUES
    (1211, 'Kiran', 'NEW', 'M', '1995-04-12', 'Mangaluru', 7.20, NULL),
    (1212, 'Leela', 'NEW', 'F', '1998-08-03', 'Belagavi',  8.30, NULL);

INSERT INTO RESERVATION (GuestID, PackageID, Term, ReviewScore)
SELECT GuestID, 'S203', 6, NULL
FROM GUEST
WHERE GuestID IN (1211, 1212)
ORDER BY GuestID;

SELECT HotelID, HotelName, Block, HeadID
FROM HOTEL
WHERE HotelID = 'NEW';

SELECT GuestID, GuestName, HotelID, Merit, AssignedHost
FROM GUEST
WHERE GuestID IN (1211, 1212)
ORDER BY GuestID;

SELECT GuestID, PackageID, Term, ReviewScore
FROM RESERVATION
WHERE GuestID IN (1211, 1212) AND PackageID = 'S203'
ORDER BY GuestID;
