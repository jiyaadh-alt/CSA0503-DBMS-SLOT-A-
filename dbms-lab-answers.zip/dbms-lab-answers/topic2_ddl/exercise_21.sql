USE hospitality_s2;

START TRANSACTION;

SELECT r.GuestID, g.GuestName, r.PackageID, r.ReviewScore
FROM RESERVATION AS r
JOIN GUEST AS g ON g.GuestID = r.GuestID
WHERE r.ReviewScore < 42
ORDER BY r.GuestID, r.PackageID;

DELETE FROM RESERVATION
WHERE ReviewScore < 42;

SELECT ROW_COUNT() AS deleted_rows;

SELECT COUNT(*) AS remaining_low_scores
FROM RESERVATION
WHERE ReviewScore < 42;

ROLLBACK;

SELECT COUNT(*) AS restored_low_scores
FROM RESERVATION
WHERE ReviewScore < 42;
