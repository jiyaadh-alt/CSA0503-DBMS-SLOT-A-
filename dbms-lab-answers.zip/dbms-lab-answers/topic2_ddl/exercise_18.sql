USE hospitality_s2;

SELECT 'baseline before invalid insert tests' AS checkpoint,
       (SELECT COUNT(*) FROM HOTEL) AS hotels,
       (SELECT COUNT(*) FROM HOST) AS hosts,
       (SELECT COUNT(*) FROM GUEST) AS guests,
       (SELECT COUNT(*) FROM PACKAGE) AS packages,
       (SELECT COUNT(*) FROM RESERVATION) AS reservations;

DROP PROCEDURE IF EXISTS ex18_merit;
DROP PROCEDURE IF EXISTS ex18_nightunits;
DROP PROCEDURE IF EXISTS ex18_package_fk;
DROP PROCEDURE IF EXISTS ex18_hotel_name;

DELIMITER $$
CREATE PROCEDURE ex18_merit()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'REJECTED' AS result, 'a' AS test_case,
               'ck_guest_merit' AS violated_constraint,
               'Merit must be between 0 and 10' AS detail;
    END;

    START TRANSACTION;
    INSERT INTO GUEST (GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost)
    VALUES (9901, 'Merit Test', 'S2A', 'M', '2000-01-01', 'Mysuru', 10.50, NULL);
    SELECT 'UNEXPECTED' AS result, 'a' AS test_case,
           'no constraint violation' AS violated_constraint;
    ROLLBACK;
END$$
DELIMITER ;

CALL ex18_merit();

DELIMITER $$
CREATE PROCEDURE ex18_nightunits()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'REJECTED' AS result, 'b' AS test_case,
               'ck_package_nightunits' AS violated_constraint,
               'NightUnits must be between 1 and 5' AS detail;
    END;

    START TRANSACTION;
    INSERT INTO PACKAGE (PackageID, Title, NightUnits, HotelID, HostID)
    VALUES ('Z901', 'Zero Night', 0, 'S2A', 122);
    SELECT 'UNEXPECTED' AS result, 'b' AS test_case,
           'no constraint violation' AS violated_constraint;
    ROLLBACK;
END$$
DELIMITER ;

CALL ex18_nightunits();

DELIMITER $$
CREATE PROCEDURE ex18_package_fk()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'REJECTED' AS result, 'c' AS test_case,
               'fk_res_package' AS violated_constraint,
               'requested PackageID ZZ999 is nonexistent; CHAR(4) stores ZZ99' AS detail;
    END;

    START TRANSACTION;
    INSERT INTO RESERVATION (GuestID, PackageID, Term, ReviewScore)
    SELECT 1201, LEFT('ZZ999', 4), 3, 50;
    SELECT 'UNEXPECTED' AS result, 'c' AS test_case,
           'no constraint violation' AS violated_constraint;
    ROLLBACK;
END$$
DELIMITER ;

CALL ex18_package_fk();

DELIMITER $$
CREATE PROCEDURE ex18_hotel_name()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'REJECTED' AS result, 'd' AS test_case,
               'uq_hotel_name' AS violated_constraint,
               'HotelName must be unique' AS detail;
    END;

    START TRANSACTION;
    INSERT INTO HOTEL (HotelID, HotelName, Block, HeadID)
    VALUES ('S2X', 'Resort Unit', 'X', NULL);
    SELECT 'UNEXPECTED' AS result, 'd' AS test_case,
           'no constraint violation' AS violated_constraint;
    ROLLBACK;
END$$
DELIMITER ;

CALL ex18_hotel_name();

SELECT 'baseline after invalid insert tests' AS checkpoint,
       (SELECT COUNT(*) FROM HOTEL) AS hotels,
       (SELECT COUNT(*) FROM HOST) AS hosts,
       (SELECT COUNT(*) FROM GUEST) AS guests,
       (SELECT COUNT(*) FROM PACKAGE) AS packages,
       (SELECT COUNT(*) FROM RESERVATION) AS reservations;

DROP PROCEDURE IF EXISTS ex18_merit;
DROP PROCEDURE IF EXISTS ex18_nightunits;
DROP PROCEDURE IF EXISTS ex18_package_fk;
DROP PROCEDURE IF EXISTS ex18_hotel_name;
