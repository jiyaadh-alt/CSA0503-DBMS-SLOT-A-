CREATE DATABASE IF NOT EXISTS hospitality_ex15;
USE hospitality_ex15;

DROP TABLE IF EXISTS HOST;
DROP TABLE IF EXISTS HOTEL;

CREATE TABLE HOTEL (
    HotelID   CHAR(4)      NOT NULL,
    HotelName VARCHAR(45)  NOT NULL,
    Block     CHAR(1)      NULL,
    HeadID    INT          NULL,
    PRIMARY KEY (HotelID),
    UNIQUE KEY uq_hotel_name (HotelName)
) ENGINE = InnoDB;

CREATE TABLE HOST (
    HostID   INT          NOT NULL,
    HostName VARCHAR(45)  NOT NULL,
    HotelID  CHAR(4)      NOT NULL,
    Grade    VARCHAR(20)  NOT NULL,
    Salary   INT          NOT NULL,
    JoinDate DATE         NULL,
    PRIMARY KEY (HostID),
    UNIQUE KEY uq_host_name (HostName),
    CONSTRAINT fk_host_hotel FOREIGN KEY (HotelID) REFERENCES HOTEL (HotelID),
    CONSTRAINT ck_host_salary CHECK (Salary > 0)
) ENGINE = InnoDB;

INSERT INTO HOTEL (HotelID, HotelName, Block, HeadID) VALUES
    ('S2A', 'City Unit',    'A', 121),
    ('S2B', 'Resort Unit',  'B', 221),
    ('S2C', 'Airport Unit', 'C', 321),
    ('S2D', 'Heritage Unit','D', NULL);

INSERT INTO HOST (HostID, HostName, HotelID, Grade, Salary, JoinDate) VALUES
    (121, 'Ms. Nila',   'S2A', 'Lead Host',    187000, '2008-06-12'),
    (122, 'Mr. Ravi',   'S2A', 'Senior Host',  134000, '2014-07-01'),
    (123, 'Ms. Tara',   'S2A', 'Junior Host',   80000, '2021-01-18'),
    (221, 'Mr. Arun',   'S2B', 'Lead Host',    178000, '2010-08-09'),
    (222, 'Mr. Keshav', 'S2B', 'Junior Host',   74000, '2022-06-20'),
    (321, 'Ms. Rani',   'S2C', 'Lead Host',    170000, '2009-12-01'),
    (322, 'Mr. Sameer', 'S2C', 'Junior Host',   71000, '2023-02-15');

DESCRIBE HOTEL;
DESCRIBE HOST;
SHOW CREATE TABLE HOTEL;
SHOW CREATE TABLE HOST;
