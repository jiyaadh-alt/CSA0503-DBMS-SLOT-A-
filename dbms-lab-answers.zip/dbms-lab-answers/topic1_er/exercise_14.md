# Exercise 14 — Seven spreadsheet failures and DBMS query-processor/storage-manager architecture

**Goal.** Explain seven distinct failures caused by separate hospitality spreadsheets with one domain example each, and draw the DBMS query-processor/storage-manager architecture.

## Chen-style ER diagram: integrated replacement design (Mermaid)

```mermaid
erDiagram
    HOTEL {
        char HotelID PK
        string HotelName
    }
    HOST {
        int HostID PK
        string HostName
        char HotelID FK
        decimal Salary
    }
    PACKAGE {
        char PackageID PK
        string Title
        char HotelID FK
    }
    ASSIGNMENT {
        int HostID PK, FK
        char PackageID PK, FK
        int Hours
    }
    GUEST {
        int GuestID PK
        string GuestName
        char HotelID FK
    }
    ALLOCATION {
        char PackageID PK, FK
        int GuestID PK, FK
        int Quantity
    }
    PAYMENT {
        int PaymentID PK
        int GuestID FK
        char PackageID FK
        decimal Amount
    }
    HOTEL ||--o{ HOST : employs
    HOTEL ||--o{ PACKAGE : owns
    HOST ||--o{ ASSIGNMENT : staffs
    PACKAGE ||--o{ ASSIGNMENT : has
    HOTEL ||--o{ GUEST : registers
    PACKAGE ||--o{ ALLOCATION : "allocated in"
    GUEST ||--o{ ALLOCATION : receives
    GUEST ||--o{ PAYMENT : makes
    PACKAGE ||--o{ PAYMENT : "paid for"
```

## Relational schema underlying the integrated database

- `HOTEL(<u>HotelID</u>, HotelName)`
- `HOST(<u>HostID</u>, HostName, HotelID FK -> HOTEL, Salary)`
- `PACKAGE(<u>PackageID</u>, Title, HotelID FK -> HOTEL)`
- `ASSIGNMENT(<u>HostID, PackageID</u>, Hours)`, with both columns as foreign keys
- `GUEST(<u>GuestID</u>, GuestName, HotelID FK -> HOTEL)`
- `ALLOCATION(<u>PackageID, GuestID</u>, Quantity)`, with both columns as foreign keys
- `PAYMENT(<u>PaymentID</u>, GuestID FK -> GUEST, PackageID FK -> PACKAGE, Amount)`

## Assumptions

1. Three spreadsheets exist: hotel staffing, package allocation and payments, each kept by a different team.
2. The same package identifier (for example `S201`) and the same guest identifier appear in more than one spreadsheet, but no shared database enforces agreement.
3. Spreadsheet cells have no central domain constraints, transaction control, concurrency control or authorization model.
4. A DBMS with an integrated conceptual schema and external views replaces the three files.

## Seven distinct failures

| # | Failure | Domain example |
|---|---|---|
| 1 | Redundancy | Host `121` name, grade and salary are retyped on every staffing row of `S2A`; the same guest name is repeated in allocation and payment sheets. |
| 2 | Inconsistent copies | Package `S201` allocation amount is 5000 in the allocation sheet but 4500 in the finance sheet, so reports disagree. |
| 3 | Isolated files | Staffing and payment sheets live on different machines with no shared key or join path, so "which host staffed the package that produced payment P7?" needs manual copying. |
| 4 | Invalid values | A clerk types `Gender = 'X'`, `Capacity = -5` or `NightUnits = 9`; the spreadsheet accepts it although the domain is 1..5 for `NightUnits`. |
| 5 | Partial updates | Hotel `S2A` changes head host from `121` to `122`; the staffing sheet is updated but the allocation sheet still names `121`, leaving a half-applied change. |
| 6 | Simultaneous edits | Two clerks open the allocation sheet and both edit the `Quantity` of package `S201`; the last save overwrites the first, so one update is lost. |
| 7 | Excessive access | The whole salary column is visible to every employee with the shared drive link; junior staff can see all host salaries instead of only their own scheduling data. |

## DBMS query-processor/storage-manager architecture (Mermaid)

```mermaid
flowchart TD
    USER["Users and applications"] --> EXT["External views"]
    EXT --> DDL["DDL interpreter"]
    EXT --> DML["DML compiler"]
    DML --> OPT["Query optimizer"]
    OPT --> EVAL["Query evaluation engine"]
    DDL --> CAT["Metadata catalog"]
    EVAL --> AUTH["Authorization and integrity manager"]
    EVAL --> TX["Transaction manager"]
    AUTH --> FILE["File manager"]
    TX --> FILE
    AUTH --> BUF["Buffer manager"]
    TX --> BUF
    FILE --> DISK["Data files on disk"]
    BUF --> DISK
    CAT --> DISK
    DISK --> IDX["Indexes and statistics"]
```

## How the DBMS addresses each failure

| Failure | DBMS mechanism |
|---|---|
| Redundancy | one integrated schema; each fact stored once, views derive repeated displays |
| Inconsistent copies | single storage of each fact plus integrity constraints |
| Isolated files | one catalog and foreign keys linking hotel, package, guest and payment relations |
| Invalid values | `CHECK`, `NOT NULL`, domains and data types in DDL |
| Partial updates | transactions with atomic commit/rollback |
| Simultaneous edits | concurrency control and locking (serializable schedules) |
| Excessive access | authorization and external views exposing only permitted columns |

The query processor parses and optimizes requests against the catalog; the storage manager enforces integrity, transactions and access paths, and mediates all reads and writes to data files, metadata and indexes.
