# Exercise 13 — Hierarchical and network representations of HOTEL → PACKAGE → RESERVATION

**Goal.** Show one hierarchical occurrence for `S2A`, give the equivalent network-model representation, identify repeated guest references, and name both owner–member sets of the link record.

## Chen-style ER diagram (Mermaid)

```mermaid
erDiagram
    HOTEL {
        char HotelID PK
        string HotelName
    }
    PACKAGE {
        char PackageID PK
        string Title
        char HotelID FK
    }
    RESERVATION {
        int GuestID PK, FK
        char PackageID PK, FK
        int Term
        tinyint ReviewScore
    }
    GUEST {
        int GuestID PK
        string GuestName
        char HotelID FK
    }
    RES_GUEST_LINK {
        int GuestID PK, FK
        char PackageID PK, FK
    }
    HOTEL ||--o{ PACKAGE : "owner-member HOTEL_HAS_PACKAGE"
    PACKAGE ||--o{ RESERVATION : "owner-member PACKAGE_HAS_RESERVATION"
    RESERVATION ||--o{ RES_GUEST_LINK : "owner-member RESERVATION_LINK_SET"
    GUEST ||--o{ RES_GUEST_LINK : "owner-member GUEST_LINK_SET"
```

## Hierarchical occurrence for S2A (Mermaid)

```mermaid
flowchart TD
    H["HOTEL S2A - City Unit"] --> P1["PACKAGE S201 - City Break"]
    H --> P2["PACKAGE S202 - Business Stay"]
    H --> P3["PACKAGE S203 - Weekend Stay"]
    P1 --> R1["RESERVATION G1201 T3 S86"]
    P1 --> R2["RESERVATION G1202 T3 S93"]
    P1 --> R3["RESERVATION G1203 T3 S45"]
    P1 --> R4["RESERVATION G1204 T3 S70"]
    P1 --> R5["RESERVATION G1208 T3 S96"]
    P2 --> R6["RESERVATION G1201 T3 S74"]
    P2 --> R7["RESERVATION G1202 T3 S87"]
    P2 --> R8["RESERVATION G1208 T3 S92"]
    P3 --> R9["RESERVATION G1201 T3 S89"]
    P3 --> R10["RESERVATION G1203 T3 S60"]
    P3 --> R11["RESERVATION G1208 T3 S95"]
    P3 --> R12["RESERVATION G1210 T3 S77"]
```

Each leaf is written as `RESERVATION G<GuestID> T<Term> S<ReviewScore>`, using the baseline instance. Guest `1204` belongs to hotel `S2B` and guest `1210` belongs to hotel `S2C`, so both use an offering of a unit other than their own.

## Equivalent relational schema

- `HOTEL(<u>HotelID</u>, HotelName)`
- `PACKAGE(<u>PackageID</u>, Title, HotelID FK -> HOTEL)`
- `RESERVATION(<u>GuestID, PackageID</u>, Term, ReviewScore)`, with both columns as foreign keys
- `GUEST(<u>GuestID</u>, GuestName, HotelID FK -> HOTEL)`

The relational form stores guest `1201` once; the hierarchical form repeats its identifier in every reservation leaf.

## Assumptions

1. The hierarchy is `HOTEL` (root) → `PACKAGE` (child) → `RESERVATION` (leaf); each `RESERVATION` child has exactly one `PACKAGE` parent and each `PACKAGE` exactly one `HOTEL` parent.
2. A guest may use offerings from several units; therefore `GUEST` is not a child of one hotel in the network model.
3. The link record `RES_GUEST_LINK` resolves the many-to-many association between `RESERVATION` and `GUEST`.
4. Baseline values for `S2A` packages and their reservations are used exactly as stored.

## Repeated guest references

| GuestID | Occurrences under S2A | Packages |
|---|---|---|
| 1201 | 3 | S201, S202, S203 |
| 1202 | 2 | S201, S202 |
| 1203 | 2 | S201, S203 |
| 1208 | 3 | S201, S202, S203 |
| 1204 | 1 | S201 |
| 1210 | 1 | S203 |

In the hierarchical occurrence the same guest is stored repeatedly as a value inside different `RESERVATION` leaves (`1201` and `1208` three times each). This is a repeated reference, not a repeated independent guest, and it is why the hierarchical tree cannot enforce guest identity or support a guest-centred query without scanning the tree.

## Network model and the link record's owner–member sets

| Set name | Owner record | Member record | Meaning |
|---|---|---|---|
| `HOTEL_HAS_PACKAGE` | `HOTEL` | `PACKAGE` | packages are owned by one hotel |
| `PACKAGE_HAS_RESERVATION` | `PACKAGE` | `RESERVATION` | reservations belong to one package |
| `RESERVATION_LINK_SET` | `RESERVATION` | `RES_GUEST_LINK` | each reservation links to its guest through one link occurrence |
| `GUEST_LINK_SET` | `GUEST` | `RES_GUEST_LINK` | each guest links to all its reservations through link occurrences |

The two owner–member sets of the link record are **`RESERVATION_LINK_SET`** (owner `RESERVATION`, member `RES_GUEST_LINK`) and **`GUEST_LINK_SET`** (owner `GUEST`, member `RES_GUEST_LINK`). A link occurrence is a member of both sets, so guest `1201` is stored once and reached from three reservations, and guest `1210` of `S2C` can be linked to reservation `S203` of `S2A` without relocating the guest under `S2A`.
