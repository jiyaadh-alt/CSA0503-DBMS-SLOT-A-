# Exercise 4 — Min–max (min,max) constraints on STAY–ATTENDANT

**Goal.** Express the full min–max constraints for `STAY–HOTEL` and `STAY–ATTENDANT`, and identify what an ordinary `M:N` label omits.

## Chen-style ER diagram (Mermaid)

```mermaid
erDiagram
    HOTEL ||--o{ STAY : "1 hotel per STAY / 0..N STAYs per HOTEL"
    STAY }o--|{ ATTENDANT : "STAY needs (2,6) / ATTENDANT covers (0,5)"
```

**Chen legend.** Chen min–max notation writes `(min,max)` at each end of the relationship line. Here: `STAY` — `(1,1)` with `HOTEL`; `HOTEL` — `(0,N)` with `STAY`; `STAY` — `(2,6)` with `ATTENDANT`; `ATTENDANT` — `(0,5)` with `STAY`. Mermaid shows only one-or-more / zero-or-more, so the numeric bounds are carried in the labels.

## Assumptions

1. Each `STAY` uses exactly one `HOTEL`; a hotel hosts any number of stays, including none.
2. Worker and attendant are the same entity type.
3. The bounds apply to the current snapshot: 2 to 6 attendants per stay, 0 to 5 stays per attendant.
4. Attendant count is per stay occurrence, and stay count is per attendant occurrence.

## Complete min–max table

| Relationship end | Min | Max | Meaning |
|---|---|---|---|
| `STAY` with `HOTEL` | 1 | 1 | exactly one hotel per stay, total participation |
| `HOTEL` with `STAY` | 0 | N | a hotel may host no stays |
| `STAY` with `ATTENDANT` | 2 | 6 | an event needs two to six workers |
| `ATTENDANT` with `STAY` | 0 | 5 | a worker covers none to five events |

## Resulting relational schema

- `HOTEL(<u>HotelID</u>, HotelName, Block)`
- `STAY(<u>StayID</u>, StartDate, HotelID FK -> HOTEL NOT NULL)`
- `ATTENDANT(<u>AttendantID</u>, AttendantName, Grade)`
- `STAY_ATTENDANT(<u>StayID, AttendantID</u>)`, with both columns as foreign keys

## What plain M:N omits

A bare `M:N` label only says "many attendants per stay and many stays per attendant". It omits:

- **Participation minima.** `STAY` has min 2, so a stay with zero or one attendant row is invalid; `ATTENDANT` has min 0, so an unused worker is valid. Plain `M:N` cannot distinguish these.
- **Upper bounds.** No stay may have 7 attendants and no attendant may cover 6 stays.
- **Existence dependence of rows.** The intersection relation must contain at least two rows per `StayID`.

Because aggregate counts span multiple rows, declarative column `CHECK` constraints are insufficient: use assertions or triggers over `STAY_ATTENDANT` that reject (a) a stay whose count falls outside 2..6 and (b) an attendant whose count exceeds 5.
