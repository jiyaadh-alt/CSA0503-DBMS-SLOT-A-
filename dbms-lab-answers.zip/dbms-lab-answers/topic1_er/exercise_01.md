# Exercise 1 — STAY_PLAN: attributes, participation, monthly charge and relations

**Goal.** Model `VISITOR` and `STAY_PLAN` with a composite address, several contact numbers, exactly one holder per plan, at most four active plans per holder, derive the monthly charge, and map the design to relations.

## Chen-style ER diagram (Mermaid)

```mermaid
erDiagram
    VISITOR {
        int PersonID PK
        string Name
        string Street
        string City
        string PIN
    }
    STAY_PLAN {
        int PlanNo PK
        date StartDate
        decimal AnnualCharge
        string Status
        string ContactNo
    }
    VISITOR ||--o{ STAY_PLAN : "holds - 0 to 4 ACTIVE"
```

**Chen legend.** In Chen notation `PersonID` and `PlanNo` would be underlined keys; `Address` would be one composite attribute with three component ovals (Street, City, PIN); `ContactNo` would be a double oval because it is multivalued; `STAY_PLAN` participates totally (double line) in `HOLDS` with cardinality 1..1 towards `VISITOR`; `VISITOR` participates partially (single line) with min 0, max 4 active plans. Mermaid has no composite/multivalued attribute symbols or min–max labels, so those facts are written in the legend and assumptions instead.

## Assumptions

1. `PersonID` and `PlanNo` are unique, non-null identifiers; no plan exists without a holder.
2. `Address` is composite: `Street`, `City`, `PIN`; it is stored as three columns, not as one string.
3. `ContactNo` is multivalued: a plan has several distinct contact numbers and repeats are not stored.
4. "Exactly one holder" means total participation of `STAY_PLAN` in `HOLDS`, cardinality 1..1 on the holder side; the foreign key is `NOT NULL`.
5. "At most 4 active plans" counts only rows whose `Status = 'ACTIVE'`; a holder may own any number of non-active plans.
6. `Status` domain is `{'ACTIVE','SUSPENDED','CLOSED'}`.
7. `MonthlyCharge` is fully derived from `AnnualCharge` and is therefore not stored as a base column.

## Resulting relational schema

- `VISITOR(<u>PersonID</u>, Name, Street, City, PIN)`
- `STAY_PLAN(<u>PlanNo</u>, StartDate, AnnualCharge, Status, HolderID FK -> VISITOR(PersonID) NOT NULL)`
- `PLAN_CONTACT(<u>PlanNo, ContactNo</u>)`, with `PlanNo FK -> STAY_PLAN(PlanNo) ON DELETE CASCADE`

The composite attribute is flattened into `Street`, `City`, `PIN`. The multivalued attribute becomes its own relation whose primary key is the plan key plus the contact value.

## Derivation: monthly charge

`MonthlyCharge = AnnualCharge / 12`. Example: `AnnualCharge = 24000` gives `MonthlyCharge = 2000`.

```sql
CREATE VIEW STAY_PLAN_MONTHLY AS
SELECT PlanNo, AnnualCharge / 12 AS MonthlyCharge
FROM STAY_PLAN;
```

Because it is derived, an update to `AnnualCharge` automatically changes the displayed monthly charge; no update anomaly is possible.

## Cardinality and participation justification

| End | Min | Max | Reason | Enforcement |
|---|---|---|---|---|
| `STAY_PLAN` -> `VISITOR` | 1 | 1 | "exactly one holder" | `HolderID NOT NULL` plus FK |
| `VISITOR` -> `STAY_PLAN` (active only) | 0 | 4 | "a holder may have at most 4 active plans" | assertion/trigger over `COUNT(*) WHERE Status='ACTIVE'` |

An ordinary `1:N` label captures "one holder, many plans" but loses the min 0 and the max 4; SQL `CHECK` cannot count other rows, so a trigger or assertion is needed for the upper bound.

## Sample instance

The following rows are illustrative only and do not come from the baseline.

| VISITOR | PersonID | Name | Street | City | PIN |
|---|---|---|---|---|---|
| | 1 | Asha | 12 Lake Road | Mysuru | 570001 |

| STAY_PLAN | PlanNo | StartDate | AnnualCharge | Status | HolderID |
|---|---|---|---|---|---|
| | 101 | 2026-01-01 | 24000 | ACTIVE | 1 |

| PLAN_CONTACT | PlanNo | ContactNo |
|---|---|---|
| | 101 | 90000-11111 |
| | 101 | 90000-22222 |

The design stores this instance: two contact numbers are two rows in `PLAN_CONTACT`, and the plan's holder is one `VISITOR` row.
