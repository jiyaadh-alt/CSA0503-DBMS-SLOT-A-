# Exercise 12 — External views, internal choices and data independence

**Goal.** Give separate scheduling and finance external views over one conceptual schema, propose two internal storage choices, and explain logical and physical data independence.

## Chen-style ER diagram: conceptual schema (Mermaid)

```mermaid
erDiagram
    HOTEL {
        char HotelID PK
        string HotelName
    }
    HOST {
        int HostID PK
        string HostName
        char HotelID FK
        string Grade
    }
    GUEST {
        int GuestID PK
        string GuestName
        char HotelID FK
    }
    GUEST_CONTACT {
        int GuestID PK, FK
        string PhoneNo
        string Email
    }
    PACKAGE {
        char PackageID PK
        string Title
        char HotelID FK
    }
    ASSIGNMENT {
        int HostID PK, FK
        char PackageID PK, FK
        int Hours
    }
    RESERVATION {
        int GuestID PK, FK
        char PackageID PK, FK
        int Term
    }
    PAYMENT {
        int PaymentID PK
        int GuestID FK
        char PackageID FK
        decimal Amount
        date PaymentDate
    }
    HOTEL ||--o{ HOST : employs
    HOTEL ||--o{ GUEST : registers
    HOTEL ||--o{ PACKAGE : owns
    GUEST ||--o{ GUEST_CONTACT : "has"
    HOST ||--o{ ASSIGNMENT : "assigned in"
    PACKAGE ||--o{ ASSIGNMENT : has
    GUEST ||--o{ RESERVATION : books
    PACKAGE ||--o{ RESERVATION : "has"
    GUEST ||--o{ PAYMENT : makes
    PACKAGE ||--o{ PAYMENT : "paid for"
```

## Three-schema architecture (Mermaid)

```mermaid
flowchart TD
    S["Scheduling staff"] --> SV["Scheduling external view"]
    F["Finance staff"] --> FV["Finance external view"]
    SV --> CM["Conceptual schema"]
    FV --> CM
    CM --> IM["Internal schema - storage and indexes"]
    IM --> DB["Stored hospitality database"]
```

## Assumptions

1. The baseline relations `HOTEL`, `HOST`, `GUEST`, `PACKAGE` and `RESERVATION` are the conceptual core; `ASSIGNMENT`, `GUEST_CONTACT` and `PAYMENT` are added to support the two views.
2. Scheduling staff need names, grades, hotel and package assignments and hours; they do not need payment amounts.
3. Finance staff need guest/package payment facts; they do not need host grades or working hours.
4. Contact details may be stored separately from the core guest record without changing what users see.
5. Index choices affect performance only, not the meaning of any view.

## External views

- `SCHEDULING_VIEW(<u>HostID, PackageID</u>, HostName, HotelID, Grade, Title, Hours)` — join of `HOST`, `ASSIGNMENT` and `PACKAGE`.
- `FINANCE_VIEW(<u>PaymentID</u>, GuestID, PackageID, Amount, PaymentDate)` — join/projection of `PAYMENT` (with guest and package keys for reference).

## Resulting relational schema (base relations)

- `HOTEL(<u>HotelID</u>, HotelName, Block, HeadID FK -> HOST)`
- `HOST(<u>HostID</u>, HostName, HotelID FK -> HOTEL, Grade, Salary, JoinDate)`
- `GUEST(<u>GuestID</u>, GuestName, HotelID FK -> HOTEL, Gender, BirthDate, City, Merit, AssignedHost FK -> HOST)`
- `GUEST_CONTACT(<u>GuestID</u>, PhoneNo, Email)`, with `GuestID FK -> GUEST` (one primary contact row per guest)
- `PACKAGE(<u>PackageID</u>, Title, NightUnits, HotelID FK -> HOTEL)`
- `ASSIGNMENT(<u>HostID, PackageID</u>, Hours)` with both foreign keys
- `RESERVATION(<u>GuestID, PackageID</u>, Term, ReviewScore)` with both foreign keys
- `PAYMENT(<u>PaymentID</u>, GuestID FK -> GUEST, PackageID FK -> PACKAGE, Amount, PaymentDate)`

## Two internal storage choices

1. Heap files for all relations plus a B+tree index on `RESERVATION(GuestID)` to speed guest-centred lookups.
2. Clustered storage ordered by `HOTEL(HotelID)` with a hash index on `PACKAGE(PackageID)` to speed hotel-wide scheduling reports.

## Data independence

| Change | Type of independence | Why applications are unaffected |
|---|---|---|
| Move `PhoneNo`/`Email` out of `GUEST` into `GUEST_CONTACT` and redefine the view internally | Logical data independence | the conceptual schema changes, but `SCHEDULING_VIEW` and `FINANCE_VIEW` keep the same columns; user queries still reference the view names and columns |
| Replace the B+tree on `RESERVATION(GuestID)` with a hash index, or add an index on `HOST(HostID)` | Physical data independence | only the internal storage/access path changes; conceptual and external schemas and all query results are identical, only performance differs |

Separation of external views also enforces least privilege: finance cannot see salaries through its view, and scheduling cannot see payment amounts.
