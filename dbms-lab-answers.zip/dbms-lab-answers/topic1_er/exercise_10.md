# Exercise 10 — Seven-step ER-to-relational mapping

**Goal.** Apply the seven standard ER mapping steps to the hospitality design with hotel phones, head host, unit membership, supervision, packages, assignments and weak details, and list every relation and key.

## Chen-style ER diagram (Mermaid)

```mermaid
erDiagram
    HOTEL {
        char HotelID PK
        string HotelName
        char Block
        int HeadID FK
    }
    HOST {
        int HostID PK
        string HostName
        char HotelID FK
        int SupervisorID FK
        string Grade
    }
    HOTEL_PHONE {
        char HotelID PK, FK
        string PhoneNo PK
    }
    PACKAGE {
        char PackageID PK
        string Title
        tinyint NightUnits
        char HotelID FK
    }
    ASSIGNMENT {
        int HostID PK, FK
        char PackageID PK, FK
        int Hours
    }
    DETAIL {
        char PackageID PK, FK
        int DetailNo PK
        string Description
    }
    HOTEL |o--o| HOST : "heads - 0 or 1"
    HOTEL ||--o{ HOST : employs
    HOTEL ||--o{ PACKAGE : owns
    HOTEL ||--o{ HOTEL_PHONE : lists
    HOST ||--o{ HOST : supervises
    HOST ||--o{ ASSIGNMENT : "assigned in"
    PACKAGE ||--o{ ASSIGNMENT : has
    PACKAGE ||--|{ DETAIL : "identifies (weak)"
```

**Chen legend.** `DETAIL` is a double rectangle with dashed-underlined `DetailNo`; its identifying relationship to `PACKAGE` is total from `DETAIL`. `PhoneNo` is a multivalued attribute (double oval) of `HOTEL`. Mermaid lacks the double box and partial-key underline; identifying relationships use solid lines (`--`) and non-identifying ones use `..`, so the labels encode the rest.

## Assumptions

1. The "unit" a host belongs to and the "unit" owning packages is the `HOTEL` organizational unit already present in the baseline; no separate `UNIT` relation is created.
2. A hotel has at most one head host, and a host heads at most one hotel; the head may be unset, as in baseline hotel `S2D`.
3. `SupervisorID` is a recursive `1:N` relationship: a host supervises many host staff, each supervised host has at most one supervisor.
4. `Hours` is a property of the `HOST–PACKAGE` assignment pair.
5. `DetailNo` is unique only within one package; details cannot outlive their package.

## The seven mapping steps

| Step | Construct in this design | Mapping result |
|---|---|---|
| 1. Regular entities | `HOTEL`, `HOST`, `PACKAGE` | base relations with underlined simple keys |
| 2. Weak entities | `DETAIL` | `DETAIL(<u>PackageID, DetailNo</u>, Description)` with composite key and cascading FK |
| 3. Binary 1:1 | `HOTEL` head `HOST` | `HeadID` added to `HOTEL`, nullable, `UNIQUE` |
| 4. Binary 1:N | `HOST` belongs to hotel; hotel owns package; host supervises host | `HotelID` in `HOST`; `HotelID` in `PACKAGE`; `SupervisorID` in `HOST` |
| 5. Binary M:N | host staff assigned to package offerings | `ASSIGNMENT(<u>HostID, PackageID</u>, Hours)` |
| 6. Multivalued attributes | hotel phone numbers | `HOTEL_PHONE(<u>HotelID, PhoneNo</u>)` |
| 7. N-ary relationships | none in this design | no additional relation |

## Complete relation list

- `HOTEL(<u>HotelID</u>, HotelName, Block, HeadID FK -> HOST NULL UNIQUE)`
- `HOST(<u>HostID</u>, HostName, HotelID FK -> HOTEL NOT NULL, SupervisorID FK -> HOST NULL, Grade, Salary, JoinDate)`
- `PACKAGE(<u>PackageID</u>, Title, NightUnits, HotelID FK -> HOTEL NOT NULL)`
- `DETAIL(<u>PackageID, DetailNo</u>, Description)`, with `PackageID FK -> PACKAGE ON DELETE CASCADE`
- `ASSIGNMENT(<u>HostID, PackageID</u>, Hours)`, with `HostID FK -> HOST` and `PackageID FK -> PACKAGE`
- `HOTEL_PHONE(<u>HotelID, PhoneNo</u>)`, with `HotelID FK -> HOTEL ON DELETE CASCADE`

If the baseline `GUEST` and `RESERVATION` relations are also in scope, `GUEST` is added in step 1 and `RESERVATION(<u>GuestID, PackageID</u>, Term, ReviewScore)` in step 5; they are not part of the design described in this exercise.

## Key and integrity notes

- `HeadID` is nullable because a hotel may have no head at a given time; `UNIQUE` stops one host from heading two hotels.
- `HOTEL` and `HOST` reference each other (`HOTEL.HeadID -> HOST`, `HOST.HotelID -> HOTEL`), so a head must be inserted/assigned after its host row exists; the nullable head permits this.
- `SupervisorID` is self-referencing and nullable for senior hosts; a trigger may forbid a supervision cycle.
- `DETAIL` uses the owner key as part of its own key, so two packages may each have a `DetailNo = 1` without collision.
