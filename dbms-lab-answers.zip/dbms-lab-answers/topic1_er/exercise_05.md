# Exercise 5 — Ternary ALLOCATION versus three pairwise projections

**Goal.** Model `VENDOR` supplies `PACKAGE` for `GUEST` with `Quantity` as one ternary fact, compare it with three pairwise projections, and reconstruct the join for the given sample.

## Chen-style ER diagram (Mermaid)

```mermaid
erDiagram
    VENDOR {
        char VendorID PK
        string VendorName
    }
    PACKAGE {
        char PackageID PK
        string Title
    }
    GUEST {
        char GuestID PK
        string GuestName
    }
    ALLOCATION {
        char VendorID PK, FK
        char PackageID PK, FK
        char GuestID PK, FK
        int Quantity
    }
    VENDOR ||--o{ ALLOCATION : supplies
    PACKAGE ||--o{ ALLOCATION : "used in"
    GUEST ||--o{ ALLOCATION : receives
```

**Chen legend.** A Chen ternary relationship is one diamond with three lines and `Quantity` attached to the diamond. Mermaid has no ternary diamond, so the fact is reified as the associative entity `ALLOCATION`; the three lines and the composite key represent the same ternary fact.

## Assumptions

1. One allocation is a single fact involving exactly one vendor, one package and one guest; `Quantity` belongs to the triple, not to any pair.
2. The identifier of an allocation is the full triple `(VendorID, PackageID, GuestID)`.
3. A vendor may appear in many allocations, a package in many, and a guest in many; all three entities exist independently.
4. The sample IDs `S2V1`, `S2V2`, `S2P1`, `S2P2`, `S2C1`, `S2C2` refer to existing vendor, package and guest rows.

## Resulting relational schema

- `VENDOR(<u>VendorID</u>, VendorName)`
- `PACKAGE(<u>PackageID</u>, Title, HotelID FK -> HOTEL)`
- `GUEST(<u>GuestID</u>, GuestName, HotelID FK -> HOTEL)`
- `ALLOCATION(<u>VendorID, PackageID, GuestID</u>, Quantity)`, with three foreign keys

## Original ternary facts

| VendorID | PackageID | GuestID | Quantity |
|---|---|---|---|
| S2V1 | S2P1 | S2C1 | q1 |
| S2V1 | S2P2 | S2C2 | q2 |
| S2V2 | S2P1 | S2C2 | q3 |

## Three pairwise projections

`VP = ALLOCATION[VendorID, PackageID]`

| VendorID | PackageID |
|---|---|
| S2V1 | S2P1 |
| S2V1 | S2P2 |
| S2V2 | S2P1 |

`PC = ALLOCATION[PackageID, GuestID]`

| PackageID | GuestID |
|---|---|
| S2P1 | S2C1 |
| S2P2 | S2C2 |
| S2P1 | S2C2 |

`VC = ALLOCATION[VendorID, GuestID]`

| VendorID | GuestID |
|---|---|
| S2V1 | S2C1 |
| S2V1 | S2C2 |
| S2V2 | S2C2 |

## Reconstructed natural join `VP ⋈ PC ⋈ VC`

| VendorID | PackageID | GuestID | Present originally? |
|---|---|---|---|
| S2V1 | S2P1 | S2C1 | yes |
| S2V1 | S2P1 | S2C2 | **no — spurious** |
| S2V1 | S2P2 | S2C2 | yes |
| S2V2 | S2P1 | S2C2 | yes |

The unsupported allocation is **(S2V1, S2P1, S2C2)**. Each of its pairs exists in some real fact — `(S2V1,S2P1)` from the first fact, `(S2P1,S2C2)` from the third, `(S2V1,S2C2)` from the second — but the three never occur together. The triple `(S2V2,S2P1,S2C1)` is not produced at all because pair `(S2V2,S2C1)` is absent.

## Comparison

| Design | Stores | Recombination |
|---|---|---|
| One ternary relation | the exact triple and its `Quantity` | lossless; no extra row |
| Three binary projections | only pairs; `Quantity` is lost | lossy: invents `(S2V1,S2P1,S2C2)` |

Therefore the pairwise decomposition is not a valid replacement for the ternary fact; the triple must be stored as one relation.
