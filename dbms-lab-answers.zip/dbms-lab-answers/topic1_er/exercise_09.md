# Exercise 9 — Aggregation: HOST allocated to STAY, reviewed by an ATTENDANT

**Goal.** Model the allocation of a `HOST` to a `STAY` as an aggregation and map the supervisor review so it cannot point at a nonexistent host–event pair.

## Chen-style EER diagram (Mermaid)

```mermaid
erDiagram
    HOST {
        int HostID PK
        string HostName
    }
    STAY {
        int StayID PK
        string HotelID FK
    }
    ATTENDANT {
        int AttendantID PK
        string AttendantName
    }
    ALLOCATION {
        int HostID PK, FK
        int StayID PK, FK
        int Hours
    }
    REVIEW {
        int HostID PK, FK
        int StayID PK, FK
        int AttendantID FK
        date ReviewDate
    }
    HOST ||--o{ ALLOCATION : "allocated in"
    STAY ||--o{ ALLOCATION : "has"
    ALLOCATION ||--|| REVIEW : "reviewed exactly once"
    ATTENDANT ||--o{ REVIEW : "supervises"
```

**Chen legend.** Aggregation is shown by enclosing the `HOST–ALLOCATION–STAY` relationship in a dashed box and treating the box as one participant in the `REVIEWS` diamond. Mermaid has no aggregation box, so the aggregate is reified as the entity `ALLOCATION`, keyed by the pair of participants.

## Assumptions

1. An allocation is identified by the pair `(HostID, StayID)`; `Hours` belongs to the pair.
2. A host may have several allocations; a stay may have several allocated hosts.
3. Each allocation is reviewed exactly once, by exactly one `ATTENDANT` supervisor.
4. A supervisor may review many allocations and need not review any.
5. A review has no independent existence: it always refers to an existing allocation.

## Resulting relational schema

- `HOST(<u>HostID</u>, HostName, HotelID FK -> HOTEL)`
- `STAY(<u>StayID</u>, StartDate, HotelID FK -> HOTEL)`
- `ATTENDANT(<u>AttendantID</u>, AttendantName)`
- `ALLOCATION(<u>HostID, StayID</u>, Hours)`, with `HostID FK -> HOST` and `StayID FK -> STAY`
- `REVIEW(<u>HostID, StayID</u>, AttendantID FK -> ATTENDANT NOT NULL, ReviewDate)`, with composite `(HostID, StayID) FK -> ALLOCATION(HostID, StayID)`

## Why a nonexistent pair cannot be reviewed

The primary key of `REVIEW` is the pair `(HostID, StayID)`, and the same pair is a composite foreign key to `ALLOCATION`. Inserting a review for `(999, 77)` fails unless `ALLOCATION` already contains that exact pair. Merging the review into `ALLOC` (a nullable `SupervisorID` column) would also prevent orphan references by construction, but it would lose the review's own attributes and the explicit one-review-per-allocation key. The aggregation mapping keeps the review as a separate fact while retaining the referential guarantee.

## Cardinality justification

| Relationship | Min | Max | Reason |
|---|---|---|---|
| `HOST` in `ALLOCATION` | 0 | N | a host may be allocated to several stays or none |
| `STAY` in `ALLOCATION` | 0 | N | a stay may allocate several hosts |
| `ALLOCATION` in `REVIEW` | 1 | 1 | exactly one supervisor reviews each allocation |
| `ATTENDANT` in `REVIEW` | 0 | N | supervisors may review several allocations |

Without aggregation, `REVIEWS` would have to connect an attendant directly to `HOST` and `STAY` separately, making it possible to store a review of a pair that was never allocated.
