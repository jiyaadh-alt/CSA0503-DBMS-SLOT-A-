# Exercise 8 — PAYER_S2 as a partial union (category)

**Goal.** Model a payment payer drawn from `VISITOR` or `VENDOR` as a partial union category with a surrogate key, and prevent one payer from linking to both sources.

## Chen-style EER diagram (Mermaid)

```mermaid
erDiagram
    VISITOR |o--o| PAYER_S2 : "partial disjoint union source"
    VENDOR |o--o| PAYER_S2 : "partial disjoint union source"
    PAYER_S2 ||--o{ PAYMENT : makes
```

**Chen legend.** A union/category is drawn as a circle containing `U` with lines from `VISITOR` and `VENDOR` to the circle and from the circle to `PAYER_S2`. Single lines indicate partial participation of both source populations. Mermaid has no union symbol, so the label records it.

## Assumptions

1. `VISITOR` and `VENDOR` are disjoint source populations; no real-world payer belongs to both.
2. Only some source records become payers, so participation of each source in the union is partial (0..1).
3. Every `PAYER_S2` occurrence comes from exactly one source record.
4. `PayerID` is a generated surrogate key; source identifiers are not reused as payer keys.
5. A payment has exactly one payer; a payer may make many payments.

## Resulting relational schema

- `VISITOR(<u>PersonID</u>, Name, Street, City, PIN)`
- `VENDOR(<u>VendorID</u>, VendorName, ContactNo)`
- `PAYER_S2(<u>PayerID</u>)`
- `PAYER_SOURCE(<u>PayerID FK -> PAYER_S2</u>, VisitorID FK -> VISITOR NULL, VendorID FK -> VENDOR NULL, SourceType)`, with checks `(SourceType = 'VISITOR' AND VisitorID IS NOT NULL AND VendorID IS NULL) OR (SourceType = 'VENDOR' AND VendorID IS NOT NULL AND VisitorID IS NULL)`
- `PAYMENT(<u>PaymentID</u>, PayerID FK -> PAYER_S2 NOT NULL, PackageID FK -> PACKAGE, Amount, PaymentDate)`

Alternative: store `PayerType CHECK IN ('VISITOR','VENDOR')` in `PAYER_S2` and add `PayerID UNIQUE FK -> PAYER_S2` to each source relation; the link table above is preferred because its `CHECK` makes the "exactly one source" rule explicit.

## Preventing a payer from linking to both sources

- `PayerID` is the primary key of `PAYER_SOURCE`, so a payer has at most one source row.
- The row-level `CHECK` forces exactly one of `VisitorID` and `VendorID` to be non-null; the other must be null.
- `VisitorID` and `VendorID` are individually `UNIQUE`, so one source record cannot become two payers.
- A cross-row assertion may additionally verify that `SourceType` agrees with the source entity's population; the disjointness assumption guarantees a visitor key and a vendor key never denote the same person.

## Mapping comparison

| Mapping | Handles "neither source pays" | Handles one payer in both sources |
|---|---|---|
| Copy payer key into each source | yes, nullable column | needs trigger/assertion |
| Separate `PAYER_SOURCE` link | yes, no row in link | structurally prevented by PK plus `CHECK` |

Because the category is partial, no source record is forced to have a payer row; because the sources are disjoint, the surrogate `PayerID` is necessary — neither `PersonID` nor `VendorID` alone can identify all payers.
