# Exercise 7 — Mapping the specializations under options 8A–8D

**Goal.** Using Exercise 6, map both hierarchies under the four standard specialization mapping options, show a subtype row for `S217`, and discuss discriminators and subtype-only storage.

## Chen-style EER diagram (Mermaid)

```mermaid
erDiagram
    HOSPITALITY_RESOURCE ||--o| ROOM : "ISA total disjoint"
    HOSPITALITY_RESOURCE ||--o| SUITE : "ISA total disjoint"
    HOSPITALITY_RESOURCE ||--o| VILLA : "ISA total disjoint"
    HOSPITALITY_USER ||--o| OPERATOR : "ISA partial overlapping"
    HOSPITALITY_USER ||--o| AUDITOR : "ISA partial overlapping"
```

**Chen legend.** Double line plus `d` = total disjoint; single line plus `o` = partial overlapping. Subtype keys are inherited, as shown in Exercise 6.

## Assumptions: definition of options 8A–8D

- **8A** — one relation for the superclass and one relation per subtype; each subtype key is a foreign key to the superclass.
- **8B** — one relation for the entire hierarchy, with a type discriminator and nullable subtype-specific columns.
- **8C** — subtype relations only, each repeating all inherited superclass attributes; no superclass relation.
- **8D** — subtype relations only, each holding the inherited key plus its own attributes; no superclass relation.
- `S217` is a `SUITE` resource named `Heritage Suite` with `SuiteLevel = 'DELUXE'`.
- In option 8B a single-valued discriminator is assumed unless explicitly replaced by flags.

## 8A — superclass plus subtype relations

- `HOSPITALITY_RESOURCE(<u>ResourceID</u>, ResourceName)`
- `ROOM(<u>ResourceID FK -> HOSPITALITY_RESOURCE</u>, BedCount)`
- `SUITE(<u>ResourceID FK -> HOSPITALITY_RESOURCE</u>, SuiteLevel)`
- `VILLA(<u>ResourceID FK -> HOSPITALITY_RESOURCE</u>, PlotArea)`
- `HOSPITALITY_USER(<u>UserID</u>, UserName)`
- `OPERATOR(<u>UserID FK -> HOSPITALITY_USER</u>, Shift)`
- `AUDITOR(<u>UserID FK -> HOSPITALITY_USER</u>, CertLevel)`

Sample row: `HOSPITALITY_RESOURCE(S217, Heritage Suite)` and `SUITE(S217, DELUXE)`.

## 8B — single relation with discriminator

- `RESOURCE_ALL(<u>ResourceID</u>, ResourceName, ResourceType, BedCount, SuiteLevel, PlotArea)` with `ResourceType IN ('ROOM','SUITE','VILLA')`
- `USER_ALL(<u>UserID</u>, UserName, UserType, Shift, CertLevel)` with a single `UserType` code

Sample row: `(S217, Heritage Suite, 'SUITE', NULL, 'DELUXE', NULL)`. With one `UserType` code a user who is both `OPERATOR` and `AUDITOR` cannot be represented; two flags (`IsOperator`, `IsAuditor`) are needed for overlapping types.

## 8C — subtype relations with inherited attributes

- `ROOM(<u>ResourceID</u>, ResourceName, BedCount)`
- `SUITE(<u>ResourceID</u>, ResourceName, SuiteLevel)`
- `VILLA(<u>ResourceID</u>, ResourceName, PlotArea)`
- `OPERATOR(<u>UserID</u>, UserName, Shift)`
- `AUDITOR(<u>UserID</u>, UserName, CertLevel)`

Sample row: `SUITE(S217, Heritage Suite, DELUXE)`. Valid for resources because the specialization is total and disjoint; invalid for users because users with neither role have nowhere to be stored and `UserName` may be duplicated inconsistently in two rows.

## 8D — subtype relations with key only

- `ROOM(<u>ResourceID</u>, BedCount)`
- `SUITE(<u>ResourceID</u>, SuiteLevel)`
- `VILLA(<u>ResourceID</u>, PlotArea)`
- `OPERATOR(<u>UserID</u>, Shift)`
- `AUDITOR(<u>UserID</u>, CertLevel)`

Sample row: `SUITE(S217, DELUXE)`. Valid only when the superclass contributes no further non-key attributes that must be retained; `ResourceName` would be lost here, so 8C is preferable for resources if that attribute is required.

## Discriminator and validity discussion

| Option | Total disjoint resource | Partial overlapping user |
|---|---|---|
| 8A | valid | valid, supports both and neither |
| 8B | valid with one `ResourceType` | needs two flags, not a single code |
| 8C | valid | invalid: "neither" users lost |
| 8D | valid only if superclass has only the key | invalid: "neither" users lost |

A single discriminator is a one-valued attribute: one row can hold only one type code. Overlapping membership means one occurrence belongs to two subtypes at once, so membership must be recorded twice (two flags or two subtype rows). Subtype-only storage (8C/8D) is valid only when the specialization is total — every superclass occurrence appears in at least one subtype relation — and, for 8D, when no non-key superclass attribute must be preserved.
