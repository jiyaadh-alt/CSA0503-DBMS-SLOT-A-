# Exercise 3 — Weak ROOM_UNIT, partial key and owner deletion

**Goal.** Model `ROOM_UNIT` as a weak entity identified only by `LocalNo` inside its owning `HOTEL`, map the composite key, and explain deletion behaviour.

## Chen-style EER diagram (Mermaid)

```mermaid
erDiagram
    HOTEL {
        char UnitID PK
        string Location
    }
    ROOM_UNIT {
        char LocalNo PK
        int Capacity
        string Status
    }
    HOTEL ||--o{ ROOM_UNIT : "identifies - weak, partial key LocalNo"
```

**Chen legend.** `ROOM_UNIT` would be a double rectangle, `LocalNo` a dashed-underlined partial key, and `IDENTIFIES` a dashed diamond with total participation from the weak entity. Mermaid has no double-box or partial-key underline symbols; identifying relationships are solid lines (`--`) while non-identifying ones use `..`, so the weakness is also encoded in the label.

## Assumptions

1. The owning "unit" is the `HOTEL` entity; `UnitID` (the baseline `HotelID`) and `Location` are its identifier and attribute.
2. `LocalNo` is unique only within one hotel: hotel `S2A` may have `LocalNo = 1` and hotel `S2B` may also have `LocalNo = 1`.
3. `Capacity` and `Status` are attributes of the weak entity, not of the owner.
4. A room unit cannot exist without its owner; `HOTEL` may own zero or many room units.
5. Deletion of a hotel should remove its room units because they have no independent identity.

## Resulting relational schema

- `HOTEL(<u>UnitID</u>, Location, HotelName, Block)`
- `ROOM_UNIT(<u>UnitID, LocalNo</u>, Capacity, Status)`, where `UnitID FK -> HOTEL(UnitID) ON DELETE CASCADE`

The composite identifier `(UnitID, LocalNo)` is the primary key of `ROOM_UNIT`; the owner key is both part of the weak entity's key and a foreign key. A separate `RoomID` surrogate may be added as a `UNIQUE` alternate key for references, but the logical identity remains `(UnitID, LocalNo)`.

## Composite-key mapping example

| HOTEL UnitID | Location |
|---|---|
| S2A | City Unit |
| S2B | Resort Unit |

| ROOM_UNIT UnitID | LocalNo | Capacity | Status |
|---|---|---|---|
| S2A | 1 | 12 | AVAILABLE |
| S2B | 1 | 22 | OCCUPIED |

Both rows have `LocalNo = 1`; only `(S2A,1)` and `(S2B,1)` are distinct keys. Mapping with `LocalNo` alone as the key would be wrong.

## Effect of deleting the owner

With `ON DELETE CASCADE`, deleting `HOTEL S2A` also deletes `(S2A,1)`: a weak entity has no existence outside its identifying owner, so an orphan row would be meaningless. With `ON DELETE RESTRICT`, the deletion would be rejected while any room unit remains; that choice is only appropriate if historical room records must be kept, in which case the entity is no longer purely weak in the operational model.
