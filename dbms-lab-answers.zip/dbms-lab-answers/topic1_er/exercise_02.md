# Exercise 2 — STAY, HOTEL, ATTENDANT and ROOM_UNIT: cardinalities and participation

**Goal.** Draw the ER design for stays, hotels, attendants and room units, and justify every cardinality and participation constraint.

## Chen-style ER diagram (Mermaid)

```mermaid
erDiagram
    HOTEL {
        char HotelID PK
        string HotelName
    }
    STAY {
        int StayID PK
        date StartDate
        char HotelID FK
        char RoomUnitID FK
    }
    ATTENDANT {
        int AttendantID PK
        string AttendantName
    }
    ROOM_UNIT {
        char ResourceID PK
        string Location
    }
    HOTEL ||--o{ STAY : "hosts - each STAY has exactly 1"
    STAY }o--|{ ATTENDANT : "needs 1 or more / covers 0 or more"
    STAY |o--|| ROOM_UNIT : "reserves - at most 1 STAY per unit"
```

**Chen legend.** Each relationship would be a diamond. `HOTEL–STAY` has a double line from `STAY` (total participation) and `1:N`; `STAY–ATTENDANT` is `M:N` with min 1 on the `STAY` side and min 0 on the `ATTENDANT` side; `STAY–ROOM_UNIT` is `1:1` with total participation of `STAY` and partial participation of `ROOM_UNIT` in this snapshot. Mermaid cannot show min–max numbers, so they are stated in labels/legend.

## Assumptions

1. `STAY` is an event with its own key `StayID`; "event" and "stay" denote the same occurrence.
2. A `HOTEL` may host zero, one or many stays; a stay cannot exist without its hotel.
3. A stay needs at least one attendant; an attendant may cover many stays or none.
4. A stay reserves exactly one room unit; in this snapshot a room unit is reserved by at most one stay.
5. The "at most one event per resource" rule is a snapshot constraint, not a statement about all future time.
6. Room units exist independently of stays; only stays are existence-dependent on the reservation relationship.

## Resulting relational schema

- `HOTEL(<u>HotelID</u>, HotelName, Location)`
- `ROOM_UNIT(<u>ResourceID</u>, Capacity, Status, Location)`
- `STAY(<u>StayID</u>, StartDate, HotelID FK -> HOTEL NOT NULL, RoomUnitID FK -> ROOM_UNIT NOT NULL UNIQUE)`
- `ATTENDANT(<u>AttendantID</u>, AttendantName, Grade)`
- `STAY_ATTENDANT(<u>StayID, AttendantID</u>)`, with `StayID FK -> STAY` and `AttendantID FK -> ATTENDANT`

The `1:N` hotel–stay relationship is placed as `HotelID` in `STAY`. The `1:1` reservation is placed as `RoomUnitID` in `STAY` with `UNIQUE` to prevent a second stay from taking the same unit. The `M:N` coverage becomes the intersection relation `STAY_ATTENDANT`; a trigger/assertion enforces `COUNT(AttendantID) >= 1` for each stored stay.

## Cardinality and participation justification

| Relationship | Left cardinality | Right cardinality | Justification |
|---|---|---|---|
| `HOTEL` hosts `STAY` | 1 hotel per stay (total) | 0..N stays per hotel | "every STAY belongs to one HOTEL; a HOTEL may have none" |
| `STAY` needs `ATTENDANT` | 1..N attendants per stay | 0..N stays per attendant | "Each STAY needs at least one ATTENDANT; staff may cover many events or none" |
| `STAY` reserves `ROOM_UNIT` | 1 unit per stay (total) | 0..1 stay per unit | "exactly one ROOM_UNIT ... reserved for at most one event in this snapshot" |

The lower bound of one attendant is participation, not cardinality: it forbids a stay row with no `STAY_ATTENDANT` rows. The upper bound of one stay per unit is what turns an otherwise ordinary `1:1` into a uniqueness constraint in the relational mapping.
