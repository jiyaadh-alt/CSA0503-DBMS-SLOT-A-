# Exercise 6 — Total disjoint and partial overlapping specializations

**Goal.** Draw the two EER specializations, give one attribute for every subtype, and explain the inherited key.

## Chen-style EER diagram (Mermaid)

```mermaid
erDiagram
    HOSPITALITY_RESOURCE {
        char ResourceID PK
        string ResourceName
    }
    ROOM {
        int BedCount
    }
    SUITE {
        string SuiteLevel
    }
    VILLA {
        decimal PlotArea
    }
    HOSPITALITY_USER {
        int UserID PK
        string UserName
    }
    OPERATOR {
        string Shift
    }
    AUDITOR {
        string CertLevel
    }
    HOSPITALITY_RESOURCE ||--o| ROOM : "ISA - total disjoint (d)"
    HOSPITALITY_RESOURCE ||--o| SUITE : "ISA - total disjoint (d)"
    HOSPITALITY_RESOURCE ||--o| VILLA : "ISA - total disjoint (d)"
    HOSPITALITY_USER ||--o| OPERATOR : "ISA - partial overlapping (o)"
    HOSPITALITY_USER ||--o| AUDITOR : "ISA - partial overlapping (o)"
```

**Chen/EER legend.** The subtype link is a circle containing `d` for disjoint or `o` for overlapping, attached to a double line for total participation and a single line for partial participation. `HOSPITALITY_RESOURCE` is total and disjoint (every resource is exactly one of `ROOM`, `SUITE`, `VILLA`); `HOSPITALITY_USER` is partial and overlapping (a user can be operator, auditor, both or neither). Mermaid has no `d`/`o` circle, so the labels carry this information.

## Assumptions

1. `ResourceID` identifies every hospitality resource, and `UserID` identifies every hospitality user.
2. Resource subtypes are mutually exclusive and cover the superclass completely.
3. User subtypes may overlap and do not cover the superclass.
4. Each subtype inherits all supertype attributes in addition to its own local attribute.

## Subtype attributes

| Supertype | Subtype | Local attribute | Example value |
|---|---|---|---|
| `HOSPITALITY_RESOURCE` | `ROOM` | `BedCount` | 2 |
| `HOSPITALITY_RESOURCE` | `SUITE` | `SuiteLevel` | DELUXE |
| `HOSPITALITY_RESOURCE` | `VILLA` | `PlotArea` | 240.50 |
| `HOSPITALITY_USER` | `OPERATOR` | `Shift` | MORNING |
| `HOSPITALITY_USER` | `AUDITOR` | `CertLevel` | SENIOR |

## Resulting relational schema (option 8A, expanded in Exercise 7)

- `HOSPITALITY_RESOURCE(<u>ResourceID</u>, ResourceName)`
- `ROOM(<u>ResourceID FK -> HOSPITALITY_RESOURCE</u>, BedCount)`
- `SUITE(<u>ResourceID FK -> HOSPITALITY_RESOURCE</u>, SuiteLevel)`
- `VILLA(<u>ResourceID FK -> HOSPITALITY_RESOURCE</u>, PlotArea)`
- `HOSPITALITY_USER(<u>UserID</u>, UserName)`
- `OPERATOR(<u>UserID FK -> HOSPITALITY_USER</u>, Shift)`
- `AUDITOR(<u>UserID FK -> HOSPITALITY_USER</u>, CertLevel)`

## Inherited key explanation

A subtype occurrence *is* a supertype occurrence, so it inherits the supertype identifier: `ROOM`, `SUITE` and `VILLA` are all keyed by `ResourceID`; `OPERATOR` and `AUDITOR` are all keyed by `UserID`. No new identifier is invented, and a subtype row cannot exist without the corresponding supertype row. In the overlapping user case the same `UserID` may legitimately appear in both `OPERATOR` and `AUDITOR`; in the disjoint resource case the same `ResourceID` must appear in exactly one subtype relation.
