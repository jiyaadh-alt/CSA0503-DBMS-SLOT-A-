# Exercise 11 — Schema versus state for ROOM_UNIT

**Goal.** Show before/after database states for `ROOM_UNIT` when resource `S28` changes `Capacity` from 12 to 22, and distinguish intension from extension.

## Chen-style ER diagram (Mermaid)

```mermaid
erDiagram
    ROOM_UNIT {
        char ResourceID PK
        int Capacity
        string Status
    }
```

**Chen legend.** `ResourceID` would be underlined in Chen notation; `Capacity` and `Status` are simple single-valued attributes.

## Assumptions

1. `S28` exists in both states and its `Status` is unchanged by this update.
2. Other rows, if any, are unaffected; the relation has `N` rows before and after the update.
3. The update is a value change, not an insertion or deletion.

## Intension (schema — unchanged)

`ROOM_UNIT(<u>ResourceID</u>, Capacity, Status)`

| Property | Value |
|---|---|
| Relation name | `ROOM_UNIT` |
| Attributes | `ResourceID`, `Capacity`, `Status` |
| Primary key | `ResourceID` |
| Attribute domains | identifier, integer, status code |

## Extension (state — changed)

Before the update:

| ResourceID | Capacity | Status |
|---|---|---|
| S28 | 12 | AVAILABLE |

After `UPDATE ROOM_UNIT SET Capacity = 22 WHERE ResourceID = 'S28';`:

| ResourceID | Capacity | Status |
|---|---|---|
| S28 | 22 | AVAILABLE |

## Does the schema or record count change?

| Question | Answer | Reason |
|---|---|---|
| Does the schema change? | No | attribute names, types and key stay the same |
| Does the record count change? | No | one existing row is modified; no row is added or removed |
| What changes? | one attribute value | `Capacity` of `S28` becomes 22 |

## Intension versus extension

| Aspect | Intension | Extension |
|---|---|---|
| Meaning | the schema/definition, i.e. the intension of the relation | the set of tuples stored at an instant, i.e. the extension/state |
| Example here | `ROOM_UNIT(ResourceID, Capacity, Status)` with key `ResourceID` | `{ ('S28',12,'AVAILABLE') }` before, `{ ('S28',22,'AVAILABLE') }` after |
| Change frequency | rare, via DDL | frequent, via DML |
| Effect of this exercise | unchanged | one tuple value changed |

The relation's degree and key are intensional; its cardinality and tuple contents are extensional. This is exactly why a database can change content without any schema change.
