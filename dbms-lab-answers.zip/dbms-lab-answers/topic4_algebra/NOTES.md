# Topic 4 lab notes

## Input conventions shared by the Python solutions

Every program reads all of its input from stdin. Blank lines are ignored. Each nonblank line is `LABEL: value`; attribute and value lists are comma-separated. Unrecognised labels are ignored. An empty stdin (or missing required labelled lines) produces a clearly labelled `EMPTY INPUT` result instead of a traceback.

Labels used:

- `ATTRS:` the explicit attribute list in the required display order.
- `FD:` one functional dependency written `LHS -> RHS`, where both sides are comma-separated attribute names.
- `START...:` a starting attribute set for Exercise 58 (`START_NO_PERIOD` and `START_WITH_PERIOD`; any labels beginning with `START` work and are reported in input order).
- `DECOMP1:`, `DECOMP2:` two relation schemas separated by `|` for Exercise 62 (labelled `DECOMP` for Exercise 63).
- `RESOURCE:`, `CAPABILITIES:`, `REGIONS:` the explicit sets for Exercise 64.

Attributes and dependencies are never inferred from names: only the `ATTRS` and `FD` lines define what the programs know. Ordering of printed dependencies, closures, subsets and tuples follows the input order, with subset enumeration by increasing size, so output is deterministic.

Verify all files with:

```text
python3 -m py_compile exercise_58.py exercise_59.py exercise_60.py exercise_61.py exercise_62.py exercise_63.py exercise_64.py
```

## Exercise 58 - sample invocation and expected output (Output 1 / Output 2)

Invocation:

```text
printf '%s\n' \
  'ATTRS: S2Job,S2Unit,S2Lead,S2Area,S2Period' \
  'FD: S2Job -> S2Unit' \
  'FD: S2Unit -> S2Lead' \
  'FD: S2Lead -> S2Area' \
  'START_NO_PERIOD: S2Job' \
  'START_WITH_PERIOD: S2Job,S2Period' | python3 exercise_58.py
```

Expected output:

```text
EXERCISE 58 - ATTRIBUTE CLOSURE WITH FIRED DEPENDENCIES
Attributes: S2Job, S2Unit, S2Lead, S2Area, S2Period
Explicit dependencies:
  FD 1: S2Job -> S2Unit
  FD 2: S2Unit -> S2Lead
  FD 3: S2Lead -> S2Area

OUTPUT 1 - START_NO_PERIOD: {S2Job}
  Initial closure: {S2Job}
  FIRED: S2Job -> S2Unit | added {S2Unit} | closure {S2Job, S2Unit}
  FIRED: S2Unit -> S2Lead | added {S2Lead} | closure {S2Job, S2Unit, S2Lead}
  FIRED: S2Lead -> S2Area | added {S2Area} | closure {S2Job, S2Unit, S2Lead, S2Area}
  No further dependency fires.
  Final closure: {S2Job, S2Unit, S2Lead, S2Area}

OUTPUT 2 - START_WITH_PERIOD: {S2Job, S2Period}
  Initial closure: {S2Job, S2Period}
  FIRED: S2Job -> S2Unit | added {S2Unit} | closure {S2Job, S2Period, S2Unit}
  FIRED: S2Unit -> S2Lead | added {S2Lead} | closure {S2Job, S2Period, S2Unit, S2Lead}
  FIRED: S2Lead -> S2Area | added {S2Area} | closure {S2Job, S2Period, S2Unit, S2Lead, S2Area}
  No further dependency fires.
  Final closure: {S2Job, S2Unit, S2Lead, S2Area, S2Period}
```

The two starting sets differ only by `S2Period`. Since no dependency has `S2Period` on a right-hand side, it is never added by a closure and never removed once present.

## Exercise 62 - sample invocation and expected output (Output 1 / Output 2)

Invocation:

```text
printf '%s\n' \
  'ATTRS: S2Job,S2Unit,S2Lead' \
  'FD: S2Job -> S2Unit' \
  'DECOMP1: S2Job,S2Unit | S2Job,S2Lead' \
  'DECOMP2: S2Job,S2Unit | S2Unit,S2Lead' | python3 exercise_62.py
```

Expected output:

```text
EXERCISE 62 - PROGRAMMED CHASE FOR LOSSLESS JOIN
Attributes: S2Job, S2Unit, S2Lead
Explicit dependencies:
  S2Job -> S2Unit

OUTPUT 1 - decomposition: {S2Job, S2Unit} ; {S2Job, S2Lead}
  Initial tableau:
       S2Job   S2Unit  S2Lead  
  R1   a1      a2      b13      {S2Job, S2Unit}
  R2   a1      b22     a3       {S2Job, S2Lead}
  Equalities forced:
    S2Job -> S2Unit: R2 and R1 agree on S2Job; R2.S2Unit b22 -> a2 from R1
  Final tableau:
       S2Job   S2Unit  S2Lead  
  R1   a1      a2      b13      {S2Job, S2Unit}
  R2   a1      a2      a3       {S2Job, S2Lead}
  Fully distinguished row: R2
  LOSSLESS: YES

OUTPUT 2 - decomposition: {S2Job, S2Unit} ; {S2Unit, S2Lead}
  Initial tableau:
       S2Job   S2Unit  S2Lead  
  R1   a1      a2      b13      {S2Job, S2Unit}
  R2   b21     a2      a3       {S2Unit, S2Lead}
  Equalities forced:
    none
  Final tableau:
       S2Job   S2Unit  S2Lead  
  R1   a1      a2      b13      {S2Job, S2Unit}
  R2   b21     a2      a3       {S2Unit, S2Lead}
  Fully distinguished row: none
  LOSSLESS: NO
```

The exercise statement does not print the two decompositions inline, so they are supplied explicitly: Output 1 is `{S2Job,S2Unit}` with `{S2Job,S2Lead}`, and Output 2 is `{S2Job,S2Unit}` with `{S2Unit,S2Lead}`. The first shares the determinant `S2Job` and is lossless; the second shares only `S2Unit`, which cannot determine `S2Job`, and is lossy.

## Exercise 59 - sample invocation

```text
printf '%s\n' \
  'ATTRS: S2Job,S2Unit,S2Lead,S2Area' \
  'FD: S2Job -> S2Lead' \
  'FD: S2Lead -> S2Area' \
  'FD: S2Area -> S2Lead' | python3 exercise_59.py
```

Key result: `S2Job` and `S2Unit` never appear on a right-hand side, so they belong to every key; closure pruning and full subset enumeration both give the single minimal key `{S2Job, S2Unit}`.

## Exercise 60 - sample invocation

```text
printf '%s\n' \
  'ATTRS: S2Job,S2Unit,S2Lead,S2Area' \
  'FD: S2Job -> S2Unit,S2Lead' \
  'FD: S2Unit -> S2Area' \
  'FD: S2Job,S2Lead -> S2Area' \
  'FD: S2Job -> S2Unit' | python3 exercise_60.py
```

Result: the duplicate `S2Job -> S2Unit` is removed, `S2Lead` is extraneous in `S2Job,S2Lead -> S2Area`, and the resulting `S2Job -> S2Area` is redundant. The minimal cover is `{S2Job -> S2Unit, S2Job -> S2Lead, S2Unit -> S2Area}`, and both closure directions are verified.

## Exercise 61 - sample invocation

```text
printf '%s\n' \
  'ATTRS: S2Job,S2Unit,S2Lead,S2Area,S2Period' \
  'FD: S2Job -> S2Lead' \
  'FD: S2Lead -> S2Area' \
  'FD: S2Job,S2Unit -> S2Period' | python3 exercise_61.py
```

Result: sole candidate key `{S2Job, S2Unit}`; highest normal form 1NF because `S2Job` alone determines nonprime `S2Lead`; lossless dependency-preserving BCNF decomposition `R1(S2Job,S2Lead)`, `R2(S2Lead,S2Area)`, `R3(S2Job,S2Unit,S2Period)`.

## Exercise 63 - sample invocation

```text
printf '%s\n' \
  'ATTRS: S2Job,S2Unit,S2Lead' \
  'FD: S2Job -> S2Unit' \
  'FD: S2Unit -> S2Lead' \
  'DECOMP: S2Job,S2Unit | S2Job,S2Lead' | python3 exercise_63.py
```

Result: projected FDs are `S2Job -> S2Unit` and `S2Job -> S2Lead`; the missing implication is `S2Unit -> S2Lead`, so the decomposition does not preserve dependencies.

## Exercise 64 - sample invocation

```text
printf '%s\n' \
  'RESOURCE: S28' \
  'CAPABILITIES: Fast,Secure' \
  'REGIONS: East,South' | python3 exercise_64.py
```

Result: four tuples `(S28,Fast,East)`, `(S28,Fast,South)`, `(S28,Secure,East)`, `(S28,Secure,South)`; complementary MVDs `Resource ->> Capability` and `Resource ->> Region`; 4NF split into `RESOURCE_CAPABILITY(Resource,Capability)` and `RESOURCE_REGION(Resource,Region)`.

## Empty-input check

For any of the programs, `python3 exercise_58.py < /dev/null` prints:

```text
EMPTY INPUT
No attributes, dependencies or starting sets were supplied; no closure can be computed.
```

Each other program prints its own labelled `EMPTY INPUT` message naming the quantities that could not be computed.
