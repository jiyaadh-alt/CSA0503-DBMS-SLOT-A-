import sys


def read_lines():
    return [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]


def split_list(value):
    return [item.strip() for item in value.split(",") if item.strip()]


def parse(lines):
    attrs = []
    fds = []
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().upper()
        value = value.strip()
        if key == "ATTRS":
            attrs = split_list(value)
        elif key == "FD" and "->" in value:
            left, right = value.split("->", 1)
            lhs = tuple(split_list(left))
            rhs = tuple(split_list(right))
            if lhs and rhs:
                fds.append((lhs, rhs))
    return attrs, fds


def fmt(items):
    return "{" + ", ".join(items) + "}"


def fmt_fd(fd):
    return ", ".join(fd[0]) + " -> " + ", ".join(fd[1])


def closure(start, fds):
    current = list(start)
    changed = True
    while changed:
        changed = False
        for fd in fds:
            if all(item in current for item in fd[0]):
                added = [item for item in fd[1] if item not in current]
                if added:
                    current.extend(added)
                    changed = True
    return current


def ordered(items, attrs):
    return [item for item in attrs if item in items]


def main():
    lines = read_lines()
    if not lines:
        print("EMPTY INPUT")
        print("No attributes or dependencies were supplied; no minimal cover can be computed.")
        return
    attrs, original = parse(lines)
    if not attrs or not original:
        print("EMPTY INPUT")
        print("A labelled ATTRS line and at least one FD line are required.")
        return
    print("EXERCISE 60 - MINIMAL COVER WITH CLOSURE EQUIVALENCE PROOF")
    print("Attributes: " + ", ".join(attrs))
    print("Explicit dependencies:")
    for fd in original:
        print("  " + fmt_fd(fd))
    print("")
    print("STEP 1 - SPLIT RIGHT-HAND SIDES")
    split = []
    for fd in original:
        if len(fd[1]) == 1:
            print("  " + fmt_fd(fd) + " already atomic")
        else:
            print("  " + fmt_fd(fd) + " becomes " + " ; ".join(", ".join(fd[0]) + " -> " + item for item in fd[1]))
        for item in fd[1]:
            split.append((fd[0], (item,)))
    print("")
    print("STEP 2 - REMOVE DUPLICATE DEPENDENCIES")
    deduped = []
    for fd in split:
        if fd in deduped:
            print("  Removed duplicate: " + fmt_fd(fd))
        else:
            deduped.append(fd)
    print("  Retained: " + " ; ".join(fmt_fd(fd) for fd in deduped))
    print("")
    print("STEP 3 - REMOVE EXTRANEOUS LEFT-HAND SIDE ATTRIBUTES")
    current = [(tuple(lhs), tuple(rhs)) for lhs, rhs in deduped]
    for index in range(len(current)):
        lhs, rhs = current[index]
        if len(lhs) < 2:
            continue
        for item in list(lhs):
            trial = tuple(other for other in lhs if other != item)
            result = closure(trial, current)
            if all(part in result for part in rhs):
                print("  LHS PRUNE " + fmt_fd((lhs, rhs)) + ": drop " + item + " because closure(" + fmt(list(trial)) + ") = " + fmt(ordered(result, attrs)) + " contains " + fmt(list(rhs)))
                current[index] = (trial, rhs)
                lhs = trial
            else:
                print("  LHS KEEP " + item + " in " + fmt_fd((lhs, rhs)) + ": closure(" + fmt(list(trial)) + ") = " + fmt(ordered(result, attrs)) + " lacks " + fmt(list(rhs)))
    print("")
    print("STEP 4 - REMOVE REDUNDANT DEPENDENCIES")
    index = 0
    while index < len(current):
        lhs, rhs = current[index]
        rest = current[:index] + current[index + 1:]
        result = closure(lhs, rest)
        if all(part in result for part in rhs):
            print("  REDUNDANT " + fmt_fd((lhs, rhs)) + ": closure(" + fmt(list(lhs)) + ") under remaining FDs = " + fmt(ordered(result, attrs)))
            current.pop(index)
        else:
            print("  KEPT " + fmt_fd((lhs, rhs)) + ": closure(" + fmt(list(lhs)) + ") under remaining FDs = " + fmt(ordered(result, attrs)))
            index += 1
    cover = [(tuple(lhs), tuple(rhs)) for lhs, rhs in current]
    print("")
    print("MINIMAL COVER")
    if not cover:
        print("  (empty)")
    for fd in cover:
        print("  " + fmt_fd(fd))
    print("")
    print("STEP 5 - EQUIVALENCE PROOF BY CLOSURES")
    equivalent = True
    print("  Original dependency implied by minimal cover:")
    for fd in original:
        result = closure(fd[0], cover)
        holds = all(part in result for part in fd[1])
        equivalent = equivalent and holds
        print("    " + fmt_fd(fd) + " -> closure(" + fmt(list(fd[0])) + ") under cover = " + fmt(ordered(result, attrs)) + " : " + ("YES" if holds else "NO"))
    print("  Minimal-cover dependency implied by original set:")
    for fd in cover:
        result = closure(fd[0], original)
        holds = all(part in result for part in fd[1])
        equivalent = equivalent and holds
        print("    " + fmt_fd(fd) + " -> closure(" + fmt(list(fd[0])) + ") under original = " + fmt(ordered(result, attrs)) + " : " + ("YES" if holds else "NO"))
    print("  EQUIVALENT SETS: " + ("YES" if equivalent else "NO"))


if __name__ == "__main__":
    main()
