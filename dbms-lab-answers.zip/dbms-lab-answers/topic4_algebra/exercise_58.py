import sys


def read_lines():
    return [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]


def split_list(value):
    return [item.strip() for item in value.split(",") if item.strip()]


def parse(lines):
    attrs = []
    fds = []
    starts = []
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().upper()
        value = value.strip()
        if key == "ATTRS":
            attrs = split_list(value)
        elif key == "FD" and "->" in value:
            left, right = value.split("->", 1)
            lhs = tuple(split_list(left))
            rhs = tuple(split_list(right))
            if lhs and rhs:
                fds.append((lhs, rhs))
        elif key.startswith("START"):
            starts.append((key, tuple(split_list(value))))
    return attrs, fds, starts


def fmt(items):
    return "{" + ", ".join(items) + "}"


def fmt_fd(fd):
    return ", ".join(fd[0]) + " -> " + ", ".join(fd[1])


def closure(start, fds, attrs):
    current = list(start)
    fired = []
    changed = True
    while changed:
        changed = False
        for fd in fds:
            if all(item in current for item in fd[0]):
                added = [item for item in fd[1] if item not in current]
                if added:
                    current.extend(added)
                    fired.append((fd, added, list(current)))
                    changed = True
    order = {item: index for index, item in enumerate(attrs)}
    current.sort(key=lambda item: order.get(item, len(attrs)))
    return current, fired


def main():
    lines = read_lines()
    if not lines:
        print("EMPTY INPUT")
        print("No attributes, dependencies or starting sets were supplied; no closure can be computed.")
        return
    attrs, fds, starts = parse(lines)
    if not attrs or not fds or not starts:
        print("EMPTY INPUT")
        print("A labelled ATTRS line, at least one FD line and a START line are required.")
        return
    print("EXERCISE 58 - ATTRIBUTE CLOSURE WITH FIRED DEPENDENCIES")
    print("Attributes: " + ", ".join(attrs))
    print("Explicit dependencies:")
    for index, fd in enumerate(fds, 1):
        print("  FD " + str(index) + ": " + fmt_fd(fd))
    print("")
    for number, (label, start) in enumerate(starts[:2], 1):
        final, fired = closure(start, fds, attrs)
        print("OUTPUT " + str(number) + " - " + label + ": " + fmt(list(start)))
        print("  Initial closure: " + fmt(list(start)))
        if not fired:
            print("  No dependency fires.")
        else:
            for fd, added, snapshot in fired:
                print("  FIRED: " + fmt_fd(fd) + " | added " + fmt(added) + " | closure " + fmt(snapshot))
            print("  No further dependency fires.")
        print("  Final closure: " + fmt(final))
        print("")


if __name__ == "__main__":
    main()
