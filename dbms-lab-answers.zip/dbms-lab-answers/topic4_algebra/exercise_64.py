import sys


def read_lines():
    return [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]


def split_list(value):
    return [item.strip() for item in value.split(",") if item.strip()]


def parse(lines):
    resource = ""
    capabilities = []
    regions = []
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().upper()
        value = value.strip()
        if key in ("RESOURCE", "RESOURCE_ID", "RESOURCEID"):
            resource = value
        elif key in ("CAPABILITIES", "CAPS", "CAPABILITY"):
            capabilities = split_list(value)
        elif key in ("REGIONS", "REGION"):
            regions = split_list(value)
    return resource, capabilities, regions


def main():
    lines = read_lines()
    if not lines:
        print("EMPTY INPUT")
        print("No resource, capability set or region set was supplied; no MVD tuples can be enumerated.")
        return
    resource, capabilities, regions = parse(lines)
    if not resource or not capabilities or not regions:
        print("EMPTY INPUT")
        print("A RESOURCE line, a CAPABILITIES line and a REGIONS line are required.")
        return
    print("EXERCISE 64 - MVD ENUMERATION AND 4NF SPLIT")
    print("Resource: " + resource)
    print("Capabilities (explicit input): " + ", ".join(capabilities))
    print("Regions (explicit input): " + ", ".join(regions))
    print("")
    tuples = [(resource, capability, region) for capability in capabilities for region in regions]
    print("ENUMERATED TUPLES HOSPITALITY_RESOURCE(Resource, Capability, Region)")
    for item in tuples:
        print("  (" + item[0] + ", " + item[1] + ", " + item[2] + ")")
    print("  Tuple count: " + str(len(tuples)))
    print("")
    print("COMPLEMENTARY MULTIVALUED DEPENDENCIES")
    print("  HOSPITALITY_RESOURCE: Resource ->> Capability")
    print("  HOSPITALITY_RESOURCE: Resource ->> Region")
    print("  For each resource the capability set is independent of the region set, so every")
    print("  listed capability is paired with every listed region.")
    print("  The MVDs are complementary: {Capability} and {Region} are disjoint and their union")
    print("  with the determinant {Resource} is the whole schema {Resource, Capability, Region}.")
    print("")
    print("4NF SPLIT")
    cap_rows = list(dict.fromkeys((resource, capability) for capability in capabilities))
    reg_rows = list(dict.fromkeys((resource, region) for region in regions))
    print("  RESOURCE_CAPABILITY(Resource, Capability): " + ", ".join("(" + row[0] + ", " + row[1] + ")" for row in cap_rows))
    print("  RESOURCE_REGION(Resource, Region): " + ", ".join("(" + row[0] + ", " + row[1] + ")" for row in reg_rows))
    print("  Rows in RESOURCE_CAPABILITY: " + str(len(cap_rows)))
    print("  Rows in RESOURCE_REGION: " + str(len(reg_rows)))
    rebuilt = []
    for cap_row in cap_rows:
        for reg_row in reg_rows:
            if cap_row[0] == reg_row[0]:
                rebuilt.append((cap_row[0], cap_row[1], reg_row[1]))
    print("  Natural join row count: " + str(len(rebuilt)))
    print("  Join reconstructs all enumerated tuples: " + ("YES" if sorted(rebuilt) == sorted(tuples) else "NO"))


if __name__ == "__main__":
    main()
