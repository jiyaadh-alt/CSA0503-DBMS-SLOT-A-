# Exercise 56 - Safe Relational Calculus with Quantifier Scopes

Relation signatures used below (from `sql/00_baseline.sql`):

```text
HOST(HostID, HostName, HotelID, Grade, Salary, JoinDate)
GUEST(GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost)
RESERVATION(GuestID, PackageID, Term, ReviewScore)
```

A calculus expression is safe when every variable is range-restricted by a relation atom inside its quantifier scope (or is a free variable bound by a relation atom). The active-domain values of each atom supply the variable's domain, so no infinite or invented values can be produced.

## (a) Host staff paid below 82000

### Tuple relational calculus

```text
{ t | HOST(t) AND t.Salary < 82000 }
```

Quantifier scope: there are no quantifiers. `t` is the single free tuple variable and its range is fixed by the atom `HOST(t)`; the predicate `t.Salary < 82000` filters that range. This is safe because the only variables used are components of the range-restricted tuple `t`.

### Domain relational calculus

```text
{ <hid, hname, hhotel, hgrade, hsalary, hjoin> |
    HOST(hid, hname, hhotel, hgrade, hsalary, hjoin) AND hsalary < 82000 }
```

Quantifier scope: no quantifiers. All six scalar variables `hid`, `hname`, `hhotel`, `hgrade`, `hsalary`, `hjoin` are bound by the single atom `HOST(...)`, so each draws its values from the corresponding column of HOST. The expression is safe.

### Verifying SQL

```sql
SELECT DISTINCT HostID, HostName, HotelID, Grade, Salary, JoinDate
FROM HOST
WHERE Salary < 82000;
```

Verified result: 123 (Ms. Tara, 80000), 222 (Mr. Keshav, 74000), 322 (Mr. Sameer, 71000).

## (b) Guest records with at least one link and no ReviewScore below 68

### Tuple relational calculus

```text
{ t | GUEST(t)
      AND (EXISTS r)( RESERVATION(r) AND r.GuestID = t.GuestID )
      AND (NOT EXISTS s)( RESERVATION(s) AND s.GuestID = t.GuestID AND s.ReviewScore < 68 ) }
```

Quantifier scopes:

- `t` is free and range-restricted by `GUEST(t)`.
- `r` is existential; its scope is exactly `RESERVATION(r) AND r.GuestID = t.GuestID`. The atom `RESERVATION(r)` supplies its active domain.
- `s` is existentially quantified inside the negation; its scope is exactly `RESERVATION(s) AND s.GuestID = t.GuestID AND s.ReviewScore < 68`. The atom `RESERVATION(s)` supplies its active domain.

Safety: `r` and `s` never occur outside their own scoped formulas, every quantified variable occurs in a relation atom of that scope, and the only free variables are components of the range-restricted `t`. The expression is therefore safe and equivalent to requiring that all linked scores are at least 68.

### Domain relational calculus

```text
{ <gid, gname, ghotel, ggender, gbirth, gcity, gmerit, ghost> |
    GUEST(gid, gname, ghotel, ggender, gbirth, gcity, gmerit, ghost)
    AND (EXISTS rid, pid, term, score)(
          RESERVATION(rid, pid, term, score) AND rid = gid )
    AND (NOT EXISTS rid2, pid2, term2, score2)(
          RESERVATION(rid2, pid2, term2, score2) AND rid2 = gid AND score2 < 68 ) }
```

Quantifier scopes:

- The eight scalar variables of the result tuple are bound by the single `GUEST(...)` atom, which is the range restriction of the whole expression.
- The existential group `(rid, pid, term, score)` is bound within `RESERVATION(rid, pid, term, score) AND rid = gid`; no member of this group appears in the second quantified formula.
- The group `(rid2, pid2, term2, score2)` is bound within `RESERVATION(rid2, pid2, term2, score2) AND rid2 = gid AND score2 < 68` under the negation; `gid` is a free variable there, supplied by the GUEST atom.

Safety: every variable is bound by a relation atom in its own quantifier scope, so the expression is domain-independent. No variable is existentially quantified without an accompanying RESERVATION atom.

### Verifying SQL

```sql
SELECT DISTINCT g.GuestID, g.GuestName, g.HotelID, g.Gender, g.BirthDate, g.City, g.Merit, g.AssignedHost
FROM GUEST g
WHERE EXISTS (SELECT 1 FROM RESERVATION r WHERE r.GuestID = g.GuestID)
  AND NOT EXISTS (SELECT 1 FROM RESERVATION s WHERE s.GuestID = g.GuestID AND s.ReviewScore < 68);
```

Verified result: 1201 (Abeer), 1202 (Bina), 1204 (Diya), 1206 (Fara), 1208 (Hina), 1210 (Juhi). Guests 1203, 1205, 1207 and 1209 each have at least one score below 68. All ReviewScore values in the baseline are non-null; under SQL three-valued logic a hypothetical NULL would not satisfy `ReviewScore < 68`, matching the two-valued calculus reading that NULL is not a value strictly below 68.
