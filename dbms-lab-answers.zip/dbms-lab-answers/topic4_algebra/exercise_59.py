import sys
from itertools import combinations


def read_lines():
    return [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]


def split_list(value):
    return [item.strip() for item in value.split(",") if item.strip()]


def parse(lines):
    attrs = []
    fds = []
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().upper()
        value = value.strip()
        if key == "ATTRS":
            attrs = split_list(value)
        elif key == "FD" and "->" in value:
            left, right = value.split("->", 1)
            lhs = tuple(split_list(left))
            rhs = tuple(split_list(right))
            if lhs and rhs:
                fds.append((lhs, rhs))
    return attrs, fds


def fmt(items):
    return "{" + ", ".join(items) + "}"


def fmt_fd(fd):
    return ", ".join(fd[0]) + " -> " + ", ".join(fd[1])


def closure(start, fds, attrs):
    current = list(start)
    fired = []
    changed = True
    while changed:
        changed = False
        for fd in fds:
            if all(item in current for item in fd[0]):
                added = [item for item in fd[1] if item not in current]
                if added:
                    current.extend(added)
                    fired.append((fd, added))
                    changed = True
    order = {item: index for index, item in enumerate(attrs)}
    current.sort(key=lambda item: order.get(item, len(attrs)))
    return current, fired


def minimal_keys(attrs, fds):
    keys = []
    for size in range(1, len(attrs) + 1):
        for subset in combinations(attrs, size):
            result, fired = closure(list(subset), fds, attrs)
            if set(result) != set(attrs):
                continue
            if any(set(keyset).issubset(subset) for keyset in keys):
                continue
            keys.append(tuple(item for item in attrs if item in subset))
    return keys


def main():
    lines = read_lines()
    if not lines:
        print("EMPTY INPUT")
        print("No attributes or dependencies were supplied; no minimal keys can be enumerated.")
        return
    attrs, fds = parse(lines)
    if not attrs or not fds:
        print("EMPTY INPUT")
        print("A labelled ATTRS line and at least one FD line are required.")
        return
    all_attrs = set(attrs)
    rhs_attrs = set()
    for fd in fds:
        rhs_attrs.update(fd[1])
    forced = [item for item in attrs if item not in rhs_attrs]
    keys = minimal_keys(attrs, fds)
    print("EXERCISE 59 - MINIMAL KEYS BY CLOSURE PRUNING")
    print("Attributes: " + ", ".join(attrs))
    print("Explicit dependencies:")
    for fd in fds:
        print("  " + fmt_fd(fd))
    print("")
    print("ATTRIBUTES ABSENT FROM EVERY RIGHT-HAND SIDE")
    print("  Never produced on a right side: " + fmt(forced))
    for item in forced:
        print("  " + item + " must belong to every key: any set without it has a closure without it,")
        print("  because no dependency can ever add " + item + " to a closure.")
    print("")
    print("CLOSURE PRUNING FROM THE FULL ATTRIBUTE SET")
    current = list(attrs)
    print("  Start: " + fmt(current))
    for item in list(attrs):
        if item not in current:
            continue
        trial = [other for other in current if other != item]
        result, fired = closure(trial, fds, attrs)
        covers = set(result) == all_attrs
        print("  Remove " + item + ": closure(" + fmt(trial) + ") = " + fmt(result) + " -> " + ("REMOVED" if covers else "KEPT"))
        for fd, added in fired:
            print("    fired " + fmt_fd(fd) + ", added " + fmt(added))
        if covers:
            current = trial
    pruned, pruned_fired = closure(current, fds, attrs)
    print("  Pruned candidate: " + fmt(current) + " with closure " + fmt(pruned))
    for fd, added in pruned_fired:
        print("    fired " + fmt_fd(fd) + ", added " + fmt(added))
    print("")
    print("ALL MINIMAL KEYS (enumerated by increasing subset size)")
    if not keys:
        print("  No key exists for the supplied dependencies.")
    for key in keys:
        result, fired = closure(list(key), fds, attrs)
        print("  KEY " + fmt(list(key)) + " closure: " + fmt(result))
        for fd, added in fired:
            print("    fired " + fmt_fd(fd) + ", added " + fmt(added))
    print("  Minimal key count: " + str(len(keys)))


if __name__ == "__main__":
    main()
