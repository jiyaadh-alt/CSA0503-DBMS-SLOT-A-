import sys
from itertools import combinations


def read_lines():
    return [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]


def split_list(value):
    return [item.strip() for item in value.split(",") if item.strip()]


def parse(lines):
    attrs = []
    fds = []
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().upper()
        value = value.strip()
        if key == "ATTRS":
            attrs = split_list(value)
        elif key == "FD" and "->" in value:
            left, right = value.split("->", 1)
            lhs = tuple(split_list(left))
            rhs = tuple(split_list(right))
            if lhs and rhs:
                fds.append((lhs, rhs))
    return attrs, fds


def fmt(items):
    return "{" + ", ".join(items) + "}"


def fmt_fd(fd):
    return ", ".join(fd[0]) + " -> " + ", ".join(fd[1])


def ordered(items, attrs):
    return [item for item in attrs if item in set(items)]


def closure(start, fds):
    current = list(start)
    changed = True
    while changed:
        changed = False
        for fd in fds:
            if all(item in current for item in fd[0]):
                added = [item for item in fd[1] if item not in current]
                if added:
                    current.extend(added)
                    changed = True
    return current


def minimal_keys(attrs, fds):
    keys = []
    for size in range(1, len(attrs) + 1):
        for subset in combinations(attrs, size):
            if set(closure(subset, fds)) != set(attrs):
                continue
            if any(set(keyset).issubset(subset) for keyset in keys):
                continue
            keys.append(tuple(item for item in attrs if item in subset))
    return keys


def minimal_cover(fds):
    split = []
    for lhs, rhs in fds:
        for item in rhs:
            candidate = (lhs, (item,))
            if candidate not in split:
                split.append(candidate)
    current = [(tuple(lhs), tuple(rhs)) for lhs, rhs in split]
    for index in range(len(current)):
        lhs, rhs = current[index]
        if len(lhs) < 2:
            continue
        for item in list(lhs):
            trial = tuple(other for other in lhs if other != item)
            result = closure(trial, current)
            if all(part in result for part in rhs):
                current[index] = (trial, rhs)
                lhs = trial
    index = 0
    while index < len(current):
        lhs, rhs = current[index]
        rest = current[:index] + current[index + 1:]
        result = closure(lhs, rest)
        if all(part in result for part in rhs):
            current.pop(index)
        else:
            index += 1
    return [(tuple(lhs), tuple(rhs)) for lhs, rhs in current]


def highest_normal_form(attrs, fds, keys):
    all_attrs = set(attrs)
    prime = set()
    for key in keys:
        prime.update(key)
    nonprime = [item for item in attrs if item not in prime]
    partial = False
    for key in keys:
        if len(key) < 2:
            continue
        for size in range(1, len(key)):
            for subset in combinations(key, size):
                if any(item in nonprime for item in closure(subset, fds)):
                    partial = True
    if partial:
        return "1NF", prime, nonprime
    def is_superkey(lhs):
        return set(closure(lhs, fds)) == all_attrs
    if any(not is_superkey(lhs) and any(item in nonprime for item in rhs) for lhs, rhs in fds):
        return "2NF", prime, nonprime
    if any(not is_superkey(lhs) for lhs, rhs in fds):
        return "3NF", prime, nonprime
    return "BCNF", prime, nonprime


def projected_fds(schema, fds):
    result = []
    for size in range(1, len(schema) + 1):
        for subset in combinations(schema, size):
            restricted = [item for item in schema if item in closure(subset, fds)]
            added = [item for item in restricted if item not in subset]
            if added:
                result.append((tuple(subset), tuple(added)))
    return result


def chase(attrs, fds, schemas):
    symbols = []
    for index, schema in enumerate(schemas):
        row = []
        for position, attribute in enumerate(attrs):
            if attribute in schema:
                row.append("a" + str(position + 1))
            else:
                row.append("b" + str(index + 1) + str(position + 1))
        symbols.append(row)
    steps = []
    changed = True
    while changed:
        changed = False
        for fd in fds:
            xpos = [attrs.index(item) for item in fd[0] if item in attrs]
            ypos = [attrs.index(item) for item in fd[1] if item in attrs]
            if not xpos or not ypos:
                continue
            for i in range(len(symbols)):
                for k in range(i + 1, len(symbols)):
                    if not all(symbols[i][p] == symbols[k][p] for p in xpos):
                        continue
                    for p in ypos:
                        si = symbols[i][p]
                        sk = symbols[k][p]
                        if si == sk:
                            continue
                        if si.startswith("a"):
                            target = si
                        elif sk.startswith("a"):
                            target = sk
                        else:
                            target = min(si, sk)
                        if si != target:
                            steps.append((fd, i, k, attrs[p], si, target))
                            symbols[i][p] = target
                        if sk != target:
                            steps.append((fd, k, i, attrs[p], sk, target))
                            symbols[k][p] = target
                        changed = True
    full = [i for i, row in enumerate(symbols) if all(row[j] == "a" + str(j + 1) for j in range(len(attrs)))]
    return symbols, steps, full


def initial_tableau(attrs, schemas):
    rows = []
    for index, schema in enumerate(schemas):
        rows.append(["a" + str(position + 1) if attribute in schema else "b" + str(index + 1) + str(position + 1) for position, attribute in enumerate(attrs)])
    return rows


def print_tableau(attrs, symbols, schemas):
    width = max([len(item) for item in attrs] + [len(cell) for row in symbols for cell in row] + [4]) + 2
    print("       " + "".join(item.ljust(width) for item in attrs))
    for index, row in enumerate(symbols):
        print("  R" + str(index + 1) + "   " + "".join(cell.ljust(width) for cell in row) + " " + fmt(list(schemas[index])))


def main():
    lines = read_lines()
    if not lines:
        print("EMPTY INPUT")
        print("No attributes or dependencies were supplied; no keys, normal form or decomposition can be computed.")
        return
    attrs, fds = parse(lines)
    if not attrs or not fds:
        print("EMPTY INPUT")
        print("A labelled ATTRS line and at least one FD line are required.")
        return
    keys = minimal_keys(attrs, fds)
    level, prime, nonprime = highest_normal_form(attrs, fds, keys)
    cover = minimal_cover(fds)
    print("EXERCISE 61 - KEYS, NORMAL FORM AND BCNF DECOMPOSITION")
    print("Attributes: " + ", ".join(attrs))
    print("Explicit dependencies:")
    for fd in fds:
        print("  " + fmt_fd(fd))
    print("")
    print("CANDIDATE KEYS")
    for key in keys:
        print("  " + fmt(list(key)) + " -> closure " + fmt(ordered(closure(key, fds), attrs)))
    print("  Prime attributes: " + fmt(sorted(prime, key=attrs.index)))
    print("  Nonprime attributes: " + fmt(nonprime))
    print("")
    print("HIGHEST NORMAL FORM: " + level)
    if level == "1NF":
        print("  Proper subset S2Job of key S2Job,S2Unit determines nonprime attributes, so 2NF fails.")
    print("")
    print("MINIMAL COVER")
    for fd in cover:
        print("  " + fmt_fd(fd))
    print("")
    groups = []
    for lhs, rhs in cover:
        target = None
        for group in groups:
            if group[0] == lhs:
                target = group
                break
        if target is None:
            groups.append((lhs, list(rhs)))
        else:
            for item in rhs:
                if item not in target[1]:
                    target[1].append(item)
    schemas = [tuple(ordered(set(lhs) | set(rhs), attrs)) for lhs, rhs in groups]
    for key in keys:
        if not any(all(item in schema for item in key) for schema in schemas):
            schemas.append(tuple(ordered(key, attrs)))
            break
    print("DEPENDENCY-PRESERVING BCNF DECOMPOSITION")
    for index, schema in enumerate(schemas, 1):
        print("  R" + str(index) + "(" + ", ".join(schema) + ")")
    print("")
    symbols, steps, full = chase(attrs, fds, schemas)
    print("LOSSLESSNESS CHASE")
    print("  Initial tableau:")
    print_tableau(attrs, initial_tableau(attrs, schemas), schemas)
    print("  Equalities forced by dependencies:")
    if not steps:
        print("    none")
    for fd, i, k, attribute, old, new in steps:
        print("    " + fmt_fd(fd) + ": R" + str(i + 1) + "." + attribute + " " + old + " -> " + new + " from R" + str(k + 1))
    print("  Final tableau:")
    print_tableau(attrs, symbols, schemas)
    if full:
        print("  Fully distinguished row: " + ", ".join("R" + str(index + 1) for index in full))
    else:
        print("  Fully distinguished row: none")
    print("  LOSSLESS: " + ("YES" if full else "NO"))
    print("")
    union = []
    for schema in schemas:
        for fd in projected_fds(schema, fds):
            if fd not in union:
                union.append(fd)
    print("PROJECTED DEPENDENCIES USED FOR PRESERVATION CHECK")
    for fd in union:
        print("  " + fmt_fd(fd))
    preserved = True
    print("PRESERVATION CHECK")
    for fd in fds:
        result = closure(fd[0], union)
        holds = all(item in result for item in fd[1])
        preserved = preserved and holds
        print("  " + fmt_fd(fd) + " closure under projections = " + fmt(ordered(result, attrs)) + " : " + ("YES" if holds else "NO"))
    print("  DEPENDENCY PRESERVING: " + ("YES" if preserved else "NO"))
    print("  RESULT: " + ("lossless and dependency-preserving BCNF decomposition" if full and preserved else "requested properties not both achieved"))


if __name__ == "__main__":
    main()
