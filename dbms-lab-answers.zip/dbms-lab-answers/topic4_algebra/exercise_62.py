import sys


def read_lines():
    return [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]


def split_list(value):
    return [item.strip() for item in value.split(",") if item.strip()]


def parse(lines):
    attrs = []
    fds = []
    decomps = []
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().upper()
        value = value.strip()
        if key == "ATTRS":
            attrs = split_list(value)
        elif key == "FD" and "->" in value:
            left, right = value.split("->", 1)
            lhs = tuple(split_list(left))
            rhs = tuple(split_list(right))
            if lhs and rhs:
                fds.append((lhs, rhs))
        elif key.startswith("DECOMP"):
            parts = value.split("|")
            decomps.append(tuple(tuple(item for item in attrs if item in split_list(part)) for part in parts))
    return attrs, fds, decomps


def fmt(items):
    return "{" + ", ".join(items) + "}"


def fmt_fd(fd):
    return ", ".join(fd[0]) + " -> " + ", ".join(fd[1])


def chase(attrs, fds, schemas):
    symbols = []
    for index, schema in enumerate(schemas):
        row = []
        for position, attribute in enumerate(attrs):
            if attribute in schema:
                row.append("a" + str(position + 1))
            else:
                row.append("b" + str(index + 1) + str(position + 1))
        symbols.append(row)
    steps = []
    changed = True
    while changed:
        changed = False
        for fd in fds:
            xpos = [attrs.index(item) for item in fd[0] if item in attrs]
            ypos = [attrs.index(item) for item in fd[1] if item in attrs]
            if not xpos or not ypos:
                continue
            for i in range(len(symbols)):
                for k in range(i + 1, len(symbols)):
                    if not all(symbols[i][p] == symbols[k][p] for p in xpos):
                        continue
                    for p in ypos:
                        si = symbols[i][p]
                        sk = symbols[k][p]
                        if si == sk:
                            continue
                        if si.startswith("a"):
                            target = si
                        elif sk.startswith("a"):
                            target = sk
                        else:
                            target = min(si, sk)
                        if si != target:
                            steps.append((fd, i, k, attrs[p], si, target))
                            symbols[i][p] = target
                        if sk != target:
                            steps.append((fd, k, i, attrs[p], sk, target))
                            symbols[k][p] = target
                        changed = True
    full = [i for i, row in enumerate(symbols) if all(row[j] == "a" + str(j + 1) for j in range(len(attrs)))]
    return symbols, steps, full


def initial_tableau(attrs, schemas):
    rows = []
    for index, schema in enumerate(schemas):
        rows.append(["a" + str(position + 1) if attribute in schema else "b" + str(index + 1) + str(position + 1) for position, attribute in enumerate(attrs)])
    return rows


def print_tableau(attrs, symbols, schemas):
    width = max([len(item) for item in attrs] + [len(cell) for row in symbols for cell in row] + [4]) + 2
    print("       " + "".join(item.ljust(width) for item in attrs))
    for index, row in enumerate(symbols):
        print("  R" + str(index + 1) + "   " + "".join(cell.ljust(width) for cell in row) + " " + fmt(list(schemas[index])))


def main():
    lines = read_lines()
    if not lines:
        print("EMPTY INPUT")
        print("No attributes, dependencies or decompositions were supplied; no chase can be run.")
        return
    attrs, fds, decomps = parse(lines)
    if not attrs or not fds or len(decomps) < 2:
        print("EMPTY INPUT")
        print("A labelled ATTRS line, at least one FD line and two DECOMP lines are required.")
        return
    print("EXERCISE 62 - PROGRAMMED CHASE FOR LOSSLESS JOIN")
    print("Attributes: " + ", ".join(attrs))
    print("Explicit dependencies:")
    for fd in fds:
        print("  " + fmt_fd(fd))
    print("")
    for number, schemas in enumerate(decomps[:2], 1):
        symbols, steps, full = chase(attrs, fds, schemas)
        print("OUTPUT " + str(number) + " - decomposition: " + " ; ".join(fmt(list(schema)) for schema in schemas))
        print("  Initial tableau:")
        print_tableau(attrs, initial_tableau(attrs, schemas), schemas)
        print("  Equalities forced:")
        if not steps:
            print("    none")
        for fd, i, k, attribute, old, new in steps:
            agreement = ", ".join(item for item in fd[0])
            print("    " + fmt_fd(fd) + ": R" + str(i + 1) + " and R" + str(k + 1) + " agree on " + agreement + "; R" + str(i + 1) + "." + attribute + " " + old + " -> " + new + " from R" + str(k + 1))
        print("  Final tableau:")
        print_tableau(attrs, symbols, schemas)
        if full:
            print("  Fully distinguished row: " + ", ".join("R" + str(index + 1) for index in full))
        else:
            print("  Fully distinguished row: none")
        print("  LOSSLESS: " + ("YES" if full else "NO"))
        print("")


if __name__ == "__main__":
    main()
