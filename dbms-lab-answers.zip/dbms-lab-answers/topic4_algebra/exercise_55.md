# Exercise 55 - Relational Algebra and Equivalent SQL

All algebra results are **sets** (duplicate rows eliminated). The SQL statements therefore use `DISTINCT` wherever a projection could repeat a row. Relation names and attribute names follow `sql/00_baseline.sql`.

## (a) Guest records in hotel S2C with Merit < 7.94

Algebra:

```text
RESULT_a <- sigma_{HotelID = 'S2C' AND Merit < 7.94}(GUEST)
```

SQL:

```sql
SELECT DISTINCT GuestID, GuestName, HotelID, Gender, BirthDate, City, Merit, AssignedHost
FROM GUEST
WHERE HotelID = 'S2C' AND Merit < 7.94;
```

Verified result on the baseline: guest 1206 (Fara, Merit 7.34) and guest 1207 (Girish, Merit 5.89). Guest 1210 (Juhi, 7.99) is excluded by the Merit condition.

## (b) Package titles linked to guest records from Hubballi

Algebra, evaluated step by step:

```text
HUB    <- sigma_{City = 'Hubballi'}(GUEST)
LINKS  <- pi_{GuestID}(HUB) join_{GuestID} RESERVATION
PACKS  <- pi_{PackageID}(LINKS) join_{PackageID} PACKAGE
RESULT_b <- pi_{Title}(PACKS)
```

SQL:

```sql
SELECT DISTINCT p.Title
FROM PACKAGE p
JOIN RESERVATION r ON p.PackageID = r.PackageID
JOIN GUEST g ON r.GuestID = g.GuestID
WHERE g.City = 'Hubballi';
```

Verified result on the baseline: `City Break`, `Business Stay`, `Weekend Stay`, `Beach Escape`. Hubballi guests are 1204 (Diya) and 1208 (Hina); their links touch S201, S204, S202, S203. The final projection removes repeated `City Break` rows, giving set semantics.

## (c) Guest records linked to both S206 and S207

Algebra:

```text
R206     <- pi_{GuestID}(sigma_{PackageID = 'S206'}(RESERVATION))
R207     <- pi_{GuestID}(sigma_{PackageID = 'S207'}(RESERVATION))
BOTH     <- R206 intersect R207
RESULT_c <- GUEST join_{GuestID} BOTH
```

SQL:

```sql
SELECT DISTINCT g.GuestID, g.GuestName, g.HotelID, g.Gender, g.BirthDate, g.City, g.Merit, g.AssignedHost
FROM GUEST g
WHERE g.GuestID IN (SELECT r.GuestID FROM RESERVATION r WHERE r.PackageID = 'S206')
  AND g.GuestID IN (SELECT r.GuestID FROM RESERVATION r WHERE r.PackageID = 'S207');
```

Verified result on the baseline: guest 1207 (Girish), the only guest with links to both offerings. S206 is linked to 1206, 1207 and 1210; S207 is linked only to 1207, so the intersection is `{1207}`.
