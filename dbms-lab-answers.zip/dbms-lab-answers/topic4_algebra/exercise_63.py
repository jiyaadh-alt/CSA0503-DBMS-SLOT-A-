import sys
from itertools import combinations


def read_lines():
    return [line.strip() for line in sys.stdin.read().splitlines() if line.strip()]


def split_list(value):
    return [item.strip() for item in value.split(",") if item.strip()]


def parse(lines):
    attrs = []
    fds = []
    decomps = []
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().upper()
        value = value.strip()
        if key == "ATTRS":
            attrs = split_list(value)
        elif key == "FD" and "->" in value:
            left, right = value.split("->", 1)
            lhs = tuple(split_list(left))
            rhs = tuple(split_list(right))
            if lhs and rhs:
                fds.append((lhs, rhs))
        elif key.startswith("DECOMP"):
            decomps.append(tuple(tuple(item for item in attrs if item in split_list(part)) for part in value.split("|")))
    return attrs, fds, decomps


def fmt(items):
    return "{" + ", ".join(items) + "}"


def fmt_fd(fd):
    return ", ".join(fd[0]) + " -> " + ", ".join(fd[1])


def ordered(items, attrs):
    return [item for item in attrs if item in set(items)]


def closure(start, fds, attrs):
    current = list(start)
    fired = []
    changed = True
    while changed:
        changed = False
        for fd in fds:
            if all(item in current for item in fd[0]):
                added = [item for item in fd[1] if item not in current]
                if added:
                    current.extend(added)
                    fired.append((fd, added))
                    changed = True
    order = {item: index for index, item in enumerate(attrs)}
    current.sort(key=lambda item: order.get(item, len(order)))
    return current, fired


def main():
    lines = read_lines()
    if not lines:
        print("EMPTY INPUT")
        print("No attributes, dependencies or decomposition were supplied; no projected closure can be computed.")
        return
    attrs, fds, decomps = parse(lines)
    if not attrs or not fds or not decomps:
        print("EMPTY INPUT")
        print("A labelled ATTRS line, at least one FD line and a DECOMP line are required.")
        return
    schemas = decomps[0]
    print("EXERCISE 63 - DEPENDENCY PRESERVATION VIA PROJECTED CLOSURES")
    print("Attributes: " + ", ".join(attrs))
    print("Explicit dependencies:")
    for fd in fds:
        print("  " + fmt_fd(fd))
    print("  Decomposition: " + " ; ".join(fmt(list(schema)) for schema in schemas))
    print("")
    union = []
    print("PROJECTED CLOSURES")
    for schema in schemas:
        print("  Relation " + fmt(list(schema)))
        for size in range(1, len(schema) + 1):
            for subset in combinations(schema, size):
                result, fired = closure(subset, fds, attrs)
                restricted = [item for item in schema if item in result]
                added = [item for item in restricted if item not in subset]
                print("    closure(" + fmt(list(subset)) + ") in full F = " + fmt(ordered(result, attrs)))
                for fd, items in fired:
                    print("      fired " + fmt_fd(fd) + ", added " + fmt(items))
                print("    projected closure in " + fmt(list(schema)) + " = " + fmt(restricted))
                if added:
                    projected = (tuple(subset), tuple(added))
                    print("    projected FD " + fmt_fd(projected))
                    if projected not in union:
                        union.append(projected)
    print("")
    print("UNION OF PROJECTED DEPENDENCIES")
    for fd in union:
        print("  " + fmt_fd(fd))
    print("")
    print("PRESERVATION CHECK")
    missing = []
    for fd in fds:
        result, fired = closure(fd[0], union, attrs)
        holds = all(item in result for item in fd[1])
        print("  " + fmt_fd(fd) + " closure under union = " + fmt(ordered(result, attrs)) + " : " + ("PRESERVED" if holds else "NOT PRESERVED"))
        for step_fd, items in fired:
            print("    fired " + fmt_fd(step_fd) + ", added " + fmt(items))
        if not holds:
            missing.append(fd)
    print("  DEPENDENCY PRESERVING: " + ("YES" if not missing else "NO"))
    if missing:
        fd = missing[0]
        original, original_fired = closure(fd[0], fds, attrs)
        projected, projected_fired = closure(fd[0], union, attrs)
        print("  MISSING IMPLICATION: " + fmt_fd(fd))
        print("  Under original F: closure(" + fmt(list(fd[0])) + ") = " + fmt(ordered(original, attrs)))
        for step_fd, items in original_fired:
            print("    fired " + fmt_fd(step_fd) + ", added " + fmt(items))
        print("  Under projected union: closure(" + fmt(list(fd[0])) + ") = " + fmt(ordered(projected, attrs)))
        if not projected_fired:
            print("    no projected dependency fires")


if __name__ == "__main__":
    main()
