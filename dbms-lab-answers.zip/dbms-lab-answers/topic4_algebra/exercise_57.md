# Exercise 57 - Division with Projection, Selection, Product and Difference Only

The required set is the unary relation `REQUIRED(PackageID) = {(S204), (S205)}`. Only the operators projection (`pi`), selection (`sigma`), Cartesian product (`x`) and set difference (`-`) are used. The subscript on a product or join is only attribute qualification, not an extra operator; where two columns share the name `GuestID` they are written as `GUEST.GuestID` and `GOOD.GuestID`.

## Algebra

```text
REQ   = {(S204), (S205)} with attribute PackageID
L     <- pi_{GuestID, PackageID}(RESERVATION)
ALLG  <- pi_{GuestID}(L)
CAND  <- ALLG x REQ
MISS  <- CAND - L
BAD   <- pi_{GuestID}(MISS)
GOOD  <- ALLG - BAD
RESULT <- pi_{GUEST.GuestID, GUEST.GuestName, GUEST.HotelID, GUEST.Gender,
                GUEST.BirthDate, GUEST.City, GUEST.Merit, GUEST.AssignedHost}
             ( sigma_{GUEST.GuestID = GOOD.GuestID}(GUEST x GOOD) )
```

Explanation: `CAND` contains every guest with any link paired with each required offering. Subtracting the actual links `L` leaves exactly the missing guest–offering pairs in `MISS`. Projecting away `PackageID` gives the guests with at least one missing pair (`BAD`); one more difference removes them, leaving the guests linked to **all** required offerings (`GOOD`). The final full records are recovered with a product plus an equality selection, so no join operator is needed.

## Intermediate result: candidate pairs (20)

`ALLG` contains all ten guests (1201 through 1210), each paired with S204 and S205.

## Intermediate result: missing pairs MISS (16)

```text
1201 S204    1202 S204    1203 S204    1204 S205
1201 S205    1202 S205    1203 S205    1206 S204
1206 S205    1207 S204    1207 S205    1208 S204
1208 S205    1209 S205    1210 S204    1210 S205
```

The four candidate pairs present in `L` and therefore absent from `MISS` are `(1204, S204)`, `(1205, S204)`, `(1205, S205)` and `(1209, S204)`.

`BAD = pi_{GuestID}(MISS) = {1201, 1202, 1203, 1204, 1206, 1207, 1208, 1209, 1210}`.

`GOOD = ALLG - BAD = {1205}`.

## Final result RESULT

```text
GuestID | GuestName | HotelID | Gender | BirthDate  | City    | Merit | AssignedHost
1205    | Eshwar    | S2B     | M      | 2004-09-17 | Mysuru  | 8.04  | 222
```

Guest 1205 is the only guest linked to both Beach Escape (S204, score 56) and Spa Retreat (S205, score 64).
