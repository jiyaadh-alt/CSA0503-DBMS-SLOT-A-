import sys


class BPlusTree:
    def __init__(self):
        self.blocks = []
        self.root = None
        self.reads = 0
        self.writes = 0
        self.splits = 0

    def read(self, index):
        self.reads += 1
        return self.blocks[index]

    def write(self, index, node):
        self.writes += 1
        self.blocks[index] = node
        return index

    def new(self, node):
        self.writes += 1
        self.blocks.append(node)
        return len(self.blocks) - 1

    def insert(self, key):
        if self.root is None:
            self.root = self.new({"leaf": True, "keys": [key], "children": [], "next": None})
            return
        promoted = self.insert_below(self.root, key)
        if promoted is not None:
            separator, right = promoted
            self.root = self.new({"leaf": False, "keys": [separator], "children": [self.root, right], "next": None})

    def insert_below(self, index, key):
        node = self.read(index)
        if node["leaf"]:
            keys = sorted(node["keys"] + [key])
            if len(keys) <= 3:
                node["keys"] = keys
                self.write(index, node)
                return None
            left_keys = keys[:2]
            right_keys = keys[2:]
            separator = right_keys[0]
            right_index = self.new({"leaf": True, "keys": right_keys, "children": [], "next": node["next"]})
            node["keys"] = left_keys
            node["next"] = right_index
            self.write(index, node)
            self.splits += 1
            return separator, right_index
        position = 0
        while position < len(node["keys"]) and key >= node["keys"][position]:
            position += 1
        promoted = self.insert_below(node["children"][position], key)
        if promoted is None:
            return None
        separator, right_index = promoted
        keys = list(node["keys"])
        children = list(node["children"])
        keys.insert(position, separator)
        children.insert(position + 1, right_index)
        if len(keys) <= 3:
            node["keys"] = keys
            node["children"] = children
            self.write(index, node)
            return None
        middle = keys[2]
        left_keys = keys[:2]
        right_keys = keys[3:]
        left_children = children[:3]
        right_children = children[3:]
        new_right = self.new({"leaf": False, "keys": right_keys, "children": right_children, "next": None})
        node["keys"] = left_keys
        node["children"] = left_children
        self.write(index, node)
        self.splits += 1
        return middle, new_right

    def levels(self):
        result = []
        if self.root is None:
            return result
        current = [self.root]
        while current:
            result.append(current)
            following = []
            for index in current:
                node = self.blocks[index]
                if not node["leaf"]:
                    following.extend(node["children"])
            current = following
        return result

    def leaf_chain(self):
        chain = []
        if self.root is None:
            return chain
        index = self.root
        while index is not None:
            node = self.blocks[index]
            if node["leaf"]:
                chain.append(index)
                index = node["next"]
                continue
            index = node["children"][0]
        return chain


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: B+ tree has no root and no nodes")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first token must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    keys = []
    for token in raw[1:1 + count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: keys must be integers")
            return
    if len(keys) < count:
        print("INPUT ERROR: expected %d keys, got %d" % (count, len(keys)))
        return
    tree = BPlusTree()
    if count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("TREE_LEVELS: 0")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    for key in keys:
        tree.insert(key)
    print("INPUT: record_count=%d order=4 max_keys=3" % count)
    print("INSERTION_ORDER: %s" % " ".join(str(k) for k in keys))
    levels = tree.levels()
    print("TREE_LEVELS: %d" % len(levels))
    for level_no, level in enumerate(levels):
        rendered = []
        for index in level:
            node = tree.blocks[index]
            kind = "LEAF" if node["leaf"] else "INT"
            rendered.append("%s:B%02d[%s]" % (kind, index, ",".join(str(k) for k in node["keys"])))
        print("LEVEL_%d: %s" % (level_no, " ".join(rendered)))
    print("LEAF_CHAIN: %s" % " -> ".join("B%02d[%s]" % (i, ",".join(str(k) for k in tree.blocks[i]["keys"])) for i in tree.leaf_chain()))
    print("SORTED_KEYS: %s" % " ".join(str(k) for k in sorted(keys)))
    print("LEAF_SPLITS: %d" % tree.splits)
    print("BLOCK_READS: %d" % tree.reads)
    print("BLOCK_WRITES: %d" % tree.writes)


if __name__ == "__main__":
    main()
