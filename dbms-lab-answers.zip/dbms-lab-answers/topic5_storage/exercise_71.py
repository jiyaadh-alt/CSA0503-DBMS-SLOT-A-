import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: no dense index entries, no index blocks, no data blocks")
        print("ROOT_TO_RECORD_IO: 0")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        record_count = int(raw[0])
        entry_size = int(raw[1])
        block_size = int(raw[2])
        data_blocking_factor = int(raw[3])
    except (IndexError, ValueError):
        print("INPUT ERROR: expected record_count entry_size block_size data_blocking_factor")
        return
    if record_count < 0 or entry_size <= 0 or block_size <= 0 or data_blocking_factor <= 0:
        print("INPUT ERROR: count must be non-negative and all sizes/capacities positive")
        return
    if record_count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: dense index has no entries and no root block")
        print("ROOT_TO_RECORD_IO: 0")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    index_blocking_factor = block_size // entry_size
    if index_blocking_factor == 0:
        print("INPUT ERROR: index entry is larger than a usable block")
        return
    levels = []
    entries = record_count
    while True:
        blocks_at_level = (entries + index_blocking_factor - 1) // index_blocking_factor
        levels.append({"entries": entries, "blocks": blocks_at_level})
        if blocks_at_level <= 1:
            break
        entries = blocks_at_level
    data_blocks = (record_count + data_blocking_factor - 1) // data_blocking_factor
    file_blocks = []
    writes = 0
    for level in levels:
        for _ in range(level["blocks"]):
            file_blocks.append(level["entries"])
            writes += 1
    reads = 0
    for _ in levels:
        reads += 1
    reads += 1
    print("INPUT: record_count=%d index_entry_size=%d block_size=%d data_blocking_factor=%d" % (record_count, entry_size, block_size, data_blocking_factor))
    print("INDEX_BLOCKING_FACTOR: %d" % index_blocking_factor)
    print("DATA_BLOCKS: %d" % data_blocks)
    print("LEVELS:")
    for level_no, level in enumerate(levels):
        label = "ROOT" if level_no == len(levels) - 1 else "L%d" % level_no
        print("  %s entries=%d blocks=%d" % (label, level["entries"], level["blocks"]))
    print("INDEX_HEIGHT: %d" % len(levels))
    print("ROOT_TO_RECORD_IO_COLD_CACHE: %d" % (len(levels) + 1))
    print("BLOCK_READS: %d" % reads)
    print("BLOCK_WRITES: %d" % writes)


if __name__ == "__main__":
    main()
