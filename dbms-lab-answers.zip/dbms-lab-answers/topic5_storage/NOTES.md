# Topic 5 – Data Storage, Hashing and Indexing

All Python files are self-contained, use only the Python 3 standard library, read stdin, and print
labelled metrics. Every simulated file is a list of blocks; a block read or write is counted when it
happens. Directory arrays and in-memory index arithmetic are reported separately from block I/O so
that no I/O is hidden. Every script prints an `EMPTY INPUT: ...` boundary case when stdin is empty.

## Exercise 65 – unspanned blocking factor and unused space

Input: three whitespace-separated integers `record_count record_length usable_block_size`.

Formulas:

- `bfr = floor(usable_block_size / record_length)`
- `blocks = ceil(record_count / bfr)`
- `unused_in_full_block = usable_block_size - bfr * record_length`
- `last_occupancy = record_count mod bfr`
- `unused_in_last_block = 0 if last_occupancy == 0 else usable_block_size - last_occupancy * record_length`
- `total_unused = blocks * usable_block_size - record_count * record_length`

No record spans two blocks. Each record insertion counts one block write; each block inspected
afterwards counts one block read.

Sample run:

```
$ printf '20 40 120\n' | python3 exercise_65.py
INPUT: record_count=20 record_length=40 usable_block_size=120
BLOCKING_FACTOR_UNSPANNED: 3
BLOCKS_NEEDED: 7
UNUSED_BYTES_IN_FULL_BLOCK: 0
RECORDS_IN_LAST_BLOCK: 2
UNUSED_BYTES_IN_LAST_BLOCK: 40
TOTAL_UNUSED_BYTES_INCLUDING_LAST_BLOCK: 40
BLOCK_WRITES: 20
BLOCK_READS: 7
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks`. If `record_length > block_size`, the blocking
factor is reported as 0 with an `UNSPANNED ERROR` line.

## Exercise 66 – append-only heap with tombstones

Input: `count`, then `count` event IDs, then optional `existing_event`, `missing_event`,
`delete_event` lines (one token each). Defaults: existing = first record, missing = `MISSING_EVENT`,
no deletion.

Blocking factor is 10 records per block. Appending fills the tail block before allocating a new one.
A search reads blocks left-to-right and stops at the first active match; a miss reads every block.
Deletion scans, marks `active=False`, and rewrites that one block. The block count never decreases.

Sample run:

```
$ printf '12\n1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n5\n99\n4\n' | python3 exercise_66.py
SEARCH_EXISTING: value=5 block=0 reads_before_hit=1
SEARCH_MISSING: value=99 block=None reads=2
BLOCKS_BEFORE_DELETE: 2
BLOCKS_AFTER_DELETE: 2
COMPACTION_PERFORMED: NO
TOMBSTONE_COUNT: 1
BLOCK_READS: 4
BLOCK_WRITES: 15
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks`.

## Exercise 67 – sequential file and binary search on block key ranges

Input: `count`, then `count` ascending integer keys, then optional `block_capacity` (default 10) and
`search_key` (default middle key).

Each block exposes its min/max key. Binary search reads one middle block per probe; if the target is
inside that block's range, the inside-block search uses the block already in memory (no extra read).
Worst case is `ceil(log2(block_count)) + 1` block reads versus `block_count` for a full heap scan.
Insertion into a sequential file shifts records and may rewrite up to `block_count` blocks; a heap
appends one block only when its tail block is full.

Sample run:

```
$ printf '12\n10\n20\n30\n40\n50\n60\n70\n80\n90\n100\n110\n120\n10\n75\n' | python3 exercise_67.py
BINARY_SEARCH_BLOCK_READS: 1
WORST_CASE_BINARY_SEARCH_BLOCK_READS: 2
HEAP_FULL_SCAN_BLOCK_READS: 2
INSERTION_COST_SEQUENTIAL: shift records and rewrite up to 2 blocks
BLOCK_WRITES: 2
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks`. Non-ascending input is rejected.

## Exercise 68 – static hashing with overflow chains

Input: `M record_count`, then `record_count` integer request IDs.

`h(k) = k mod M`. Each bucket chain starts with no block; the first insert allocates a primary block.
Each block holds two records. A full chain gets a new overflow block linked from the previous block.
Insertion order is preserved. Each chain probe is a block read; each block allocation and each record
placement is a block write.

Sample run:

```
$ printf '5\n6\n2\n7\n12\n17\n22\n27\n' | python3 exercise_68.py
HASH_FUNCTION: h(k) = k mod 5
B02 BLK00[2,7] -> BLK01[12,17] -> BLK02[22,27]
OVERFLOW_BLOCKS: 2
TOTAL_BLOCKS: 3
BLOCK_READS: 10
BLOCK_WRITES: 9
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks`; with a supplied `M` and zero records it also
prints `BUCKET_COUNT: M`.

## Exercise 69 – extendible hashing with shared bucket references

Input: `count`, then `count` integer device IDs.

`h(k) = k` using low-order bits; global depth starts at 1 with two separate depth-one buckets; each
bucket holds two records. On overflow, split only that bucket. If its local depth equals the global
depth, double the directory first. Splitting uses bit `local_depth` to divide the keys, then every
directory entry pointing at the old bucket is retargeted to one of the two new buckets. Shared
references are printed as the list of directory slots pointing at each bucket. Directory doublings
are reported as `DIRECTORY_EXPANSIONS`, not as block I/O. A 64-split guard prevents non-terminating
splits when more than two identical IDs are supplied.

Sample run:

```
$ printf '8\n0\n1\n2\n3\n4\n5\n6\n7\n' | python3 exercise_69.py
GLOBAL_DEPTH: 2
DIRECTORY_SIZE: 4
DIRECTORY_ENTRIES:
  0->B02 1->B04 2->B03 3->B05
DIRECTORY_EXPANSIONS: 1
BLOCK_READS: 11
BLOCK_WRITES: 16
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks` and shows the initial depth-one directory.

## Exercise 70 – linear hashing with split pointer and level

Input: `count`, then `count` integer record IDs.

Two buckets, capacity two, `level = 0`, `split_pointer = 0`, `modulus = 2^(level+1)`. An addressed
bucket below the split pointer is addressed again with modulus `2 * modulus`. On any overflow,
split exactly the bucket at the split pointer: allocate `bucket[pointer + modulus]`, redistribute the
old records with `h_(l+1)`, advance the pointer, and reset the pointer to 0 while incrementing the
level when the pointer reaches the current modulus. A 2000-attempt guard handles saturated cases.

Sample run:

```
$ printf '10\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n' | python3 exercise_70.py
LEVEL: 1
SPLIT_POINTER: 2
BUCKET_COUNT: 6
SPLITS: 4
BLOCK_READS: 18
BLOCK_WRITES: 26
```

Empty input prints `EMPTY INPUT: 0 records, 2 initial empty blocks` with `LEVEL: 0` and
`SPLIT_POINTER: 0`.

## Exercise 71 – dense multilevel index I/O

Input: `record_count index_entry_size block_size data_blocking_factor`.

`index_bfr = floor(block_size / index_entry_size)`. Level 0 has one entry per data record; each
higher level has one entry per block at the level below. Repeat until one root block remains. Cold
cache root-to-record cost is `index_height + 1` (one index block per level plus one data block).

Sample run:

```
$ printf '1000000\n20\n512\n50\n' | python3 exercise_71.py
INDEX_BLOCKING_FACTOR: 25
DATA_BLOCKS: 20000
LEVELS:
  L0 entries=1000000 blocks=40000
  L1 entries=40000 blocks=1600
  L2 entries=1600 blocks=64
  L3 entries=64 blocks=3
  ROOT entries=3 blocks=1
INDEX_HEIGHT: 5
ROOT_TO_RECORD_IO_COLD_CACHE: 6
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks` and `ROOT_TO_RECORD_IO: 0`.

## Exercise 72 – B+/B-tree capacity arithmetic

Input: `block_size key_size record_pointer_size child_pointer_size`.

- B+ internal: `p = floor((block_size + key_size) / (key_size + child_pointer_size))` child
  pointers, `p - 1` keys, derived from `(p-1)*key + p*child <= block_size`.
- B+ leaf: `floor((block_size - child_pointer_size) / (key_size + record_pointer_size))` records,
  charging one next-leaf pointer of child-pointer size.
- B-tree node: `floor((block_size - child_pointer_size) / (key_size + record_pointer_size + child_pointer_size))`
  keys, one record pointer per key, and `keys + 1` child pointers.

Headers are ignored. Three sample blocks are written and read so the I/O counters are explicit.

Sample run:

```
$ printf '4096\n12\n8\n8\n' | python3 exercise_72.py
BPLUS_INTERNAL_MAX_CHILD_POINTERS: 205
BPLUS_LEAF_MAX_RECORDS: 204
BTREE_NODE_MAX_KEYS: 146
BTREE_NODE_MAX_CHILD_POINTERS: 147
BLOCK_READS: 3
BLOCK_WRITES: 3
```

Empty input prints `EMPTY INPUT: 0 bytes, 0 blocks`.

## Exercise 73 – B+ insertion, order four

Input: `count`, then `count` integer keys.

Maximum three keys per node. A four-key leaf splits 2:2 and the minimum of the right leaf is copied
up (it stays in the leaf). An internal four-key overflow promotes the third key (one-based), leaving
two keys left and one key right. The leaf chain is relinked at every leaf split. Levels, leaf chain,
splits and I/O are printed.

Sample run:

```
$ printf '12\n10\n20\n5\n15\n30\n25\n35\n40\n1\n45\n50\n55\n' | python3 exercise_73.py
TREE_LEVELS: 3
LEVEL_0: INT:B07[35]
LEVEL_1: INT:B02[15,25] INT:B06[45]
LEVEL_2: LEAF:B00[1,5,10] LEAF:B01[15,20] LEAF:B03[25,30] LEAF:B04[35,40] LEAF:B05[45,50,55]
LEAF_SPLITS: 5
BLOCK_READS: 20
BLOCK_WRITES: 22
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks`.

## Exercise 74 – B+ inclusive range retrieval

Input: `count`, `count` keys, then optional `low` and `high` (defaults: min and max inserted key).

The search descends from the root to the leaf containing `low`, then follows the leaf chain, stopping
only after the first key greater than `high` is seen. `DISTINCT_NODES_VISITED` counts each node once,
including the root and the leaf that supplies the first key beyond the upper bound.
`NODE_READS_TOTAL` additionally reports raw read calls (tree construction included).

Sample run:

```
$ printf '12\n10\n20\n5\n15\n30\n25\n35\n40\n1\n45\n50\n55\n15\n40\n' | python3 exercise_74.py
RANGE_RESULTS: 15 20 25 30 35 40
DISTINCT_NODES_VISITED: 6
VISITED_NODE_IDS: B07 B02 B01 B03 B04 B05
NODE_READS_TOTAL: 27
BLOCK_WRITES: 22
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks` and an empty range.

## Exercise 75 – B+ deletion with borrow, merge and root collapse

Input: `count`, `count` keys, then `delete_count` and `delete_count` keys (a zero or missing
`delete_count` means no deletes).

Non-root leaves keep at least two keys; non-root internal nodes keep at least one key. The right
sibling is checked for borrowing first, then the left; when neither can lend, the node merges with
the right sibling if present, otherwise with the left. Separators are recomputed from subtree
minima after every successful deletion so duplicates cannot leave a stale separator. An empty root
leaf clears the tree; a root with one remaining child collapses to that child.

Sample run:

```
$ printf '12\n10\n20\n5\n15\n30\n25\n35\n40\n1\n45\n50\n55\n3\n5\n20\n50\n' | python3 exercise_75.py
OPERATION_TRACE:
  delete 5 from B00
  delete 20 from B01
  merge B01 with right B03
  delete 50 from B05
TREE_LEVELS: 3
BLOCK_READS: 36
BLOCK_WRITES: 27
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks`. Deleting a missing key prints
`delete <key> not found` and does not rebalance.

## Exercise 76 – order-five B-tree insertion

Input: `count`, then `count` integer asset IDs.

At most four keys per node. A five-key node promotes its middle key (index 2, zero-based) and removes
it from the node; an internal split therefore produces two children with two keys and three pointers
each. Verification uses inorder traversal against sorted input and checks that all leaf depths match.

Sample run:

```
$ printf '12\n10\n20\n5\n15\n30\n25\n35\n40\n1\n45\n50\n55\n' | python3 exercise_76.py
LEVEL_0: B02[15,30,45]
LEVEL_1: B00[1,5,10] B01[20,25] B03[35,40] B04[50,55]
SORTED_TRAVERSAL_VERIFIED: True
EQUAL_LEAF_DEPTH_VERIFIED: True
NODE_SPLITS: 3
BLOCK_READS: 28
BLOCK_WRITES: 18
```

Empty input prints `EMPTY INPUT: 0 records, 0 blocks`.

## Exercise 77 – ARCHIVE_S2 index experiment (MySQL)

`exercise_77.sql` creates its own database `hospitality_s2_storage_lab` and its own `ARCHIVE_S2`
table; it never touches `hospitality_s2` from `sql/00_baseline.sql`. It generates 62000 rows with a
recursive CTE (`cte_max_recursion_depth` raised to 70000), records `EXPLAIN` plans and wall-clock
timings for `RecordID = 32111` and `Region = 'REGION_07'` before and after a unique index on
`RecordID` and a nonunique index on `Region`, then prints `SHOW INDEX`.

`EXPLAIN possible_keys` shows eligibility; `EXPLAIN key` shows the optimizer's actual choice. The
unique-key lookup should become `const`; the ten-value `Region` predicate may still show a full scan
because roughly 6200 matching rows make the secondary index unattractive. Record actual output on
your server rather than assuming a particular plan. Timings vary by machine and cache state.

## Exercise 78 – SEARCH_S2 index experiment (MySQL)

`exercise_78.sql` creates its own database `hospitality_s2_index_lab` and its own `SEARCH_S2` table.
It loads 62000 generated rows, defines `ID PRIMARY KEY`, `Email UNIQUE`, composite `(Area, Score)`
and name prefix index `Name(7)`, prints `SHOW INDEX`, and runs `EXPLAIN` for area-plus-score,
score-only, area-only and name-prefix filters.

The composite index is eligible for `(Area, Score)` and for `Area` alone by leftmost prefix. A
`Score`-only predicate is not eligible through that index because `Area` is missing. `Name LIKE
'Name00%'` is eligible only for the seven-character indexed prefix; the optimizer may still choose a
full scan when the prefix estimate is poor. Interpretation notes are emitted as labelled result rows
rather than SQL comments.

## Caveats

- Block I/O counts are simulation counters, not operating-system measurements. Directory arrays,
  CTE row generation and index arithmetic are not counted as block I/O.
- Read counters include nodes read during search and rebalancing, including repeated reads of the
  same node. Exercise 74 separately reports distinct node visits.
- All structures use integer keys. Hash scripts guard against pathological duplicate-key saturation
  instead of looping forever.
- SQL scripts generate data and print plans/timings; they do not assert a fixed optimizer plan.
- No Python or SQL source file contains code comments; explanation lives in this file.
