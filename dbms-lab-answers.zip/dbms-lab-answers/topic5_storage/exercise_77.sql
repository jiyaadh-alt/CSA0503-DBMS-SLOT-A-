CREATE DATABASE IF NOT EXISTS hospitality_s2_storage_lab;
USE hospitality_s2_storage_lab;

DROP TABLE IF EXISTS ARCHIVE_S2;

CREATE TABLE ARCHIVE_S2 (
    RecordID INT NOT NULL,
    Region VARCHAR(30) NOT NULL,
    Amount DECIMAL(10,2) NOT NULL
) ENGINE = InnoDB;

SET SESSION cte_max_recursion_depth = 70000;

INSERT INTO ARCHIVE_S2 (RecordID, Region, Amount)
WITH RECURSIVE seq AS (
    SELECT 1 AS n
    UNION ALL
    SELECT n + 1 FROM seq WHERE n < 62000
)
SELECT n, CONCAT('REGION_', LPAD(CAST(n % 10 AS CHAR), 2, '0')), (n % 1000) + 0.50
FROM seq;

SELECT COUNT(*) AS rows_generated FROM ARCHIVE_S2;

SELECT 'BEFORE INDEXES' AS phase;

EXPLAIN SELECT RecordID, Region, Amount FROM ARCHIVE_S2 WHERE RecordID = 32111;
SET @t0 = NOW(6);
SELECT COUNT(*) AS recordid_match_count_before FROM ARCHIVE_S2 WHERE RecordID = 32111;
SET @t1 = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @t0, @t1) / 1000000 AS recordid_seconds_before;

EXPLAIN SELECT RecordID, Region, Amount FROM ARCHIVE_S2 WHERE Region = 'REGION_07';
SET @t0 = NOW(6);
SELECT COUNT(*) AS region_match_count_before FROM ARCHIVE_S2 WHERE Region = 'REGION_07';
SET @t1 = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @t0, @t1) / 1000000 AS region_seconds_before;

CREATE UNIQUE INDEX uq_archive_recordid ON ARCHIVE_S2 (RecordID);
CREATE INDEX ix_archive_region ON ARCHIVE_S2 (Region);
ANALYZE TABLE ARCHIVE_S2;

SELECT 'AFTER INDEXES' AS phase;

EXPLAIN SELECT RecordID, Region, Amount FROM ARCHIVE_S2 WHERE RecordID = 32111;
SET @t0 = NOW(6);
SELECT COUNT(*) AS recordid_match_count_after FROM ARCHIVE_S2 WHERE RecordID = 32111;
SET @t1 = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @t0, @t1) / 1000000 AS recordid_seconds_after;

EXPLAIN SELECT RecordID, Region, Amount FROM ARCHIVE_S2 WHERE Region = 'REGION_07';
SET @t0 = NOW(6);
SELECT COUNT(*) AS region_match_count_after FROM ARCHIVE_S2 WHERE Region = 'REGION_07';
SET @t1 = NOW(6);
SELECT TIMESTAMPDIFF(MICROSECOND, @t0, @t1) / 1000000 AS region_seconds_after;

SHOW INDEX FROM ARCHIVE_S2;

SELECT 'EXPLAIN possible_keys shows eligibility; EXPLAIN key shows optimizer choice' AS eligibility_note;
SELECT 'Region has ten values over 62000 rows so a full scan may remain cheaper than the secondary index' AS optimizer_note;
