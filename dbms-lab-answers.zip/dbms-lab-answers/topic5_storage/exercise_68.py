import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: no request IDs supplied, no hash blocks allocated")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        bucket_count = int(raw[0])
        record_count = int(raw[1])
    except (IndexError, ValueError):
        print("INPUT ERROR: expected bucket_count then record_count")
        return
    if bucket_count <= 0 or record_count < 0:
        print("INPUT ERROR: bucket_count must be positive and record_count non-negative")
        return
    keys = []
    for token in raw[2:2 + record_count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: request IDs must be integers")
            return
    if len(keys) < record_count:
        print("INPUT ERROR: expected %d request IDs, got %d" % (record_count, len(keys)))
        return
    if record_count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BUCKET_COUNT: %d" % bucket_count)
        print("HASH_FUNCTION: h(k) = k mod %d" % bucket_count)
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    capacity = 2
    blocks = []
    buckets = [[] for _ in range(bucket_count)]
    reads = 0
    writes = 0
    trace = []

    def allocate(keys_in_block):
        nonlocal writes
        block = {"keys": list(keys_in_block), "next": None}
        index = len(blocks)
        blocks.append(block)
        writes += 1
        return index

    for key in keys:
        home = key % bucket_count
        trace.append("insert %d h=%d" % (key, home))
        chain = buckets[home]
        if not chain:
            chain.append(allocate([]))
            buckets[home] = chain
            trace.append("  allocate primary block BLK%02d" % chain[0])
        placed = False
        for block_index in list(chain):
            reads += 1
            block = blocks[block_index]
            if len(block["keys"]) < capacity:
                block["keys"].append(key)
                writes += 1
                trace.append("  write BLK%02d keys=%s" % (block_index, ",".join(str(x) for x in block["keys"])))
                placed = True
                break
        if not placed:
            overflow_index = allocate([key])
            writes += 1
            blocks[chain[-1]]["next"] = overflow_index
            chain.append(overflow_index)
            trace.append("  overflow BLK%02d -> BLK%02d" % (chain[-2], overflow_index))
    print("INPUT: bucket_count=%d record_count=%d block_capacity=%d" % (bucket_count, record_count, capacity))
    print("HASH_FUNCTION: h(k) = k mod %d" % bucket_count)
    print("INSERTION_ORDER: %s" % " ".join(str(k) for k in keys))
    print("BUCKET_CHAINS:")
    for bucket_id, chain in enumerate(buckets):
        if not chain:
            print("  B%02d empty" % bucket_id)
            continue
        parts = []
        for block_index in chain:
            block = blocks[block_index]
            parts.append("BLK%02d[%s]" % (block_index, ",".join(str(x) for x in block["keys"])))
        print("  B%02d %s" % (bucket_id, " -> ".join(parts)))
    print("OVERFLOW_BLOCKS: %d" % sum(max(0, len(chain) - 1) for chain in buckets))
    print("TOTAL_BLOCKS: %d" % len(blocks))
    print("INSERT_TRACE:")
    for line in trace:
        print("  " + line)
    print("BLOCK_READS: %d" % reads)
    print("BLOCK_WRITES: %d" % writes)


if __name__ == "__main__":
    main()
