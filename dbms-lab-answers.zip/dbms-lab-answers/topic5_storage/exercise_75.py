import sys


class BPlusTree:
    def __init__(self):
        self.blocks = []
        self.root = None
        self.reads = 0
        self.writes = 0
        self.dead = set()
        self.trace = []
        self.splits = 0

    def read(self, index):
        self.reads += 1
        return self.blocks[index]

    def write(self, index, node):
        self.writes += 1
        self.blocks[index] = node
        return index

    def new(self, node):
        self.writes += 1
        self.blocks.append(node)
        return len(self.blocks) - 1

    def insert(self, key):
        if self.root is None:
            self.root = self.new({"leaf": True, "keys": [key], "children": [], "next": None})
            return
        promoted = self.insert_below(self.root, key)
        if promoted is not None:
            separator, right = promoted
            self.root = self.new({"leaf": False, "keys": [separator], "children": [self.root, right], "next": None})

    def insert_below(self, index, key):
        node = self.read(index)
        if node["leaf"]:
            keys = sorted(node["keys"] + [key])
            if len(keys) <= 3:
                node["keys"] = keys
                self.write(index, node)
                return None
            right_index = self.new({"leaf": True, "keys": keys[2:], "children": [], "next": node["next"]})
            node["keys"] = keys[:2]
            node["next"] = right_index
            self.write(index, node)
            self.splits += 1
            return keys[2], right_index
        position = 0
        while position < len(node["keys"]) and key >= node["keys"][position]:
            position += 1
        promoted = self.insert_below(node["children"][position], key)
        if promoted is None:
            return None
        separator, right_index = promoted
        keys = list(node["keys"])
        children = list(node["children"])
        keys.insert(position, separator)
        children.insert(position + 1, right_index)
        if len(keys) <= 3:
            node["keys"] = keys
            node["children"] = children
            self.write(index, node)
            return None
        middle = keys[2]
        new_right = self.new({"leaf": False, "keys": keys[3:], "children": children[3:], "next": None})
        node["keys"] = keys[:2]
        node["children"] = children[:3]
        self.write(index, node)
        self.splits += 1
        return middle, new_right

    def find_leaf(self, key):
        index = self.root
        parent = None
        position = None
        while index is not None:
            node = self.read(index)
            if node["leaf"]:
                return key in node["keys"], index, parent, position
            child_position = 0
            while child_position < len(node["keys"]) and key >= node["keys"][child_position]:
                child_position += 1
            parent = index
            position = child_position
            index = node["children"][child_position]
        return False, None, None, None

    def find_parent(self, target):
        if self.root == target:
            return None, None
        pending = [(self.root, None)]
        while pending:
            index, parent = pending.pop()
            node = self.read(index)
            if not node["leaf"]:
                for position, child in enumerate(node["children"]):
                    if child == target:
                        return index, position
                    pending.append((child, index))
        return None, None

    def subtree_min(self, index):
        node = self.read(index)
        if node["leaf"]:
            return node["keys"][0] if node["keys"] else None
        for child in node["children"]:
            value = self.subtree_min(child)
            if value is not None:
                return value
        return None

    def refresh_separators(self, index):
        node = self.read(index)
        if node["leaf"]:
            return
        for child in node["children"]:
            self.refresh_separators(child)
        node["keys"] = [self.subtree_min(child) for child in node["children"][1:]]
        self.write(index, node)

    def rebalance(self, index, parent_id, position):
        parent = self.read(parent_id)
        node = self.read(index)
        required = 2 if node["leaf"] else 1
        if len(node["keys"]) >= required:
            return
        right_id = parent["children"][position + 1] if position + 1 < len(parent["children"]) else None
        left_id = parent["children"][position - 1] if position - 1 >= 0 else None
        right = self.read(right_id) if right_id is not None else None
        left = self.read(left_id) if left_id is not None else None
        if right is not None and len(right["keys"]) > (2 if right["leaf"] else 1):
            if node["leaf"]:
                value = right["keys"].pop(0)
                node["keys"].append(value)
                parent["keys"][position] = right["keys"][0]
            else:
                value = right["keys"].pop(0)
                child = right["children"].pop(0)
                node["keys"].append(value)
                node["children"].append(child)
                parent["keys"][position] = right["keys"][0]
            self.write(index, node)
            self.write(right_id, right)
            self.write(parent_id, parent)
            self.trace.append("borrow right B%02d <- B%02d" % (index, right_id))
            return
        if left is not None and len(left["keys"]) > (2 if left["leaf"] else 1):
            if node["leaf"]:
                value = left["keys"].pop()
                node["keys"].insert(0, value)
                parent["keys"][position - 1] = node["keys"][0]
            else:
                value = left["keys"].pop()
                child = left["children"].pop()
                node["keys"].insert(0, value)
                node["children"].insert(0, child)
                parent["keys"][position - 1] = node["keys"][0]
            self.write(index, node)
            self.write(left_id, left)
            self.write(parent_id, parent)
            self.trace.append("borrow left B%02d <- B%02d" % (index, left_id))
            return
        if right is not None:
            if node["leaf"]:
                node["keys"] = node["keys"] + right["keys"]
                node["next"] = right["next"]
            else:
                node["keys"] = node["keys"] + [parent["keys"][position]] + right["keys"]
                node["children"] = node["children"] + right["children"]
            del parent["keys"][position]
            del parent["children"][position + 1]
            self.write(index, node)
            self.write(parent_id, parent)
            self.dead.add(right_id)
            self.trace.append("merge B%02d with right B%02d" % (index, right_id))
        elif left is not None:
            if node["leaf"]:
                left["keys"] = left["keys"] + node["keys"]
                left["next"] = node["next"]
            else:
                left["keys"] = left["keys"] + [parent["keys"][position - 1]] + node["keys"]
                left["children"] = left["children"] + node["children"]
            del parent["keys"][position - 1]
            del parent["children"][position]
            self.write(left_id, left)
            self.write(parent_id, parent)
            self.dead.add(index)
            self.trace.append("merge B%02d with left B%02d" % (index, left_id))
        if parent_id == self.root:
            if not parent["children"]:
                self.root = None
                self.dead.add(parent_id)
                self.trace.append("root collapsed to empty tree")
            elif len(parent["children"]) == 1:
                self.root = parent["children"][0]
                self.dead.add(parent_id)
                self.trace.append("root collapsed to single child B%02d" % self.root)
            return
        if len(parent["keys"]) < 1:
            grandparent, parent_position = self.find_parent(parent_id)
            if grandparent is not None:
                self.rebalance(parent_id, grandparent, parent_position)

    def delete(self, key):
        if self.root is None:
            self.trace.append("delete %d on empty tree" % key)
            return False
        found, leaf_id, parent_id, position = self.find_leaf(key)
        if not found:
            self.trace.append("delete %d not found" % key)
            return False
        node = self.read(leaf_id)
        node["keys"].remove(key)
        self.write(leaf_id, node)
        self.trace.append("delete %d from B%02d" % (key, leaf_id))
        if leaf_id == self.root:
            if not node["keys"]:
                self.root = None
                self.dead.add(leaf_id)
                self.trace.append("root leaf emptied")
            return True
        if len(node["keys"]) < 2:
            self.rebalance(leaf_id, parent_id, position)
        if self.root is not None:
            self.refresh_separators(self.root)
        return True

    def levels(self):
        result = []
        if self.root is None:
            return result
        current = [self.root]
        while current:
            result.append(current)
            following = []
            for index in current:
                node = self.blocks[index]
                if not node["leaf"]:
                    following.extend(child for child in node["children"] if child not in self.dead)
            current = following
        return result

    def leaf_chain(self):
        chain = []
        if self.root is None:
            return chain
        index = self.root
        while index is not None:
            node = self.blocks[index]
            if node["leaf"]:
                chain.append(index)
                index = node["next"]
                continue
            index = node["children"][0]
        return chain


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: no B+ tree and no deletions")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first token must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    keys = []
    for token in raw[1:1 + count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: keys must be integers")
            return
    if len(keys) < count:
        print("INPUT ERROR: expected %d keys, got %d" % (count, len(keys)))
        return
    tree = BPlusTree()
    if count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: deletion from an empty tree has no effect")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    for key in keys:
        tree.insert(key)
    extras = raw[1 + count:]
    deletions = []
    if extras:
        try:
            delete_count = int(extras[0])
        except ValueError:
            print("INPUT ERROR: deletion count must be an integer")
            return
        for token in extras[1:1 + delete_count]:
            try:
                deletions.append(int(token))
            except ValueError:
                print("INPUT ERROR: deletion keys must be integers")
                return
    for key in deletions:
        tree.delete(key)
    print("INPUT: record_count=%d deletions=%d max_keys=3 min_leaf_keys=2 min_internal_keys=1" % (count, len(deletions)))
    print("INSERTION_ORDER: %s" % " ".join(str(k) for k in keys))
    print("DELETION_ORDER: %s" % (" ".join(str(k) for k in deletions) if deletions else "[]"))
    print("OPERATION_TRACE:")
    for line in tree.trace:
        print("  " + line)
    levels = tree.levels()
    print("TREE_LEVELS: %d" % len(levels))
    for level_no, level in enumerate(levels):
        rendered = []
        for index in level:
            node = tree.blocks[index]
            rendered.append("%s:B%02d[%s]" % ("LEAF" if node["leaf"] else "INT", index, ",".join(str(k) for k in node["keys"])))
        print("LEVEL_%d: %s" % (level_no, " ".join(rendered)))
    print("LEAF_CHAIN: %s" % (" -> ".join("B%02d[%s]" % (i, ",".join(str(k) for k in tree.blocks[i]["keys"])) for i in tree.leaf_chain()) if tree.leaf_chain() else "[]"))
    print("BLOCK_READS: %d" % tree.reads)
    print("BLOCK_WRITES: %d" % tree.writes)


if __name__ == "__main__":
    main()
