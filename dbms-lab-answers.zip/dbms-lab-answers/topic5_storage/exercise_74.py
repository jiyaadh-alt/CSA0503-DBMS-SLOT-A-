import sys


class BPlusTree:
    def __init__(self):
        self.blocks = []
        self.root = None
        self.reads = 0
        self.writes = 0
        self.splits = 0

    def read(self, index):
        self.reads += 1
        return self.blocks[index]

    def write(self, index, node):
        self.writes += 1
        self.blocks[index] = node
        return index

    def new(self, node):
        self.writes += 1
        self.blocks.append(node)
        return len(self.blocks) - 1

    def insert(self, key):
        if self.root is None:
            self.root = self.new({"leaf": True, "keys": [key], "children": [], "next": None})
            return
        promoted = self.insert_below(self.root, key)
        if promoted is not None:
            separator, right = promoted
            self.root = self.new({"leaf": False, "keys": [separator], "children": [self.root, right], "next": None})

    def insert_below(self, index, key):
        node = self.read(index)
        if node["leaf"]:
            keys = sorted(node["keys"] + [key])
            if len(keys) <= 3:
                node["keys"] = keys
                self.write(index, node)
                return None
            left_keys = keys[:2]
            right_keys = keys[2:]
            separator = right_keys[0]
            right_index = self.new({"leaf": True, "keys": right_keys, "children": [], "next": node["next"]})
            node["keys"] = left_keys
            node["next"] = right_index
            self.write(index, node)
            self.splits += 1
            return separator, right_index
        position = 0
        while position < len(node["keys"]) and key >= node["keys"][position]:
            position += 1
        promoted = self.insert_below(node["children"][position], key)
        if promoted is None:
            return None
        separator, right_index = promoted
        keys = list(node["keys"])
        children = list(node["children"])
        keys.insert(position, separator)
        children.insert(position + 1, right_index)
        if len(keys) <= 3:
            node["keys"] = keys
            node["children"] = children
            self.write(index, node)
            return None
        middle = keys[2]
        left_children = children[:3]
        right_children = children[3:]
        new_right = self.new({"leaf": False, "keys": keys[3:], "children": right_children, "next": None})
        node["keys"] = keys[:2]
        node["children"] = left_children
        self.write(index, node)
        self.splits += 1
        return middle, new_right

    def levels(self):
        result = []
        if self.root is None:
            return result
        current = [self.root]
        while current:
            result.append(current)
            following = []
            for index in current:
                node = self.blocks[index]
                if not node["leaf"]:
                    following.extend(node["children"])
            current = following
        return result


def range_retrieve(tree, low, high):
    visited = []
    seen = set()
    trace = []

    def visit(index):
        if index not in seen:
            seen.add(index)
            visited.append(index)
        return tree.read(index)

    index = tree.root
    while index is not None:
        node = visit(index)
        trace.append("visit B%02d %s keys=%s" % (index, "LEAF" if node["leaf"] else "INT", ",".join(str(k) for k in node["keys"])))
        if node["leaf"]:
            break
        position = 0
        while position < len(node["keys"]) and low >= node["keys"][position]:
            position += 1
        index = node["children"][position]
    results = []
    beyond = False
    while index is not None:
        node = visit(index)
        trace.append("scan leaf B%02d keys=%s" % (index, ",".join(str(k) for k in node["keys"])))
        for key in node["keys"]:
            if key > high:
                beyond = True
                trace.append("stop at BLK B%02d first key beyond upper bound=%d" % (index, key))
                break
            if key >= low:
                results.append(key)
        if beyond:
            break
        index = node["next"]
    return results, visited, trace


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: no B+ tree and no range to retrieve")
        print("DISTINCT_NODES_VISITED: 0")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first token must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    keys = []
    for token in raw[1:1 + count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: keys must be integers")
            return
    if len(keys) < count:
        print("INPUT ERROR: expected %d keys, got %d" % (count, len(keys)))
        return
    extras = raw[1 + count:]
    tree = BPlusTree()
    if count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: empty tree returns an empty range")
        print("RANGE_RESULTS: []")
        print("DISTINCT_NODES_VISITED: 0")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    for key in keys:
        tree.insert(key)
    low = min(keys)
    high = max(keys)
    if len(extras) >= 1:
        try:
            low = int(extras[0])
        except ValueError:
            print("INPUT ERROR: range lower bound must be an integer")
            return
    if len(extras) >= 2:
        try:
            high = int(extras[1])
        except ValueError:
            print("INPUT ERROR: range upper bound must be an integer")
            return
    results, visited, trace = range_retrieve(tree, low, high)
    print("INPUT: record_count=%d range=[%d,%d] order=4 max_keys=3" % (count, low, high))
    print("INSERTED_KEYS: %s" % " ".join(str(k) for k in keys))
    levels = tree.levels()
    print("TREE_LEVELS: %d" % len(levels))
    for level_no, level in enumerate(levels):
        rendered = []
        for index in level:
            node = tree.blocks[index]
            rendered.append("%s:B%02d[%s]" % ("LEAF" if node["leaf"] else "INT", index, ",".join(str(k) for k in node["keys"])))
        print("LEVEL_%d: %s" % (level_no, " ".join(rendered)))
    print("RANGE_TRACE:")
    for line in trace:
        print("  " + line)
    print("RANGE_RESULTS: %s" % (" ".join(str(k) for k in results) if results else "[]"))
    print("DISTINCT_NODES_VISITED: %d" % len(visited))
    print("VISITED_NODE_IDS: %s" % (" ".join("B%02d" % i for i in visited) if visited else "[]"))
    print("NODE_READS_TOTAL: %d" % tree.reads)
    print("BLOCK_WRITES: %d" % tree.writes)


if __name__ == "__main__":
    main()
