import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: no records supplied, so no blocks are allocated")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        record_count = int(raw[0])
        record_length = int(raw[1])
        block_size = int(raw[2])
    except (IndexError, ValueError):
        print("INPUT ERROR: expected record_count record_length usable_block_size")
        return
    if record_count < 0 or record_length <= 0 or block_size <= 0:
        print("INPUT ERROR: counts must be non-negative and sizes must be positive")
        return
    blocking_factor = block_size // record_length
    if blocking_factor == 0:
        print("INPUT: record_count=%d record_length=%d usable_block_size=%d" % (record_count, record_length, block_size))
        print("BLOCKING_FACTOR_UNSPANNED: 0")
        print("UNSPANNED ERROR: a record does not fit in one usable block")
        return
    blocks_needed = (record_count + blocking_factor - 1) // blocking_factor
    unused_in_full_block = block_size - blocking_factor * record_length
    last_occupancy = record_count % blocking_factor
    unused_in_last_block = 0 if last_occupancy == 0 else block_size - last_occupancy * record_length
    total_unused = blocks_needed * block_size - record_count * record_length
    file_blocks = [[] for _ in range(blocks_needed)]
    writes = 0
    for record_no in range(record_count):
        block_index = record_no // blocking_factor
        file_blocks[block_index].append(record_no)
        writes += 1
    reads = 0
    structure = []
    for block_index, entries in enumerate(file_blocks):
        reads += 1
        used = len(entries) * record_length
        structure.append("BLK%02d records=%d used_bytes=%d unused_bytes=%d" % (block_index, len(entries), used, block_size - used))
    print("INPUT: record_count=%d record_length=%d usable_block_size=%d" % (record_count, record_length, block_size))
    if record_count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
    print("BLOCKING_FACTOR_UNSPANNED: %d" % blocking_factor)
    print("BLOCKS_NEEDED: %d" % blocks_needed)
    print("UNUSED_BYTES_IN_FULL_BLOCK: %d" % unused_in_full_block)
    print("RECORDS_IN_LAST_BLOCK: %d" % last_occupancy)
    print("UNUSED_BYTES_IN_LAST_BLOCK: %d" % unused_in_last_block)
    print("TOTAL_CAPACITY_BYTES: %d" % (blocks_needed * block_size))
    print("TOTAL_RECORD_BYTES: %d" % (record_count * record_length))
    print("TOTAL_UNUSED_BYTES_INCLUDING_LAST_BLOCK: %d" % total_unused)
    print("FILE_BLOCKS:")
    for line in structure:
        print("  " + line)
    print("BLOCK_WRITES: %d" % writes)
    print("BLOCK_READS: %d" % reads)


if __name__ == "__main__":
    main()
