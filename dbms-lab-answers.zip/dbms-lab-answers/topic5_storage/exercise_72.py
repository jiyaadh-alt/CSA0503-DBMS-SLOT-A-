import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 bytes, 0 blocks")
        print("BOUNDARY CASE: node capacities are undefined without sizes")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        block_size = int(raw[0])
        key_size = int(raw[1])
        record_pointer_size = int(raw[2])
        child_pointer_size = int(raw[3])
    except (IndexError, ValueError):
        print("INPUT ERROR: expected block_size key_size record_pointer_size child_pointer_size")
        return
    if block_size < 0 or key_size < 0 or record_pointer_size < 0 or child_pointer_size < 0:
        print("INPUT ERROR: sizes must be non-negative")
        return
    if block_size == 0:
        print("EMPTY INPUT: 0 usable bytes, 0 blocks")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    bplus_internal_children = 0
    bplus_internal_keys = 0
    if key_size + child_pointer_size > 0:
        bplus_internal_children = (block_size + key_size) // (key_size + child_pointer_size)
        bplus_internal_keys = bplus_internal_children - 1
    bplus_leaf_records = 0
    if key_size + record_pointer_size > 0:
        bplus_leaf_records = (block_size - child_pointer_size) // (key_size + record_pointer_size)
        bplus_leaf_records = max(0, bplus_leaf_records)
    btree_keys = 0
    btree_children = 0
    denominator = key_size + record_pointer_size + child_pointer_size
    if denominator > 0:
        btree_keys = max(0, (block_size - child_pointer_size) // denominator)
        btree_children = btree_keys + 1 if btree_keys else 0
    file_blocks = [bplus_internal_children, bplus_leaf_records, btree_children]
    writes = len(file_blocks)
    reads = 0
    for _ in file_blocks:
        reads += 1
    print("INPUT: block_size=%d key_size=%d record_pointer_size=%d child_pointer_size=%d" % (block_size, key_size, record_pointer_size, child_pointer_size))
    print("BPLUS_INTERNAL_MAX_CHILD_POINTERS: %d" % bplus_internal_children)
    print("BPLUS_INTERNAL_MAX_KEYS: %d" % bplus_internal_keys)
    print("BPLUS_LEAF_MAX_RECORDS: %d" % bplus_leaf_records)
    print("BTREE_NODE_MAX_KEYS: %d" % btree_keys)
    print("BTREE_NODE_MAX_CHILD_POINTERS: %d" % btree_children)
    print("SAMPLE_BLOCKS: BLK00 internal BLK01 leaf BLK02 btree_node")
    print("BLOCK_READS: %d" % reads)
    print("BLOCK_WRITES: %d" % writes)


if __name__ == "__main__":
    main()
