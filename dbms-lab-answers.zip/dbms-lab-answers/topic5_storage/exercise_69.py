import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: directory starts empty because no IDs were supplied")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first token must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    keys = []
    for token in raw[1:1 + count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: device IDs must be integers")
            return
    if len(keys) < count:
        print("INPUT ERROR: expected %d device IDs, got %d" % (count, len(keys)))
        return
    capacity = 2
    buckets = []
    reads = 0
    writes = 0
    expansions = 0
    trace = []

    def new_bucket(depth, values):
        nonlocal writes
        bucket = {"depth": depth, "keys": list(values)}
        index = len(buckets)
        buckets.append(bucket)
        writes += 1
        return index

    left = new_bucket(1, [])
    right = new_bucket(1, [])
    directory = [left, right]
    global_depth = 1
    if count == 0:
        print("EMPTY INPUT: 0 records, 2 initial empty blocks")
        print("BOUNDARY CASE: global_depth=1 with two separate depth-one buckets")
        print("GLOBAL_DEPTH: 1")
        print("DIRECTORY: 0->B00 1->B01")
        print("BUCKETS: B00(depth=1,keys=[]) B01(depth=1,keys=[])")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: %d" % writes)
        return
    for key in keys:
        guard = 0
        while True:
            guard += 1
            if guard > 64:
                trace.append("insert %d stopped after 64 splits (duplicate-key saturation)" % key)
                break
            slot = key & ((1 << global_depth) - 1)
            bucket_id = directory[slot]
            reads += 1
            bucket = buckets[bucket_id]
            if len(bucket["keys"]) < capacity:
                bucket["keys"].append(key)
                writes += 1
                trace.append("insert %d slot=%d -> B%02d keys=%s" % (key, slot, bucket_id, ",".join(str(x) for x in bucket["keys"])))
                break
            local_depth = bucket["depth"]
            if local_depth == global_depth:
                global_depth += 1
                directory = directory + list(directory)
                expansions += 1
                trace.append("double directory to size=%d global_depth=%d" % (len(directory), global_depth))
                continue
            distinguishing_bit = 1 << local_depth
            new_depth = local_depth + 1
            new_left = new_bucket(new_depth, [])
            new_right = new_bucket(new_depth, [])
            for value in bucket["keys"]:
                if value & distinguishing_bit:
                    buckets[new_right]["keys"].append(value)
                else:
                    buckets[new_left]["keys"].append(value)
            for slot_index, ref in enumerate(directory):
                if ref == bucket_id:
                    directory[slot_index] = new_right if slot_index & distinguishing_bit else new_left
            bucket["keys"] = []
            writes += 1
            trace.append("split B%02d depth %d->%d into B%02d and B%02d" % (bucket_id, local_depth, new_depth, new_left, new_right))
    print("INPUT: record_count=%d block_capacity=%d hash_function=h(k)=k low-order bits" % (count, capacity))
    print("DEVICE_IDS: %s" % " ".join(str(k) for k in keys))
    print("GLOBAL_DEPTH: %d" % global_depth)
    print("DIRECTORY_SIZE: %d" % len(directory))
    print("DIRECTORY_ENTRIES:")
    print("  " + " ".join("%d->B%02d" % (slot, bucket_id) for slot, bucket_id in enumerate(directory)))
    print("SHARED_BUCKET_REFERENCES:")
    for bucket_id in sorted(set(directory)):
        slots = [slot for slot, ref in enumerate(directory) if ref == bucket_id]
        print("  B%02d depth=%d keys=%s referenced_by=%s" % (bucket_id, buckets[bucket_id]["depth"], ",".join(str(x) for x in buckets[bucket_id]["keys"]), ",".join(str(s) for s in slots)))
    print("DIRECTORY_EXPANSIONS: %d" % expansions)
    print("INSERT_TRACE:")
    for line in trace:
        print("  " + line)
    print("BLOCK_READS: %d" % reads)
    print("BLOCK_WRITES: %d" % writes)


if __name__ == "__main__":
    main()
