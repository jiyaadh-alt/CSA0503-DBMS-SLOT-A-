import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: two initial buckets, level=0, split_pointer=0")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first token must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    keys = []
    for token in raw[1:1 + count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: record IDs must be integers")
            return
    if len(keys) < count:
        print("INPUT ERROR: expected %d record IDs, got %d" % (count, len(keys)))
        return
    capacity = 2
    buckets = [[], []]
    level = 0
    split_pointer = 0
    modulus = 2
    reads = 0
    writes = 0
    split_count = 0
    trace = []

    def address(key):
        bucket = key % modulus
        if bucket < split_pointer:
            bucket = key % (2 * modulus)
        return bucket

    if count == 0:
        print("EMPTY INPUT: 0 records, 2 initial empty blocks")
        print("LEVEL: 0")
        print("SPLIT_POINTER: 0")
        print("BUCKETS: B00=[] B01=[]")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return

    def split_bucket():
        nonlocal modulus, level, split_pointer, split_count, reads, writes
        old = split_pointer
        new_index = old + modulus
        while len(buckets) <= new_index:
            buckets.append([])
            writes += 1
        reads += 1
        original = list(buckets[old])
        buckets[old] = []
        writes += 1
        for value in original:
            target = new_index if value % (2 * modulus) == new_index else old
            buckets[target].append(value)
            writes += 1
        split_count += 1
        trace.append("split B%02d -> B%02d using mod=%d" % (old, new_index, 2 * modulus))
        split_pointer += 1
        if split_pointer == modulus:
            split_pointer = 0
            level += 1
            modulus *= 2
            trace.append("level=%d modulus=%d split_pointer=0" % (level, modulus))

    for key in keys:
        guard = 0
        while True:
            guard += 1
            if guard > 2000:
                trace.append("insert %d stopped after 2000 split attempts" % key)
                break
            bucket = address(key)
            reads += 1
            if len(buckets[bucket]) < capacity:
                buckets[bucket].append(key)
                writes += 1
                trace.append("insert %d -> B%02d keys=%s" % (key, bucket, ",".join(str(x) for x in buckets[bucket])))
                break
            split_bucket()
    print("INPUT: record_count=%d block_capacity=%d" % (count, capacity))
    print("RECORD_IDS: %s" % " ".join(str(k) for k in keys))
    print("HASH_FUNCTION: h_l(k) = k mod %d where current level=%d" % (modulus, level))
    print("LEVEL: %d" % level)
    print("SPLIT_POINTER: %d" % split_pointer)
    print("BUCKET_COUNT: %d" % len(buckets))
    print("BUCKETS:")
    for index, values in enumerate(buckets):
        print("  B%02d keys=%s" % (index, ",".join(str(x) for x in values)))
    print("SPLITS: %d" % split_count)
    print("INSERT_TRACE:")
    for line in trace:
        print("  " + line)
    print("BLOCK_READS: %d" % reads)
    print("BLOCK_WRITES: %d" % writes)


if __name__ == "__main__":
    main()
