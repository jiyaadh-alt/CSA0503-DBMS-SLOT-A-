CREATE DATABASE IF NOT EXISTS hospitality_s2_index_lab;
USE hospitality_s2_index_lab;

DROP TABLE IF EXISTS SEARCH_S2;

CREATE TABLE SEARCH_S2 (
    ID INT NOT NULL,
    Email VARCHAR(120) NOT NULL,
    Area VARCHAR(45) NOT NULL,
    Score INT NOT NULL,
    Name VARCHAR(90) NOT NULL,
    PRIMARY KEY (ID),
    UNIQUE KEY uq_search_email (Email),
    KEY ix_search_area_score (Area, Score),
    KEY ix_search_name_prefix (Name(7))
) ENGINE = InnoDB;

SET SESSION cte_max_recursion_depth = 70000;

INSERT INTO SEARCH_S2 (ID, Email, Area, Score, Name)
WITH RECURSIVE seq AS (
    SELECT 1 AS n
    UNION ALL
    SELECT n + 1 FROM seq WHERE n < 62000
)
SELECT n,
       CONCAT('user', LPAD(CAST(n AS CHAR), 6, '0'), '@example.test'),
       CONCAT('AREA_', LPAD(CAST(n % 12 AS CHAR), 2, '0')),
       n % 100,
       CONCAT('Name', LPAD(CAST(n AS CHAR), 6, '0'))
FROM seq;

SELECT COUNT(*) AS rows_generated FROM SEARCH_S2;

ANALYZE TABLE SEARCH_S2;

SHOW INDEX FROM SEARCH_S2;

EXPLAIN SELECT ID, Email, Area, Score, Name FROM SEARCH_S2 WHERE Area = 'AREA_07' AND Score = 83;

EXPLAIN SELECT ID, Email, Area, Score, Name FROM SEARCH_S2 WHERE Score = 83;

EXPLAIN SELECT ID, Email, Area, Score, Name FROM SEARCH_S2 WHERE Area = 'AREA_07';

EXPLAIN SELECT ID, Email, Area, Score, Name FROM SEARCH_S2 WHERE Name LIKE 'Name00%';

SELECT 'composite (Area,Score) serves Area+Score and Area-only by leftmost prefix' AS leftmost_note;
SELECT 'Score-only cannot use the composite because Area is the leftmost column' AS score_only_note;
SELECT 'Name(7) is a prefix index so LIKE Name00% is eligible only for the indexed prefix' AS prefix_note;
SELECT 'EXPLAIN key may be NULL or ALL when the optimizer estimates a scan is cheaper' AS optimizer_note;
