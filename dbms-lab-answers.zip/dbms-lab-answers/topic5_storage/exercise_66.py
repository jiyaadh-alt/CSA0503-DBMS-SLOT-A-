import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: append-only heap has no records and no blocks")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first line must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    records = raw[1:1 + count]
    extras = raw[1 + count:]
    capacity = 10
    if count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BLOCKING_FACTOR: %d" % capacity)
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    if len(records) < count:
        print("INPUT ERROR: expected %d event records, got %d" % (count, len(records)))
        return
    existing = records[0]
    missing = "MISSING_EVENT"
    deletion = None
    if len(extras) >= 1:
        existing = extras[0]
    if len(extras) >= 2:
        missing = extras[1]
    if len(extras) >= 3:
        deletion = extras[2]
    blocks = []
    writes = 0
    for record in records:
        if not blocks or len(blocks[-1]) >= capacity:
            blocks.append([])
            writes += 1
        blocks[-1].append([record, True])
        writes += 1
    reads = 0

    def search(value):
        nonlocal reads
        for block_index, block in enumerate(blocks):
            reads += 1
            for entry in block:
                if entry[0] == value and entry[1]:
                    return block_index, entry, reads
        return None, None, reads

    hit_block, hit_entry, read_hit = search(existing)
    reads_total = reads
    miss_block, miss_entry, read_miss_after = search(missing)
    reads_total = reads
    print("INPUT: record_count=%d blocking_factor=%d" % (count, capacity))
    print("EVENT_RECORDS: %s" % " ".join(records))
    print("SEARCH_EXISTING: value=%s block=%s reads_before_hit=%d" % (existing, hit_block, read_hit))
    print("SEARCH_MISSING: value=%s block=%s reads=%d" % (missing, miss_block, read_miss_after - read_hit))
    print("HEAP_WORST_CASE_READS: %d" % len(blocks))
    if deletion is not None:
        block_before = len(blocks)
        dblock, dentry, _ = search(deletion)
        if dentry is not None:
            dentry[1] = False
            writes += 1
            print("TOMBSTONE_DELETE: value=%s block=%s" % (deletion, dblock))
        else:
            print("TOMBSTONE_DELETE: value=%s not found, no change" % deletion)
        print("BLOCKS_BEFORE_DELETE: %d" % block_before)
        print("BLOCKS_AFTER_DELETE: %d" % len(blocks))
        print("COMPACTION_PERFORMED: NO")
    tombstones = sum(1 for block in blocks for entry in block if not entry[1])
    reads_total = reads
    print("TOMBSTONE_COUNT: %d" % tombstones)
    print("FILE_BLOCKS:")
    for block_index, block in enumerate(blocks):
        shown = " ".join(entry[0] + ("*" if not entry[1] else "") for entry in block)
        print("  BLK%02d %s" % (block_index, shown))
    print("BLOCK_READS: %d" % reads_total)
    print("BLOCK_WRITES: %d" % writes)


if __name__ == "__main__":
    main()
