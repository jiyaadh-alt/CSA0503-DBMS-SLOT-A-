import math
import sys


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: sequential file has no records and no blocks")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first token must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    if count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BINARY_SEARCH_BLOCK_READS: 0")
        print("HEAP_FULL_SCAN_BLOCK_READS: 0")
        return
    keys = []
    for token in raw[1:1 + count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: sequential keys must be integers")
            return
    if len(keys) < count:
        print("INPUT ERROR: expected %d keys, got %d" % (count, len(keys)))
        return
    extras = raw[1 + count:]
    capacity = 10
    target = keys[count // 2]
    if len(extras) >= 1:
        try:
            capacity = int(extras[0])
        except ValueError:
            print("INPUT ERROR: block capacity must be an integer")
            return
    if len(extras) >= 2:
        try:
            target = int(extras[1])
        except ValueError:
            print("INPUT ERROR: search key must be an integer")
            return
    if capacity <= 0:
        print("INPUT ERROR: block capacity must be positive")
        return
    if keys != sorted(keys):
        print("INPUT ERROR: sequential file keys must be in ascending order")
        return
    blocks = []
    writes = 0
    for start in range(0, count, capacity):
        block = list(keys[start:start + capacity])
        blocks.append(block)
        writes += 1
    reads = 0
    trace = []
    lo = 0
    hi = len(blocks) - 1
    chosen = None
    found = False
    while lo <= hi:
        mid = (lo + hi) // 2
        reads += 1
        block = blocks[mid]
        trace.append("read BLK%02d range=%d..%d" % (mid, block[0], block[-1]))
        if target < block[0]:
            hi = mid - 1
        elif target > block[-1]:
            lo = mid + 1
        else:
            chosen = mid
            found = target in block
            trace.append("sequential scan inside BLK%02d found=%s" % (mid, found))
            break
    block_count = len(blocks)
    worst_binary = math.ceil(math.log2(block_count)) + 1 if block_count else 0
    print("INPUT: record_count=%d block_capacity=%d search_key=%d" % (count, capacity, target))
    print("FILE_BLOCKS:")
    for index, block in enumerate(blocks):
        print("  BLK%02d min=%d max=%d keys=%s" % (index, block[0], block[-1], ",".join(str(k) for k in block)))
    print("BINARY_SEARCH_TRACE:")
    for line in trace:
        print("  " + line)
    print("SEARCH_RESULT: found=%s block=%s" % (found, chosen))
    print("BINARY_SEARCH_BLOCK_READS: %d" % reads)
    print("BLOCK_READS: %d" % reads)
    print("WORST_CASE_BINARY_SEARCH_BLOCK_READS: %d" % worst_binary)
    print("HEAP_FULL_SCAN_BLOCK_READS: %d" % block_count)
    print("INSERTION_COST_SEQUENTIAL: shift records and rewrite up to %d blocks" % block_count)
    print("INSERTION_COST_HEAP: append one block when the tail block is full")
    print("BLOCK_WRITES: %d" % writes)


if __name__ == "__main__":
    main()
