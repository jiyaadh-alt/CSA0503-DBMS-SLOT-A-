import sys


class BTree:
    def __init__(self):
        self.blocks = []
        self.root = None
        self.reads = 0
        self.writes = 0
        self.splits = 0

    def read(self, index):
        self.reads += 1
        return self.blocks[index]

    def write(self, index, node):
        self.writes += 1
        self.blocks[index] = node
        return index

    def new(self, node):
        self.writes += 1
        self.blocks.append(node)
        return len(self.blocks) - 1

    def insert(self, key):
        if self.root is None:
            self.root = self.new({"keys": [key], "children": []})
            return
        promoted = self.insert_below(self.root, key)
        if promoted is not None:
            separator, left, right = promoted
            self.root = self.new({"keys": [separator], "children": [left, right]})

    def insert_below(self, index, key):
        node = self.read(index)
        if not node["children"]:
            keys = sorted(node["keys"] + [key])
            if len(keys) <= 4:
                node["keys"] = keys
                self.write(index, node)
                return None
            middle = keys[2]
            left_keys = keys[:2]
            right_keys = keys[3:]
            left_index = self.write(index, {"keys": left_keys, "children": []})
            right_index = self.new({"keys": right_keys, "children": []})
            self.splits += 1
            return middle, left_index, right_index
        position = 0
        while position < len(node["keys"]) and key >= node["keys"][position]:
            position += 1
        promoted = self.insert_below(node["children"][position], key)
        if promoted is None:
            return None
        separator, left_index, right_index = promoted
        keys = list(node["keys"])
        children = list(node["children"])
        keys.insert(position, separator)
        children[position] = left_index
        children.insert(position + 1, right_index)
        if len(keys) <= 4:
            node["keys"] = keys
            node["children"] = children
            self.write(index, node)
            return None
        middle = keys[2]
        new_left = self.write(index, {"keys": keys[:2], "children": children[:3]})
        new_right = self.new({"keys": keys[3:], "children": children[3:]})
        self.splits += 1
        return middle, new_left, new_right

    def inorder(self):
        values = []

        def walk(index):
            node = self.read(index)
            for position, key in enumerate(node["keys"]):
                if node["children"]:
                    walk(node["children"][position])
                values.append(key)
            if node["children"]:
                walk(node["children"][len(node["keys"])])

        if self.root is not None:
            walk(self.root)
        return values

    def leaf_depths(self):
        depths = []

        def walk(index, depth):
            node = self.read(index)
            if not node["children"]:
                depths.append(depth)
                return
            for child in node["children"]:
                walk(child, depth + 1)

        if self.root is not None:
            walk(self.root, 1)
        return depths

    def levels(self):
        result = []
        if self.root is None:
            return result
        current = [self.root]
        while current:
            result.append(current)
            following = []
            for index in current:
                following.extend(self.blocks[index]["children"])
            current = following
        return result


def main():
    raw = sys.stdin.read().split()
    if not raw:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("BOUNDARY CASE: B-tree has no root and no nodes")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    try:
        count = int(raw[0])
    except ValueError:
        print("INPUT ERROR: first token must be the record count")
        return
    if count < 0:
        print("INPUT ERROR: record count must be non-negative")
        return
    keys = []
    for token in raw[1:1 + count]:
        try:
            keys.append(int(token))
        except ValueError:
            print("INPUT ERROR: asset IDs must be integers")
            return
    if len(keys) < count:
        print("INPUT ERROR: expected %d asset IDs, got %d" % (count, len(keys)))
        return
    tree = BTree()
    if count == 0:
        print("EMPTY INPUT: 0 records, 0 blocks")
        print("TREE_LEVELS: 0")
        print("BLOCK_READS: 0")
        print("BLOCK_WRITES: 0")
        return
    for key in keys:
        tree.insert(key)
    traversal = tree.inorder()
    depths = tree.leaf_depths()
    print("INPUT: record_count=%d order=5 max_keys=4" % count)
    print("ASSET_IDS: %s" % " ".join(str(k) for k in keys))
    levels = tree.levels()
    print("TREE_LEVELS: %d" % len(levels))
    for level_no, level in enumerate(levels):
        rendered = []
        for index in level:
            node = tree.blocks[index]
            rendered.append("B%02d[%s]" % (index, ",".join(str(k) for k in node["keys"])))
        print("LEVEL_%d: %s" % (level_no, " ".join(rendered)))
    print("SORTED_TRAVERSAL: %s" % " ".join(str(k) for k in traversal))
    print("SORTED_TRAVERSAL_VERIFIED: %s" % (traversal == sorted(keys)))
    print("LEAF_DEPTHS: %s" % ",".join(str(d) for d in depths))
    print("EQUAL_LEAF_DEPTH_VERIFIED: %s" % (bool(depths) and len(set(depths)) == 1))
    print("NODE_SPLITS: %d" % tree.splits)
    print("BLOCK_READS: %d" % tree.reads)
    print("BLOCK_WRITES: %d" % tree.writes)


if __name__ == "__main__":
    main()
