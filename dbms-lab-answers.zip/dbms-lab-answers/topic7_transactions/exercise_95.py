import re
import sys
from collections import defaultdict

TOKEN_RE = re.compile(r"([SXURC])(\d+)(?:\(([A-Za-z0-9_]+)\))?", re.IGNORECASE)


def new_state():
    return {"holders": defaultdict(dict), "queues": defaultdict(list)}


def parse_line(text):
    operations = []
    unparsed = []
    for token in re.split(r"[\s,]+", text.strip()):
        if not token:
            continue
        match = TOKEN_RE.fullmatch(token)
        if match is None:
            unparsed.append(token)
            continue
        operations.append((match.group(1).upper(), int(match.group(2)), match.group(3).upper() if match.group(3) else None))
    return operations, unparsed


def grantable(item, tid, mode, state, position):
    holders = state["holders"][item]
    queue = state["queues"][item]
    earlier = queue[:position]
    if mode == "S":
        if any(request_mode in ("X", "U") for _, request_mode in earlier):
            return False
        return not any(holder_mode == "X" and holder != tid for holder, holder_mode in holders.items())
    if earlier:
        return False
    return all(holder == tid for holder in holders)


def drain(item, state):
    holders = state["holders"][item]
    queue = state["queues"][item]
    while queue:
        position = 0
        tid, mode = queue[0]
        if not grantable(item, tid, mode, state, position):
            break
        queue.pop(position)
        holders[tid] = "X" if mode in ("X", "U") else "S"


def request(tid, item, mode, state):
    holders = state["holders"][item]
    queue = state["queues"][item]
    if mode == "U" and holders.get(tid) != "S":
        return "INVALID_UPGRADE (T%d does not hold S on %s)" % (tid, item)
    if mode in ("X", "U") and holders.get(tid) == "X":
        return "ALREADY_HELD_X"
    if mode == "S" and holders.get(tid) in ("S", "X"):
        return "ALREADY_HELD_S"
    queue.append((tid, mode))
    before = len(queue)
    drain(item, state)
    if len(queue) < before:
        return "GRANTED_UPGRADE" if mode == "U" else "GRANTED_%s" % mode
    return "WAITING (behind %s)" % (", ".join("T%d:%s" % entry for entry in queue[:queue.index((tid, mode))]) or "holder")


def release_one(tid, item, state):
    holders = state["holders"][item]
    queue = state["queues"][item]
    holders.pop(tid, None)
    state["queues"][item] = [entry for entry in queue if entry[0] != tid]
    queue = state["queues"][item]
    drain(item, state)
    return "RELEASED"


def commit(tid, state):
    affected = [item for item, holders in state["holders"].items() if tid in holders]
    affected += [item for item, queue in state["queues"].items() if any(entry[0] == tid for entry in queue)]
    for item in sorted(set(affected)):
        state["holders"][item].pop(tid, None)
        state["queues"][item] = [entry for entry in state["queues"][item] if entry[0] != tid]
        drain(item, state)
    return "COMMIT_RELEASED_%d_ITEMS" % len(set(affected))


def snapshot(state):
    items = sorted(set(state["holders"]) | set(state["queues"]))
    holders = []
    queues = []
    for item in items:
        if state["holders"][item]:
            holders.append("%s:%s" % (item, ",".join("T%d=%s" % (tid, mode) for tid, mode in sorted(state["holders"][item].items()))))
        if state["queues"][item]:
            queues.append("%s:[%s]" % (item, ",".join("T%d:%s" % entry for entry in state["queues"][item])))
    return " | ".join(holders) if holders else "-", " | ".join(queues) if queues else "-"


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("REQUEST_COUNT: 0")
        print("HOLDERS: -")
        print("FIFO_QUEUES: -")
        print("RESULT: no locks held and no waiters")
        return
    for index, line in enumerate(lines, 1):
        operations, unparsed = parse_line(line)
        state = new_state()
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("UNPARSED: %s" % (", ".join(unparsed) if unparsed else "NONE"))
        for step, (kind, tid, item) in enumerate(operations, 1):
            if kind == "C":
                result = commit(tid, state)
            elif item is None:
                result = "INVALID (no item)"
            elif kind == "R":
                result = release_one(tid, item, state)
            else:
                result = request(tid, item, kind, state)
            holders, queues = snapshot(state)
            print("OP %d: %s -> %s" % (step, kind + str(tid) + ("(" + item + ")" if item else ""), result))
            print("  HOLDERS: %s" % holders)
            print("  FIFO_QUEUES: %s" % queues)
        print("RESULT: final state shown above; releases processed at commit and after every grant")
        print()


if __name__ == "__main__":
    main()
