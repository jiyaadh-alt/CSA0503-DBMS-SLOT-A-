# Topic 7: Transaction Management, Concurrency Control and Recovery — Lab Notes

All answer files live in this directory only. Every `.py` file is Python 3 standard library only, reads one case per non-empty line from stdin, prints labelled deterministic output, and prints a `BOUNDARY EMPTY INPUT` block when stdin is empty (or blank). Multiple input lines are labelled `RUN 1`, `RUN 2`, ... in input order. Verification performed:

```
python3 -m py_compile exercise_91.py ... exercise_102.py
```

## General schedule notation (91, 92, 93, 99)

A schedule is a whitespace/comma separated sequence of tokens:

| Token | Meaning |
| --- | --- |
| `r7(X)` | transaction T7 reads item X |
| `w7(X)` | transaction T7 writes item X |
| `c7` | T7 commits (non-conflicting for precedence-graph purposes) |
| `a7` | T7 aborts |

Transaction numbers are timestamps where used (91, 96–99): lower number = older transaction. Item names are upper-cased. Unrecognised tokens are reported on the `UNPARSED:` line and ignored.

---

## Exercise 91 — precedence graph, topological order / cycle witness (`exercise_91.py`)

**Algorithm.** For every pair of operations on the same item from different transactions, if at least one operation is a write, add an edge from the earlier operation's transaction to the later one. Commit/abort operations never conflict. Duplicate edges are removed with a set. Kahn's algorithm with numerically sorted ready transactions produces a deterministic topological order; if no order exists, a DFS back edge gives a deterministic cycle witness.

**Input.** One schedule per line, general notation above.

**Output 1 sample** (serializable):

```
printf '%s\n' 'r7(X) w7(X) r8(X) w8(X) c7 c8' | python3 exercise_91.py
```

Key result: `EDGES: T7 -> T8`, `RESULT: CONFLICT_SERIALIZABLE`, `TOPOLOGICAL_ORDER: T7 -> T8`, `CYCLE_WITNESS: NONE`.

**Output 2 sample** (cyclic):

```
printf '%s\n' 'w7(X) w8(X) w8(Y) w7(Y) c7 c8' | python3 exercise_91.py
```

Key result: `EDGES: T7 -> T8, T8 -> T7`, `RESULT: NOT_CONFLICT_SERIALIZABLE`, `TOPOLOGICAL_ORDER: NONE`, `CYCLE_WITNESS: T7 -> T8 -> T7`. The X conflict gives T7→T8 and the Y conflict gives T8→T7.

**Boundary.**

```
printf '\n' | python3 exercise_91.py
```

prints `SCHEDULE_COUNT: 0`, `PRECEDENCE_GRAPH: EMPTY`, `TOPOLOGICAL_ORDER: [] (vacuously serializable)`, `CYCLE_WITNESS: NONE`.

---

## Exercise 92 — exhaustive view-serializability checker (`exercise_92.py`)

**Algorithm.** A view is the triple (initial reads, reads-from writer per read occurrence, final writer per item). The program enumerates all transaction permutations (up to 7 transactions), builds the corresponding serial schedule by concatenating each transaction's operations in program order, and accepts a permutation only when its view is exactly equal. It also builds the conflict precedence graph so the two tests can be compared. A blind write is a write not preceded by a read of that item by the same transaction.

**Input.** One schedule per line. More than 7 transactions reports `VIEW_SERIALIZABLE: NOT_ENUMERATED` instead of guessing.

**Sample (blind-write case where the results differ):**

```
printf '%s\n' 'w1(X) r2(X) w2(Y) r2(Y) w1(Y) w2(Y) c1 c2' | python3 exercise_92.py
```

Result: `READS_FROM: r2[1](X)<=T1, r2[1](Y)<=T2`, `FINAL_WRITER: X=T1, Y=T2`, `CONFLICT_SERIALIZABLE: NO`, `VIEW_SERIALIZABLE: YES`, `EQUIVALENT_SERIAL_ORDERS: T1 -> T2`. The blind writes `w2(Y)` before `w1(Y)` and `w1(Y)` create the precedence cycle T1→T2→T1, but they are never observed by a read and the final writer of Y is T2, so the serial order T1,T2 has the same view. Conflict serializability is sufficient, not necessary.

**Sample with initial reads:**

```
printf '%s\n' 'r7(X) w7(X) r8(X) w8(Y) c7 c8' | python3 exercise_92.py
```

shows `r7[1](X)<=INITIAL`, `r8[1](X)<=T7`, final writers `X=T7, Y=T8`, and the equivalent order `T7 -> T8`.

**Boundary.** Empty stdin prints `VIEW: EMPTY` and both serializability tests `YES (vacuously ...)`.

---

## Exercise 93 — recoverable / cascadeless / strict classification (`exercise_93.py`)

**Algorithm.** While scanning, the program keeps the last writer of each item, the set of committed/aborted writers, and read dependencies (reader, writer). At a commit it checks whether the reader committed before every writer it read from resolved. At every read it flags a dirty read when the last writer is another uncommitted transaction; at every read or write it flags a strictness violation when another transaction's uncommitted value is still installed. The first operation for each condition is printed with a reason.

**Input.** One schedule per line.

**Output 1 sample** (fails all three):

```
printf '%s\n' 'r7(X) w7(X) r8(X) w8(X) c8 c7' | python3 exercise_93.py
```

Expected: `RECOVERABLE: NO`, `CASCADELESS: NO`, `STRICT: NO`, `CLASSIFICATION: NOT_RECOVERABLE`, first recoverable violation `c8 [T8 commits before writer T7 resolves]`, first cascadeless and strict violations `r8(X)`.

**Output 2 sample** (recoverable only):

```
printf '%s\n' 'w7(X) r8(X) c7 c8' | python3 exercise_93.py
```

Expected: `RECOVERABLE: YES`, `CASCADELESS: NO`, `STRICT: NO`, `CLASSIFICATION: RECOVERABLE_ONLY`, first recoverable violation `NONE`, first cascadeless/strict violation `r8(X)`. T8 read dirty but committed after T7, so recovery is still possible.

**Boundary.** Empty stdin prints all three properties `YES (vacuously)` and `FIRST_VIOLATIONS: NONE`.

---

## Exercise 94 — threading events (`exercise_94.py`)

**Input.** One scenario name per line, with optional integers:

| Line | Meaning |
| --- | --- |
| `LOST_UPDATE [start] [delta1] [delta2]` | two workers forced by `threading.Event` to read the same stock before either writes |
| `LOCKED_UPDATE [start] [delta1] [delta2]` | same two workers, but the full read–modify–write section is inside one `threading.Lock` |
| `DIRTY_READ [start] [uncommitted]` | T7 writes uncommitted, T8 reads, T7 aborts; repeated with a transaction-wide lock |
| `MIXED_TIME [stockA] [stockB] [transfer]` | summary reads one store before and one after a committed transfer; repeated under a transaction-wide lock |

Defaults: `LOST_UPDATE 22 5 4`, `LOCKED_UPDATE 22 5 4`, `DIRTY_READ 22 17`, `MIXED_TIME 100 60 30`. Unknown names print `SCENARIO: UNKNOWN`.

**Sample and expectations:**

```
printf '%s\n' 'LOST_UPDATE 22 5 4' 'LOCKED_UPDATE 22 5 4' 'DIRTY_READ 22 17' 'MIXED_TIME 100 60 30' | python3 exercise_94.py
```

- RUN 1: both workers read 22, writes are 17 then 18, `FINAL_QTY: 18` instead of `SERIAL_EXPECTED: 13` — 5 units lost.
- RUN 2: locked workers read 22 then 17, `FINAL_QTY: 13`, `LOST_UPDATE: NO`.
- RUN 3: unprotected T8 reads 17 and keeps it after T7 aborts to 22; transaction-wide protection makes T8 wait and read 22.
- RUN 4: unprotected summary `BEFORE=60 AFTER=70 SUM=130 EXPECTED=160`; protected summary reads 60 and 100, sums to 160, while the final stock is A=70, B=90.

Events (not sleeps) fix the interleaving, so repeated runs print identical text.

---

## Exercise 95 — shared/exclusive locks, FIFO queues, upgrade (`exercise_95.py`)

**Input.** One lock-request sequence per line:

| Token | Meaning |
| --- | --- |
| `S7(X)` / `X7(X)` | T7 requests shared / exclusive lock on X |
| `U7(X)` | T7 upgrades its shared lock on X to exclusive (keeps S while waiting) |
| `R7(X)` | T7 releases X explicitly |
| `C7` | T7 commits: all its locks are released and its queued requests are removed |

A new request is queued behind every existing queued request for that item; the queue is drained from the front only, so a later shared request cannot bypass a queued exclusive or upgrade request. The holders and FIFO queue are printed after every operation.

**Sample:**

```
printf '%s\n' 'S7(X) S8(X) X7(X) S9(X) C8 C7' | python3 exercise_95.py
```

`S7` and `S8` are granted; `X7(X)` waits (upgrade by implication of an X request from an S holder); `S9(X)` waits behind `T7:X` even though S would be compatible with the S holders. `C8` upgrades T7 to X, `C7` then grants T9's S. A second sample `X7(A) X8(B) X8(A) X7(B)` shows two waiting queues; this program intentionally does not abort (deadlock handling is Exercise 96).

---

## Exercise 96 — wait-for graph and younger-victim abort (`exercise_96.py`)

**Input.** Same lock tokens as Exercise 95. After every operation the program prints wait-for edges `waiter -> blocker` (blockers are conflicting holders and earlier conflicting waiters). When a cycle is found it prints the cycle, aborts the numerically largest (youngest) transaction in the cycle, releases its locks and waiting requests, drains newly unblocked queues and prints `NEWLY_GRANTED_AFTER_ABORT`.

**Sample:**

```
printf '%s\n' 'X7(A) X8(B) X8(A) X7(B)' | python3 exercise_96.py
```

At OP 4: `CYCLE: T7 -> T8 -> T7`, `VICTIM: T8 (youngest in cycle; lower transaction number is older)`, `VICTIM_RELEASED: A,B`, `NEWLY_GRANTED_AFTER_ABORT: T7:X(B)`, and the graph becomes empty. A second sample `S7(X) S8(X) U7(X) S9(X) C8` shows an upgrade waiting behind another S holder and being granted after that holder commits.

---

## Exercise 97 — wait-die vs wound-wait (`exercise_97.py`)

**Input.** One case per line: `A` (or `CASE_A`) and `B` (or `CASE_B`). State is reset before each case. TS(T7)=7, TS(T8)=8; lower timestamp is older.

**Sample.**

```
printf '%s\n' 'A' 'B' | python3 exercise_97.py
```

- Case A: T8 holds X(X2), T7 requests X(X2). Wait-die: older requester `WAITS`. Wound-wait: older requester `ABORTS_HOLDER T8`, then gets the lock.
- Case B: T7 holds X(Y2), T8 requests X(Y2). Wait-die: younger requester `ABORTS_REQUESTER T8`. Wound-wait: younger requester `WAITS`.

---

## Exercise 98 — InnoDB two-session script (`exercise_98.sql`)

This file contains SQL statements only; labels are `SELECT '...' AS label;` statements, not comments. Run the labelled statements in two separate MySQL connections (Session 1 and Session 2), in the printed order, with InnoDB and a lock wait timeout that allows observation.

1. Setup (Session 1) creates `STOCK(SKU VARCHAR(10) PRIMARY KEY, Qty INT NOT NULL)` with row `('X2', 12)`.
2. Case 1: Session 1 `START TRANSACTION; SELECT ... FOR UPDATE;` holds an exclusive lock on X2. Session 2's `UPDATE STOCK SET Qty = 7 WHERE SKU = 'X2';` blocks until Session 1's `COMMIT`, then completes.
3. Reset: Session 1 restores `Qty = 12`.
4. Case 2 (READ COMMITTED): Session 1 starts a transaction and reads 12; Session 2 commits `Qty = 7`; Session 1's second plain SELECT sees 7 (new snapshot per statement).
5. Reset and Case 3 (REPEATABLE READ): same steps, but Session 1's second plain SELECT still sees 12 (snapshot established by the first read in the transaction).
6. Reset and Case 4 (SERIALIZABLE with `autocommit = 0`): a plain SELECT inside Session 1's transaction takes a shared locking read, so Session 2's UPDATE blocks until Session 1 commits. Cleanup restores autocommit and REPEATABLE READ.
7. The final `BOUNDARY EMPTY INPUT` SELECTs return a label and `step_count = 0`, the SQL equivalent of the Python boundary block.

Caveat: a single automated client that executes the whole file in one connection cannot demonstrate blocking; the Session 2 statements must be run in a second terminal while the Session 1 transaction is open. Expected values are 12/7 for the READ COMMITTED pair, 12/12 for the REPEATABLE READ pair, and a blocked UPDATE in the SERIALIZABLE case.

---

## Exercise 99 — basic timestamp ordering and Thomas write rule (`exercise_99.py`)

**Input.** One schedule per line, general notation. `read_TS` and `write_TS` start at 0 for every item; default item is X2 when a read/write omits `(item)`.

Rules implemented:

- Read by T: abort T if `TS(T) < write_TS(item)`; otherwise grant and set `read_TS = max(read_TS, TS(T))`.
- Write by T: abort T if `TS(T) < read_TS(item)`; else if `TS(T) < write_TS(item)`, ignore the obsolete write by the Thomas write rule (T is not aborted); else grant and set `write_TS = TS(T)`.
- Once T aborts, all its remaining operations are reported as `SKIPPED`.

**Sample.**

```
printf '%s\n' 'w8(X2) w7(X2) r7(X2) c7 c8' 'r8(X2) w7(X2) r7(X2) c7 c8' | python3 exercise_99.py
```

RUN 1: `w8` grants (`write_TS=8`), stale blind `w7` is `IGNORED (Thomas write rule: 7 < write_TS=8)`, the stale `r7` aborts T7, `c7` is skipped, `c8` commits. RUN 2: `r8` grants (`read_TS=8`), `w7` aborts by the basic TO rule, and its remaining operations are skipped. This is the requested comparison: a stale blind write is ignored, a stale read is fatal.

---

## Exercise 100 — immediate-update recovery (`exercise_100.py`)

**Input.** One case per line; tokens separated by `|` (or spaces):

`INIT(X2=12,X3=30)` initial disk image · `B(T7)` begin · `W(T7,X2,12,17)` write with before image, after image · `C(T7)` commit · `A(T8)` abort · `F(T8,X2)` steal a dirty page to disk · `CP` quiescent force checkpoint · `CRASH` end of log (later tokens ignored).

**Algorithm.** The checkpoint forces all dirty pages and has no active transaction (`CHECKPOINT_QUIESCENT:` verifies this). Recovery starts from the disk image at crash (which may contain stolen uncommitted pages), redoes committed writes after the checkpoint in log order, then undoes incomplete/aborted writes in reverse log order using before images.

**Sample.**

```
printf '%s\n' 'INIT(X2=12,X3=30) | B(T7) | W(T7,X3,30,25) | C(T7) | CP | B(T8) | W(T8,X2,12,19) | F(T8,X2) | B(T9) | W(T9,X3,25,20) | C(T9) | CRASH' | python3 exercise_100.py
```

Result: checkpoint `X2=12, X3=25`; disk at crash `X2=19, X3=25` (T8's page was stolen); `REDO: L8 W(T9,X3,25,20)->20`; `UNDO: L5 W(T8,X2,12,19)->12`; `RECOVERED_QUANTITIES: X2=12, X3=20`; `RECOVERY_WORK: redo_records=1 undo_records=1`.

---

## Exercise 101 — deferred update recovery (`exercise_101.py`)

**Input.** Like Exercise 100 but writes are new-value-only: `W(T7,X3,25)`. `F(T9,X3)` may flush a committed page; flushing an uncommitted page is reported as `IGNORED_UNCOMMITTED` because deferred updates stay in a buffer. `CP`, `CRASH` and `INIT` are unchanged.

**Algorithm.** Recovery restarts from the checkpoint image and redoes the new values of committed transactions after the checkpoint. There is no undo phase: an incomplete transaction's values were never installed on disk, so they disappear at crash. `IMMEDIATE_UPDATE_COMPARISON` reports the undo records that immediate update would have needed for the same log.

**Sample.**

```
printf '%s\n' 'INIT(X2=12,X3=30) | B(T7) | W(T7,X3,25) | C(T7) | CP | B(T8) | W(T8,X2,19) | A(T8) | B(T9) | W(T9,X3,20) | C(T9) | CRASH' | python3 exercise_101.py
```

Result: `REDO: L8 W(T9,X3,20)->20`, `UNDO: NONE`, `IMMEDIATE_UPDATE_COMPARISON: immediate redo_records=1 immediate undo_records=1 deferred undo_records=0`, `RECOVERED_QUANTITIES: X2=12, X3=20`, `RECOVERY_WORK: redo_records=1 undo_records=0`.

---

## Exercise 102 — six-page shadow paging (`exercise_102.py`)

**Input.** One scenario per line: `COMMIT` (or `SWITCH`) or `CRASH`, with optional `PAGES(1,4)`, `FREE(220,221)`, `MAPFREE(222)`. Defaults match the exercise statement.

**Simulation.** Base physical map `[210,211,212,213,214,215]`, root pointer 210. Logical pages 1 and 4 are copied to free pages 220 and 221, producing working map `[220,211,212,213,221,215]`, stored in a new map page 222. A commit performs the single atomic root switch 210→222 and keeps 210 as the old shadow. A crash before the switch leaves root 210 current; 220, 221 and 222 are reported as orphan pages and the recovered map is the base map.

**Sample.**

```
printf '%s\n' 'COMMIT' 'CRASH' | python3 exercise_102.py
```

RUN 1 prints `WORKING_MAP: P1->220, P2->211, P3->212, P4->221, P5->214, P6->215`, `ROOT_BEFORE: 210`, `ROOT_AFTER: 222`, `OLD_SHADOW_MAP: 210 retained for recovery`. RUN 2 prints `ROOT_AFTER: 210 (unchanged)`, `ORPHAN_PAGES: 220, 221, 222` and the original committed map.

---

## Caveats and limits

- Precedence graphs in 91/92 include every conflicting pair, not just the last writer, so edge sets can contain redundant edges; cycle/topological results are unaffected.
- View checking in 92 is exhaustive only up to 7 transactions by design, to keep a lab-scale bound on factorial enumeration.
- Strictness in 93 treats a resolved (committed or aborted) prior writer as safe; an abort restores the last committed value, so a subsequent read is not a dirty read.
- Lock programs 95/96 implement item-level S/X/U locks with FIFO queues and commit-time release; they do not model index/key-range locking or transaction timestamps beyond the explicit victim choice.
- Recovery programs 100/101 simulate a quiescent force checkpoint and a log truncated at `CRASH`; they do not model page LSNs, repeated checkpoints after the last one, or physical media failure.
- Exercise 98 requires two live MySQL sessions; a single-session run of the whole file will block at the Session 2 UPDATE until the corresponding Session 1 transaction is committed from the other terminal.
