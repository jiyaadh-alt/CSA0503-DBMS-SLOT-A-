import sys

CASES = {
    "A": {"holder": 8, "requester": 7, "item": "X2", "description": "T8 holds X(X2), T7 requests X(X2)"},
    "B": {"holder": 7, "requester": 8, "item": "Y2", "description": "T7 holds X(Y2), T8 requests X(Y2)"},
}


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("CASE_COUNT: 0")
        print("WAIT_DIE: NO_DECISION")
        print("WOUND_WAIT: NO_DECISION")
        print("RESULT: no conflicting request supplied; both schemes are idle")
        return
    for index, line in enumerate(lines, 1):
        token = line.upper().replace("CASE", "").replace("_", "").replace("-", "").strip()
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        if token not in CASES:
            print("CASE: UNKNOWN")
            print("RESULT: expected A or B; state not changed")
            print()
            continue
        case = CASES[token]
        holder = case["holder"]
        requester = case["requester"]
        older_requester = requester < holder
        if older_requester:
            wait_die = "WAITS (older requester is never killed)"
            wound_wait = "ABORTS_HOLDER T%d; X(%s) granted to T%d" % (holder, case["item"], requester)
        else:
            wait_die = "ABORTS_REQUESTER T%d (younger requester dies)" % requester
            wound_wait = "WAITS (younger requester never wounds an older holder)"
        print("CASE: %s" % token)
        print("SETUP: %s; TS(T%d)=%d, TS(T%d)=%d (lower timestamp is older)" % (case["description"], requester, requester, holder, holder))
        print("STATE_RESET: YES (fresh lock table before this case)")
        print("WAIT_DIE: %s" % wait_die)
        print("WOUND_WAIT: %s" % wound_wait)
        print("RESULT: %s" % ("schemes differ for this case" if older_requester else "schemes differ for this case"))
        print()


if __name__ == "__main__":
    main()
