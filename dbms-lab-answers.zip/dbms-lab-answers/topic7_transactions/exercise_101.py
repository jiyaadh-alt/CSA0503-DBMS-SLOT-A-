import re
import sys

PATTERNS = [
    ("INIT", re.compile(r"INIT\(([^)]*)\)", re.IGNORECASE)),
    ("BEGIN", re.compile(r"B\(T(\d+)\)", re.IGNORECASE)),
    ("WRITE", re.compile(r"W\(T(\d+),([A-Za-z0-9_]+),(-?\d+)\)", re.IGNORECASE)),
    ("COMMIT", re.compile(r"C\(T(\d+)\)", re.IGNORECASE)),
    ("ABORT", re.compile(r"A\(T(\d+)\)", re.IGNORECASE)),
    ("FLUSH", re.compile(r"F\(T(\d+),([A-Za-z0-9_]+)\)", re.IGNORECASE)),
    ("CHECKPOINT", re.compile(r"CP", re.IGNORECASE)),
    ("CRASH", re.compile(r"CRASH", re.IGNORECASE)),
]


def parse_tokens(text):
    tokens = [part.strip() for part in re.split(r"[|]", text) if part.strip()]
    if len(tokens) == 1 and " " in tokens[0]:
        tokens = tokens[0].split()
    return tokens


def parse_event(token):
    for name, pattern in PATTERNS:
        match = pattern.fullmatch(token)
        if match is None:
            continue
        if name == "INIT":
            values = {}
            for pair in match.group(1).split(","):
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    try:
                        values[key.strip().upper()] = int(value.strip())
                    except ValueError:
                        pass
            return (name, values)
        if name == "WRITE":
            return (name, (int(match.group(1)), match.group(2).upper(), int(match.group(3))))
        if name in ("BEGIN", "COMMIT", "ABORT"):
            return (name, int(match.group(1)))
        if name == "FLUSH":
            return (name, (int(match.group(1)), match.group(2).upper()))
        return (name, None)
    return ("UNKNOWN", token)


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("CASE_COUNT: 0")
        print("INITIAL_DISK: -")
        print("CHECKPOINT: NONE")
        print("REDO: NONE")
        print("UNDO: NONE (no deferred transaction buffered)")
        print("RESULT: no recovery performed")
        return
    for index, line in enumerate(lines, 1):
        events = [parse_event(token) for token in parse_tokens(line)]
        initial = {}
        log = []
        disk = {}
        buffer = {}
        pending = {}
        checkpoint_position = None
        checkpoint_state = None
        unparsed = []
        flush_notes = []
        for kind, payload in events:
            if kind == "CRASH":
                break
            if kind == "INIT":
                initial.update(payload)
                disk.update(payload)
                buffer.update(payload)
            elif kind == "BEGIN":
                log.append(("BEGIN", payload, None))
                pending[payload] = set()
            elif kind == "WRITE":
                tid, item, value = payload
                pending.setdefault(tid, set()).add(item)
                buffer[item] = value
                log.append(("WRITE", payload, len(log) + 1))
            elif kind == "COMMIT":
                log.append(("COMMIT", payload, None))
                for item in pending.get(tid, set()):
                    if item in buffer:
                        disk[item] = buffer[item]
            elif kind == "ABORT":
                log.append(("ABORT", payload, None))
                for item in pending.get(tid, set()):
                    if item in buffer:
                        buffer[item] = disk.get(item, buffer[item])
            elif kind == "FLUSH":
                tid, item = payload
                if item in pending.get(tid, set()):
                    flush_notes.append("F(T%d,%s):IGNORED_UNCOMMITTED" % (tid, item))
                else:
                    disk[item] = buffer.get(item, disk.get(item, 0))
                    flush_notes.append("F(T%d,%s):FLUSHED" % (tid, item))
                log.append(("FLUSH", payload, None))
            elif kind == "CHECKPOINT":
                checkpoint_position = len(log)
                checkpoint_state = dict(disk)
            else:
                unparsed.append(payload)
        if checkpoint_state is None:
            checkpoint_state = dict(initial)
            checkpoint_position = 0
        scan_from = checkpoint_position
        committed = {payload for kind, payload, _ in log[scan_from:] if kind == "COMMIT"}
        aborted = {payload for kind, payload, _ in log[scan_from:] if kind == "ABORT"}
        participants = {payload for kind, payload, _ in log[scan_from:] if kind == "BEGIN"} | {payload[0] for kind, payload, _ in log[scan_from:] if kind == "WRITE"}
        redo = [(position, payload) for kind, payload, position in log[scan_from:] if kind == "WRITE" and payload[0] in committed]
        would_undo = [(position, payload) for kind, payload, position in log[scan_from:] if kind == "WRITE" and payload[0] not in committed]
        recovered = dict(checkpoint_state)
        for _, (tid, item, value) in redo:
            recovered[item] = value
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("UNPARSED: %s" % (", ".join(unparsed) if unparsed else "NONE"))
        print("INITIAL_DISK: %s" % (", ".join("%s=%d" % pair for pair in sorted(initial.items())) if initial else "-"))
        log_text = []
        for kind, payload, position in log:
            prefix = "L%d " % position if position else ""
            if kind == "WRITE":
                body = "W(T%d,%s,%d)" % payload
            elif kind == "FLUSH":
                body = "F(T%d,%s)" % payload
            elif kind in ("BEGIN", "COMMIT", "ABORT"):
                body = "%s(T%d)" % (kind.title(), payload)
            else:
                body = kind
            log_text.append(prefix + body)
        print("LOG_NEW_VALUE_ONLY: %s" % (" | ".join(log_text) if log_text else "NONE"))
        print("CHECKPOINT: %s" % ("L%d forced state %s" % (checkpoint_position, ", ".join("%s=%d" % pair for pair in sorted(checkpoint_state.items()))) if checkpoint_position else "NONE (start from initial disk)"))
        status = ["T%d=%s" % (tid, "COMMITTED" if tid in committed else "ABORTED" if tid in aborted else "INCOMPLETE") for tid in sorted(participants)]
        print("TRANSACTION_STATUS: %s" % (", ".join(status) if status else "NONE"))
        print("FLUSH_NOTES: %s" % (", ".join(flush_notes) if flush_notes else "NONE"))
        print("DISK_AT_CRASH: %s" % (", ".join("%s=%d" % pair for pair in sorted(disk.items())) if disk else "-"))
        print("REDO: %s" % (", ".join("L%d W(T%d,%s,%d)->%d" % (position, tid, item, value, value) for position, (tid, item, value) in redo) if redo else "NONE"))
        print("UNDO: NONE (deferred update never writes uncommitted values to disk)")
        print("IMMEDIATE_UPDATE_COMPARISON: immediate redo_records=%d immediate undo_records=%d deferred undo_records=0" % (len(redo), len(would_undo)))
        print("EXPLANATION: only committed new values are redone; incomplete transactions stay in the buffer and vanish at crash")
        print("RECOVERED_QUANTITIES: %s" % (", ".join("%s=%d" % pair for pair in sorted(recovered.items())) if recovered else "-"))
        print("RECOVERY_WORK: redo_records=%d undo_records=0" % len(redo))
        print()


if __name__ == "__main__":
    main()
