import itertools
import re
import sys
from collections import defaultdict

TOKEN_RE = re.compile(r"([rwac])(\d+)(?:\(([A-Za-z0-9_]+)\))?", re.IGNORECASE)
MAX_TRANSACTIONS = 7


def parse_schedule(text):
    operations = []
    unparsed = []
    for token in re.split(r"[\s,]+", text.strip()):
        if not token:
            continue
        match = TOKEN_RE.fullmatch(token)
        if match is None:
            unparsed.append(token)
            continue
        kind = match.group(1).lower()
        tid = int(match.group(2))
        item = match.group(3).upper() if match.group(3) else None
        operations.append((kind, tid, item))
    return operations, unparsed


def data_ops(operations):
    return [(kind, tid, item) for kind, tid, item in operations if kind in ("r", "w") and item]


def view_summary(operations):
    last_writer = {}
    reads_from = {}
    seen_reads = defaultdict(int)
    all_items = set()
    for kind, tid, item in data_ops(operations):
        all_items.add(item)
        if kind == "r":
            seen_reads[(tid, item)] += 1
            reads_from[(tid, item, seen_reads[(tid, item)])] = last_writer.get(item, "INIT")
        else:
            last_writer[item] = tid
    final_writer = {item: last_writer.get(item, "INIT") for item in sorted(all_items)}
    return reads_from, final_writer


def edges_of(operations):
    by_item = defaultdict(list)
    edges = set()
    for kind, tid, item in data_ops(operations):
        for other_kind, other_tid, _ in by_item[item]:
            if other_tid != tid and "w" in (other_kind, kind):
                edges.add((other_tid, tid))
        by_item[item].append((kind, tid, item))
    return edges


def has_cycle(nodes, edges):
    adjacency = {node: sorted(dst for src, dst in edges if src == node) for node in nodes}
    state = {node: 0 for node in nodes}

    def visit(node):
        state[node] = 1
        for dst in adjacency[node]:
            if state[dst] == 1 or (state[dst] == 0 and visit(dst)):
                return True
        state[node] = 2
        return False

    return any(state[node] == 0 and visit(node) for node in nodes)


def format_writer(writer):
    return "INITIAL" if writer == "INIT" else "T%d" % writer


def format_summary(reads_from, final_writer):
    reads = []
    for (tid, item, occurrence), writer in sorted(reads_from.items()):
        label = "r%d[%d](%s)" % (tid, occurrence, item)
        reads.append("%s<=%s" % (label, format_writer(writer)))
    finals = ["%s=%s" % (item, format_writer(writer)) for item, writer in sorted(final_writer.items())]
    return ", ".join(reads) if reads else "NONE", ", ".join(finals) if finals else "NONE"


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("SCHEDULE_COUNT: 0")
        print("VIEW: EMPTY")
        print("VIEW_SERIALIZABLE: YES (vacuously, no schedule supplied)")
        print("CONFLICT_SERIALIZABLE: YES (vacuously, no schedule supplied)")
        return
    for index, line in enumerate(lines, 1):
        operations, unparsed = parse_schedule(line)
        data = data_ops(operations)
        transactions = sorted({tid for _, tid, _ in operations})
        reads_from, final_writer = view_summary(operations)
        read_text, final_text = format_summary(reads_from, final_writer)
        edges = edges_of(operations)
        conflict_serializable = not has_cycle(transactions, edges)
        per_transaction = {tid: [(kind, item) for kind, owner, item in data if owner == tid] for tid in transactions}
        equivalent = []
        if transactions and len(transactions) <= MAX_TRANSACTIONS:
            for order in itertools.permutations(transactions):
                serial_ops = [(kind, tid, item) for tid in order for kind, item in per_transaction[tid]]
                if view_summary(serial_ops) == (reads_from, final_writer):
                    equivalent.append(order)
        blind_writes = []
        read_before = set()
        for kind, tid, item in data:
            if kind == "r":
                read_before.add((tid, item))
            elif (tid, item) not in read_before:
                blind_writes.append("w%d(%s)" % (tid, item))
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("UNPARSED: %s" % (", ".join(unparsed) if unparsed else "NONE"))
        print("TRANSACTIONS: %s" % (", ".join("T%d" % t for t in transactions) if transactions else "NONE"))
        print("READS_FROM: %s" % read_text)
        print("FINAL_WRITER: %s" % final_text)
        edge_text = ["T%d -> T%d" % pair for pair in sorted(edges)]
        print("PRECEDENCE_EDGES: %s" % (", ".join(edge_text) if edge_text else "NONE"))
        print("CONFLICT_SERIALIZABLE: %s" % ("YES" if conflict_serializable else "NO"))
        print("BLIND_WRITES: %s" % (", ".join(blind_writes) if blind_writes else "NONE"))
        if transactions and len(transactions) > MAX_TRANSACTIONS:
            print("VIEW_SERIALIZABLE: NOT_ENUMERATED (more than %d transactions)" % MAX_TRANSACTIONS)
            print("EQUIVALENT_SERIAL_ORDERS: NONE")
        else:
            print("VIEW_SERIALIZABLE: %s" % ("YES" if equivalent else "NO"))
            print("EQUIVALENT_SERIAL_ORDERS: %s" % (" | ".join(" -> ".join("T%d" % t for t in order) for order in equivalent) if equivalent else "NONE"))
        if equivalent and not conflict_serializable:
            print("EXPLANATION: view equivalence holds through reads-from and final-writer equality; the precedence cycle is caused by blind writes")
        elif not equivalent and conflict_serializable:
            print("EXPLANATION: conflict serializability is sufficient, but no serial order preserves every reads-from and final-writer choice")
        else:
            print("EXPLANATION: conflict and view tests agree for this schedule")
        print()


if __name__ == "__main__":
    main()
