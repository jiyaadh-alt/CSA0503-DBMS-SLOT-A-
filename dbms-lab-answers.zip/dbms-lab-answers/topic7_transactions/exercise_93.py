import re
import sys

TOKEN_RE = re.compile(r"([rwac])(\d+)(?:\(([A-Za-z0-9_]+)\))?", re.IGNORECASE)


def parse_schedule(text):
    operations = []
    unparsed = []
    for token in re.split(r"[\s,]+", text.strip()):
        if not token:
            continue
        match = TOKEN_RE.fullmatch(token)
        if match is None:
            unparsed.append(token)
            continue
        kind = match.group(1).lower()
        tid = int(match.group(2))
        item = match.group(3).upper() if match.group(3) else None
        operations.append((kind, tid, item))
    return operations, unparsed


def op_text(kind, tid, item):
    return "c%d" % tid if kind == "c" else "%s%d(%s)" % (kind, tid, item or "?")


def classify(operations):
    committed = set()
    aborted = set()
    last_writer = {}
    committed_writer = {}
    dependencies = []
    written_by = {}
    violations = {"recoverable": None, "cascadeless": None, "strict": None}
    for kind, tid, item in operations:
        if kind == "c":
            bad = [writer for reader, writer in dependencies if reader == tid and writer is not None and writer not in committed]
            if bad and violations["recoverable"] is None:
                violations["recoverable"] = (op_text(kind, tid, item), "T%d commits before writer T%d resolves" % (tid, sorted(bad)[0]))
            committed.add(tid)
            for name in written_by.get(tid, set()):
                committed_writer[name] = tid
            continue
        if kind == "a":
            aborted.add(tid)
            for name, writer in list(last_writer.items()):
                if writer == tid:
                    last_writer[name] = committed_writer.get(name)
            continue
        if item is None:
            continue
        writer = last_writer.get(item)
        if writer is not None and writer != tid and writer not in committed and writer not in aborted:
            if violations["strict"] is None:
                violations["strict"] = (op_text(kind, tid, item), "%s touches %s while writer T%d is uncommitted" % ("T%d" % tid, item, writer))
            if kind == "r" and violations["cascadeless"] is None:
                violations["cascadeless"] = (op_text(kind, tid, item), "T%d reads dirty value of %s written by T%d" % (tid, item, writer))
        if kind == "r":
            if writer is not None and writer != tid:
                dependencies.append((tid, writer))
        elif kind == "w":
            last_writer[item] = tid
            written_by.setdefault(tid, set()).add(item)
    if violations["recoverable"] is None:
        for reader, writer in dependencies:
            if writer is not None and writer not in committed:
                violations["recoverable"] = ("END", "T%d read from uncommitted T%d and never committed after it" % (reader, writer))
                break
    return violations


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("SCHEDULE_COUNT: 0")
        print("RECOVERABLE: YES (vacuously)")
        print("CASCADELESS: YES (vacuously)")
        print("STRICT: YES (vacuously)")
        print("FIRST_VIOLATIONS: NONE")
        return
    for index, line in enumerate(lines, 1):
        operations, unparsed = parse_schedule(line)
        violations = classify(operations)
        transactions = sorted({tid for _, tid, _ in operations})
        recoverable = violations["recoverable"] is None
        cascadeless = violations["cascadeless"] is None
        strict = violations["strict"] is None
        if strict:
            verdict = "STRICT"
        elif cascadeless:
            verdict = "CASCADELESS_ONLY"
        elif recoverable:
            verdict = "RECOVERABLE_ONLY"
        else:
            verdict = "NOT_RECOVERABLE"
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("UNPARSED: %s" % (", ".join(unparsed) if unparsed else "NONE"))
        print("TRANSACTIONS: %s" % (", ".join("T%d" % t for t in transactions) if transactions else "NONE"))
        print("RECOVERABLE: %s" % ("YES" if recoverable else "NO"))
        print("CASCADELESS: %s" % ("YES" if cascadeless else "NO"))
        print("STRICT: %s" % ("YES" if strict else "NO"))
        print("CLASSIFICATION: %s" % verdict)
        for name in ("recoverable", "cascadeless", "strict"):
            entry = violations[name]
            text = "NONE" if entry is None else "%s [%s]" % (entry[0], entry[1])
            print("FIRST_VIOLATION_%s: %s" % (name.upper(), text))
        print("IMPLICATION_STRICT_TO_CASCADELESS_TO_RECOVERABLE: YES")
        print()


if __name__ == "__main__":
    main()
