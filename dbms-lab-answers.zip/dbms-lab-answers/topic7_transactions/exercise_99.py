import re
import sys

TOKEN_RE = re.compile(r"([rwca])(\d+)(?:\(([A-Za-z0-9_]+)\))?", re.IGNORECASE)


def parse_schedule(text):
    operations = []
    unparsed = []
    for token in re.split(r"[\s,]+", text.strip()):
        if not token:
            continue
        match = TOKEN_RE.fullmatch(token)
        if match is None:
            unparsed.append(token)
            continue
        operations.append((match.group(1).lower(), int(match.group(2)), match.group(3).upper() if match.group(3) else "X2"))
    return operations, unparsed


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("OPERATION_COUNT: 0")
        print("ITEM_STATE: NONE (read_TS=0, write_TS=0 per item)")
        print("RESULT: no timestamp-ordering decisions taken")
        return
    for index, line in enumerate(lines, 1):
        operations, unparsed = parse_schedule(line)
        read_ts = {}
        write_ts = {}
        aborted = set()
        skipped = []
        outcomes = {}
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("UNPARSED: %s" % (", ".join(unparsed) if unparsed else "NONE"))
        print("INITIAL: read_TS=0, write_TS=0 for every item; lower transaction number is older")
        for step, (kind, tid, item) in enumerate(operations, 1):
            label = "c%d" % tid if kind == "c" else "%s%d(%s)" % (kind, tid, item)
            if tid in aborted:
                skipped.append(label)
                print("OP %d: %s -> SKIPPED (T%d aborted earlier)" % (step, label, tid))
                continue
            rts = read_ts.get(item, 0)
            wts = write_ts.get(item, 0)
            if kind == "r":
                if tid < wts:
                    aborted.add(tid)
                    outcomes[tid] = "ABORTED (read_TS rule: TS(T%d)=%d < write_TS=%d)" % (tid, tid, wts)
                    print("OP %d: %s -> ABORT T%d (stale read: %d < write_TS=%d); read_TS=%d write_TS=%d" % (step, label, tid, tid, wts, rts, wts))
                else:
                    read_ts[item] = max(rts, tid)
                    print("OP %d: %s -> GRANTED (read); read_TS=%d write_TS=%d" % (step, label, read_ts[item], wts))
            elif kind == "w":
                if tid < rts:
                    aborted.add(tid)
                    outcomes[tid] = "ABORTED (basic TO write rule: TS(T%d)=%d < read_TS=%d)" % (tid, tid, rts)
                    print("OP %d: %s -> ABORT T%d (late write: %d < read_TS=%d); read_TS=%d write_TS=%d" % (step, label, tid, tid, rts, rts, wts))
                elif tid < wts:
                    outcomes.setdefault(tid, "OBSOLETE_WRITE_IGNORED_BY_THOMAS_RULE")
                    print("OP %d: %s -> IGNORED (Thomas write rule: %d < write_TS=%d); read_TS=%d write_TS=%d" % (step, label, tid, wts, rts, wts))
                else:
                    write_ts[item] = tid
                    print("OP %d: %s -> GRANTED (write); read_TS=%d write_TS=%d" % (step, label, rts, write_ts[item]))
            elif kind == "c":
                outcomes.setdefault(tid, "COMMITTED")
                print("OP %d: %s -> COMMIT RECORDED; read_TS=%d write_TS=%d" % (step, label, rts, wts))
            else:
                outcomes[tid] = "ABORTED (explicit abort)"
                print("OP %d: %s -> ABORT RECORDED; read_TS=%d write_TS=%d" % (step, label, rts, wts))
        for tid in sorted(aborted):
            outcomes[tid] = outcomes.get(tid, "ABORTED")
        print("SKIPPED_OPS_AFTER_ABORT: %s" % (", ".join(skipped) if skipped else "NONE"))
        print("OUTCOMES: %s" % (", ".join("T%d=%s" % (tid, outcomes[tid]) for tid in sorted(outcomes)) if outcomes else "NONE"))
        print("FINAL_ITEM_STATE: %s" % (", ".join("%s(read_TS=%d,write_TS=%d)" % (item, read_ts.get(item, 0), write_ts.get(item, 0)) for item in sorted(set(read_ts) | set(write_ts))) if (read_ts or write_ts) else "NONE"))
        print()


if __name__ == "__main__":
    main()
