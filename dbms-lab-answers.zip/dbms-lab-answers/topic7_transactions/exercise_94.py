import sys
import threading


def start_and_join(targets):
    threads = [threading.Thread(target=target) for target in targets]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()


def lost_update(start, first_delta, second_delta):
    stock = {"X2": start}
    reads = {}
    writes = []
    first_read = threading.Event()
    second_read = threading.Event()
    first_write = threading.Event()

    def worker_one():
        reads[1] = stock["X2"]
        first_read.set()
        second_read.wait()
        stock["X2"] = reads[1] - first_delta
        writes.append((1, stock["X2"]))
        first_write.set()

    def worker_two():
        first_read.wait()
        reads[2] = stock["X2"]
        second_read.set()
        first_write.wait()
        stock["X2"] = reads[2] - second_delta
        writes.append((2, stock["X2"]))

    start_and_join([worker_one, worker_two])
    return reads, writes, stock["X2"]


def locked_update(start, first_delta, second_delta):
    stock = {"X2": start}
    reads = {}
    writes = []
    mutex = threading.Lock()
    second_started = threading.Event()

    def worker_one():
        mutex.acquire()
        reads[1] = stock["X2"]
        stock["X2"] = reads[1] - first_delta
        writes.append((1, stock["X2"]))
        mutex.release()

    def worker_two():
        second_started.set()
        mutex.acquire()
        reads[2] = stock["X2"]
        stock["X2"] = reads[2] - second_delta
        writes.append((2, stock["X2"]))
        mutex.release()

    start_and_join([worker_one, worker_two])
    return reads, writes, stock["X2"]


def dirty_read(protected, start, uncommitted):
    stock = {"X2": start}
    mutex = threading.Lock()
    write_done = threading.Event()
    abort_now = threading.Event()
    reader_done = threading.Event()
    reader_started = threading.Event()
    observed = []

    def writer():
        if protected:
            mutex.acquire()
        stock["X2"] = uncommitted
        write_done.set()
        abort_now.wait()
        stock["X2"] = start
        if protected:
            mutex.release()

    def reader():
        if protected:
            reader_started.set()
            mutex.acquire()
        else:
            write_done.wait()
        observed.append(stock["X2"])
        reader_done.set()
        if protected:
            mutex.release()

    writer_thread = threading.Thread(target=writer)
    reader_thread = threading.Thread(target=reader)
    writer_thread.start()
    write_done.wait()
    reader_thread.start()
    if protected:
        reader_started.wait()
    else:
        reader_done.wait()
    abort_now.set()
    writer_thread.join()
    reader_thread.join()
    return observed[0], stock["X2"]


def mixed_time(protected, stock_a, stock_b, transfer):
    stock = {"A": stock_a, "B": stock_b}
    mutex = threading.Lock()
    b_read = threading.Event()
    transfer_done = threading.Event()
    transfer_started = threading.Event()
    release_now = threading.Event()
    observed = []

    def summary():
        if protected:
            mutex.acquire()
        observed.append(stock["B"])
        b_read.set()
        if protected:
            release_now.wait()
        else:
            transfer_done.wait()
        observed.append(stock["A"])
        if protected:
            mutex.release()

    def transfer_worker():
        b_read.wait()
        transfer_started.set()
        if protected:
            mutex.acquire()
        stock["A"] -= transfer
        stock["B"] += transfer
        if protected:
            transfer_done.set()
        else:
            transfer_done.set()
        if protected:
            mutex.release()

    summary_thread = threading.Thread(target=summary)
    transfer_thread = threading.Thread(target=transfer_worker)
    summary_thread.start()
    transfer_thread.start()
    if protected:
        transfer_started.wait()
        release_now.set()
    summary_thread.join()
    transfer_thread.join()
    return observed, stock


def numbers(tokens, defaults):
    values = list(defaults)
    for index, token in enumerate(tokens[:len(defaults)]):
        try:
            values[index] = int(token)
        except ValueError:
            pass
    return values


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("SCENARIO_COUNT: 0")
        print("THREAD_EVENT_TRACE: NONE")
        print("LOST_UPDATE: NO (no scenario supplied)")
        print("DIRTY_READ: NOT_STAGED")
        print("MIXED_TIME_SUMMARY: NOT_STAGED")
        return
    for index, line in enumerate(lines, 1):
        tokens = line.split()
        scenario = tokens[0].upper() if tokens else ""
        arguments = tokens[1:]
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        if scenario == "LOST_UPDATE":
            start, first, second = numbers(arguments, (22, 5, 4))
            reads, writes, final = lost_update(start, first, second)
            serial = start - first - second
            print("SCENARIO: LOST_UPDATE")
            print("INTERLEAVING: W1_READ, W2_READ, W1_WRITE, W2_WRITE")
            print("WORKER_1: READ %d -> WRITE %d" % (reads[1], writes[0][1]))
            print("WORKER_2: READ %d -> WRITE %d" % (reads[2], writes[1][1]))
            print("FINAL_QTY: %d" % final)
            print("SERIAL_EXPECTED: %d" % serial)
            print("LOST_UPDATE: %s" % ("NO" if final == serial else "YES (%d units overwritten)" % (final - serial)))
        elif scenario == "LOCKED_UPDATE":
            start, first, second = numbers(arguments, (22, 5, 4))
            reads, writes, final = locked_update(start, first, second)
            serial = start - first - second
            print("SCENARIO: LOCKED_UPDATE")
            print("INTERLEAVING: W1_READ, W1_WRITE, W2_READ, W2_WRITE")
            print("WORKER_1: READ %d -> WRITE %d" % (reads[1], writes[0][1]))
            print("WORKER_2: READ %d -> WRITE %d" % (reads[2], writes[1][1]))
            print("FINAL_QTY: %d" % final)
            print("SERIAL_EXPECTED: %d" % serial)
            print("LOST_UPDATE: %s" % ("NO" if final == serial else "YES"))
        elif scenario == "DIRTY_READ":
            start, uncommitted = numbers(arguments, (22, 17))
            observed, final = dirty_read(False, start, uncommitted)
            guarded, guarded_final = dirty_read(True, start, uncommitted)
            print("SCENARIO: DIRTY_READ")
            print("UNPROTECTED: T7 writes %d uncommitted, T8 reads %d, T7 aborts, disk=%d" % (uncommitted, observed, final))
            print("UNPROTECTED_DIRTY_READ: %s" % ("YES" if observed == uncommitted else "NO"))
            print("TXN_PROTECTED: T8 waits for lock until T7 abort, reads %d, disk=%d" % (guarded, guarded_final))
            print("TXN_PROTECTED_DIRTY_READ: %s" % ("NO" if guarded == start else "YES"))
        elif scenario == "MIXED_TIME":
            stock_a, stock_b, transfer = numbers(arguments, (100, 60, 30))
            observed, final = mixed_time(False, stock_a, stock_b, transfer)
            guarded, guarded_final = mixed_time(True, stock_a, stock_b, transfer)
            print("SCENARIO: MIXED_TIME")
            print("UNPROTECTED: BEFORE=%d AFTER=%d SUM=%d EXPECTED=%d" % (observed[0], observed[1], sum(observed), stock_a + stock_b))
            print("UNPROTECTED_MIXED_TIME: %s" % ("YES" if sum(observed) != stock_a + stock_b else "NO"))
            print("TXN_PROTECTED: BEFORE=%d AFTER=%d SUM=%d EXPECTED=%d" % (guarded[0], guarded[1], sum(guarded), stock_a + stock_b))
            print("TXN_PROTECTED_FINAL_STOCK: A=%d B=%d SUM=%d" % (guarded_final["A"], guarded_final["B"], sum(guarded_final.values())))
            print("TXN_PROTECTED_MIXED_TIME: %s" % ("NO" if sum(guarded) == stock_a + stock_b else "YES"))
        else:
            print("SCENARIO: UNKNOWN")
            print("RESULT: no thread events staged; expected LOST_UPDATE, LOCKED_UPDATE, DIRTY_READ or MIXED_TIME")
        print()


if __name__ == "__main__":
    main()
