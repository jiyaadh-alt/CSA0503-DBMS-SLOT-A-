import re
import sys
from collections import defaultdict

TOKEN_RE = re.compile(r"([rwac])(\d+)(?:\(([A-Za-z0-9_]+)\))?", re.IGNORECASE)


def parse_schedule(text):
    operations = []
    unparsed = []
    for token in re.split(r"[\s,]+", text.strip()):
        if not token:
            continue
        match = TOKEN_RE.fullmatch(token)
        if match is None:
            unparsed.append(token)
            continue
        kind = match.group(1).lower()
        tid = int(match.group(2))
        item = match.group(3).upper() if match.group(3) else None
        operations.append((kind, tid, item))
    return operations, unparsed


def build_graph(operations):
    transactions = sorted({tid for _, tid, _ in operations})
    edges = set()
    by_item = defaultdict(list)
    for kind, tid, item in operations:
        if kind not in ("r", "w") or item is None:
            continue
        for other_kind, other_tid, _ in by_item[item]:
            if other_tid != tid and ("w" in (other_kind, kind)):
                edges.add((other_tid, tid))
        by_item[item].append((kind, tid, item))
    adjacency = {tid: sorted({dst for src, dst in edges if src == tid}) for tid in transactions}
    return transactions, edges, adjacency


def topological_order(transactions, adjacency):
    indegree = {tid: 0 for tid in transactions}
    for tid in transactions:
        for dst in adjacency[tid]:
            indegree[dst] += 1
    ready = sorted(tid for tid in transactions if indegree[tid] == 0)
    order = []
    while ready:
        tid = ready.pop(0)
        order.append(tid)
        for dst in adjacency[tid]:
            indegree[dst] -= 1
            if indegree[dst] == 0:
                ready.append(dst)
                ready.sort()
    return order


def find_cycle(transactions, adjacency):
    state = {tid: 0 for tid in transactions}
    stack = []
    found = []

    def visit(tid):
        state[tid] = 1
        stack.append(tid)
        for dst in adjacency[tid]:
            if found:
                break
            if state[dst] == 1:
                start = stack.index(dst)
                found.extend(stack[start:])
                found.append(dst)
                break
            if state[dst] == 0:
                visit(dst)
        stack.pop()
        state[tid] = 2

    for tid in transactions:
        if state[tid] == 0:
            visit(tid)
            if found:
                break
    return found


def format_ops(operations):
    result = []
    for kind, tid, item in operations:
        result.append("c%d" % tid if kind == "c" else "%s%d(%s)" % (kind, tid, item or "?"))
    return ", ".join(result) if result else "NONE"


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("SCHEDULE_COUNT: 0")
        print("PRECEDENCE_GRAPH: EMPTY")
        print("TOPOLOGICAL_ORDER: [] (vacuously serializable)")
        print("CYCLE_WITNESS: NONE")
        return
    for index, line in enumerate(lines, 1):
        operations, unparsed = parse_schedule(line)
        transactions, edges, adjacency = build_graph(operations)
        order = topological_order(transactions, adjacency)
        cycle = [] if order else find_cycle(transactions, adjacency)
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("PARSED_OPS: %s" % format_ops(operations))
        print("UNPARSED: %s" % (", ".join(unparsed) if unparsed else "NONE"))
        print("TRANSACTIONS: %s" % (", ".join("T%d" % t for t in transactions) if transactions else "NONE"))
        edge_list = ["T%d -> T%d" % pair for pair in sorted(edges)]
        print("EDGES: %s" % (", ".join(edge_list) if edge_list else "NONE"))
        adjacency_text = ["T%d: %s" % (tid, ",".join("T%d" % d for d in adjacency[tid]) or "-") for tid in transactions]
        print("ADJACENCY: %s" % (" | ".join(adjacency_text) if adjacency_text else "NONE"))
        if order:
            print("RESULT: CONFLICT_SERIALIZABLE")
            print("TOPOLOGICAL_ORDER: %s" % " -> ".join("T%d" % t for t in order))
            print("CYCLE_WITNESS: NONE")
        else:
            print("RESULT: NOT_CONFLICT_SERIALIZABLE")
            print("TOPOLOGICAL_ORDER: NONE")
            print("CYCLE_WITNESS: %s" % (" -> ".join("T%d" % t for t in cycle) if cycle else "NONE"))
        print()


if __name__ == "__main__":
    main()
