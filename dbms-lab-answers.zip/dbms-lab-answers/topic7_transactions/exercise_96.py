import re
import sys
from collections import defaultdict

TOKEN_RE = re.compile(r"([SXURC])(\d+)(?:\(([A-Za-z0-9_]+)\))?", re.IGNORECASE)


def new_state():
    return {"holders": defaultdict(dict), "queues": defaultdict(list)}


def parse_line(text):
    operations = []
    unparsed = []
    for token in re.split(r"[\s,]+", text.strip()):
        if not token:
            continue
        match = TOKEN_RE.fullmatch(token)
        if match is None:
            unparsed.append(token)
            continue
        operations.append((match.group(1).upper(), int(match.group(2)), match.group(3).upper() if match.group(3) else None))
    return operations, unparsed


def grantable(item, tid, mode, state, position):
    holders = state["holders"][item]
    queue = state["queues"][item]
    earlier = queue[:position]
    if mode == "S":
        if any(request_mode in ("X", "U") for _, request_mode in earlier):
            return False
        return not any(holder_mode == "X" and holder != tid for holder, holder_mode in holders.items())
    if earlier:
        return False
    return all(holder == tid for holder in holders)


def drain(item, state, granted):
    queue = state["queues"][item]
    while queue:
        position = 0
        tid, mode = queue[0]
        if not grantable(item, tid, mode, state, position):
            break
        queue.pop(position)
        state["holders"][item][tid] = "X" if mode in ("X", "U") else "S"
        granted.append("T%d:%s(%s)" % (tid, mode, item))


def request(tid, item, mode, state, granted):
    holders = state["holders"][item]
    queue = state["queues"][item]
    if mode == "U" and holders.get(tid) != "S":
        return "INVALID_UPGRADE"
    if mode == "S" and holders.get(tid) in ("S", "X"):
        return "ALREADY_HELD"
    if mode in ("X", "U") and holders.get(tid) == "X":
        return "ALREADY_HELD"
    queue.append((tid, mode))
    before = len(granted)
    drain(item, state, granted)
    if len(granted) > before:
        return "GRANTED"
    return "WAITING"


def release_all(tid, state, granted):
    affected = []
    for item in set(state["holders"]) | set(state["queues"]):
        if tid in state["holders"][item] or any(entry[0] == tid for entry in state["queues"][item]):
            affected.append(item)
    for item in sorted(affected):
        state["holders"][item].pop(tid, None)
        state["queues"][item] = [entry for entry in state["queues"][item] if entry[0] != tid]
        drain(item, state, granted)
    return sorted(affected)


def wait_for_edges(state):
    edges = set()
    nodes = set()
    for item, queue in state["queues"].items():
        holders = state["holders"][item]
        for tid, mode in holders.items():
            nodes.add(tid)
        for position, (tid, mode) in enumerate(queue):
            nodes.add(tid)
            blockers = set()
            for holder, holder_mode in holders.items():
                nodes.add(holder)
                if holder != tid and (mode in ("X", "U") or holder_mode == "X"):
                    blockers.add(holder)
            for other, other_mode in queue[:position]:
                if other != tid and (mode in ("X", "U") or other_mode in ("X", "U")):
                    blockers.add(other)
            for blocker in blockers:
                edges.add((tid, blocker))
    return nodes, edges


def find_cycle(nodes, edges):
    adjacency = {node: sorted(dst for src, dst in edges if src == node) for node in nodes}
    state = {node: 0 for node in sorted(nodes)}
    stack = []
    result = []

    def visit(node):
        state[node] = 1
        stack.append(node)
        for dst in adjacency[node]:
            if result:
                break
            if state[dst] == 1:
                result.extend(stack[stack.index(dst):])
                result.append(dst)
                break
            if state[dst] == 0:
                visit(dst)
        stack.pop()
        state[node] = 2

    for node in sorted(nodes):
        if state[node] == 0:
            visit(node)
            if result:
                break
    return result


def format_edges(nodes, edges):
    text = ["T%d -> T%d" % pair for pair in sorted(edges)]
    return ", ".join(text) if text else "NONE"


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("REQUEST_COUNT: 0")
        print("WAIT_FOR_GRAPH: EMPTY")
        print("CYCLE: NONE")
        print("VICTIM: NONE")
        print("RESULT: no locks held and no waiters")
        return
    for index, line in enumerate(lines, 1):
        operations, unparsed = parse_line(line)
        state = new_state()
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("UNPARSED: %s" % (", ".join(unparsed) if unparsed else "NONE"))
        for step, (kind, tid, item) in enumerate(operations, 1):
            granted = []
            if kind == "C":
                affected = release_all(tid, state, granted)
                status = "COMMIT_RELEASE %s" % (",".join(affected) if affected else "NONE")
            elif item is None:
                affected = []
                status = "INVALID (no item)"
            elif kind == "R":
                state["holders"][item].pop(tid, None)
                state["queues"][item] = [entry for entry in state["queues"][item] if entry[0] != tid]
                drain(item, state, granted)
                affected = [item]
                status = "RELEASE %s" % item
            else:
                affected = []
                status = request(tid, item, kind, state, granted)
            nodes, edges = wait_for_edges(state)
            cycle = find_cycle(nodes, edges)
            print("OP %d: %s -> %s" % (step, kind + str(tid) + ("(" + item + ")" if item else ""), status))
            print("  WAIT_FOR_GRAPH: %s" % format_edges(nodes, edges))
            print("  NEWLY_GRANTED: %s" % (", ".join(granted) if granted else "NONE"))
            if cycle:
                victim = max(cycle)
                print("  CYCLE: %s" % " -> ".join("T%d" % node for node in cycle))
                freed = release_all(victim, state, granted)
                print("  VICTIM: T%d (youngest in cycle; lower transaction number is older)" % victim)
                print("  VICTIM_RELEASED: %s" % (",".join(freed) if freed else "NONE"))
                print("  NEWLY_GRANTED_AFTER_ABORT: %s" % (", ".join(granted) if granted else "NONE"))
                nodes, edges = wait_for_edges(state)
                print("  WAIT_FOR_GRAPH_AFTER_ABORT: %s" % format_edges(nodes, edges))
                print("  CYCLE_AFTER_ABORT: NONE")
            else:
                print("  CYCLE: NONE")
        print("RESULT: deadlock detection applied after each operation; abort policy is younger-victim")
        print()


if __name__ == "__main__":
    main()
