import re
import sys

BASE_MAP = [210, 211, 212, 213, 214, 215]
PAGES_RE = re.compile(r"PAGES\(([^)]*)\)", re.IGNORECASE)
FREE_RE = re.compile(r"FREE\(([^)]*)\)", re.IGNORECASE)
MAPFREE_RE = re.compile(r"MAPFREE\((\d+)\)", re.IGNORECASE)


def numbers_from(match, count):
    if match is None:
        return None
    values = []
    for part in match.group(1).split(","):
        try:
            values.append(int(part.strip()))
        except ValueError:
            pass
    return values if len(values) == count else None


def format_map(mapping):
    return ", ".join("P%d->%d" % (index + 1, address) for index, address in enumerate(mapping))


def main():
    lines = [line.strip() for line in sys.stdin if line.strip()]
    if not lines:
        print("BOUNDARY EMPTY INPUT")
        print("CASE_COUNT: 0")
        print("BASE_MAP: %s" % format_map(BASE_MAP))
        print("ROOT_POINTER: 210 (unchanged)")
        print("RESULT: no page copy and no root switch performed")
        return
    for index, line in enumerate(lines, 1):
        mode_match = re.search(r"\b(COMMIT|SWITCH|CRASH)\b", line, re.IGNORECASE)
        mode = mode_match.group(1).upper() if mode_match else "UNKNOWN"
        logical = numbers_from(PAGES_RE.search(line), 2) or [1, 4]
        free = numbers_from(FREE_RE.search(line), 2) or [220, 221]
        map_match = MAPFREE_RE.search(line)
        map_page = int(map_match.group(1)) if map_match else 222
        working = list(BASE_MAP)
        for page, address in zip(logical, free):
            working[page - 1] = address
        root_before = 210
        root_after = map_page if mode in ("COMMIT", "SWITCH") else root_before
        print("RUN %d" % index)
        print("INPUT: %s" % line)
        print("BASE_MAP: %s" % format_map(BASE_MAP))
        print("COPIES: %s" % ", ".join("logical %d to free page %d" % (page, address) for page, address in zip(logical, free)))
        print("WORKING_MAP: %s" % format_map(working))
        print("NEW_MAP_PAGE: %d" % map_page)
        print("ROOT_BEFORE: %d" % root_before)
        print("SCENARIO: %s" % ("ATOMIC_ROOT_SWITCH" if mode in ("COMMIT", "SWITCH") else "CRASH_BEFORE_SWITCH" if mode == "CRASH" else "UNKNOWN"))
        if mode in ("COMMIT", "SWITCH"):
            print("ROOT_AFTER: %d" % root_after)
            print("COMMITTED_MAP: %s" % format_map(working))
            print("OLD_SHADOW_MAP: 210 retained for recovery")
            print("ORPHAN_PAGES: NONE")
            print("RESULT: single atomic root write from 210 to %d publishes both copied pages" % root_after)
        elif mode == "CRASH":
            print("ROOT_AFTER: %d (unchanged)" % root_after)
            print("COMMITTED_MAP: %s" % format_map(BASE_MAP))
            print("OLD_SHADOW_MAP: 210 still current")
            print("ORPHAN_PAGES: %s" % ", ".join(str(address) for address in free + [map_page]))
            print("RESULT: copies are unreachable; crash leaves the original six-page map intact")
        else:
            print("ROOT_AFTER: %d (unchanged)" % root_before)
            print("RESULT: expected COMMIT, SWITCH or CRASH")
        print()


if __name__ == "__main__":
    main()
