# CSA05 – Database Management Systems: Lab Exercise Answers

Complete answer set for the 102 exercises in `CSA05-Lab Exercises(CO1-CO5).docx`.

## Layout

| Directory | Exercises | Contents |
|---|---|---|
| `sql/` | baseline | `00_baseline.sql` – hospitality schema, constraints and sample rows |
| `topic1_er/` | 1–14 | ER/EER diagrams (Mermaid), assumptions, relational mappings, examples |
| `topic2_ddl/` | 15–28 | MySQL DDL, constraints, transactions, privileges, triggers, `NOTES.md` |
| `topic3_queries/` | 29–54 | MySQL queries, joins, subqueries, aggregates, views, window functions, `NOTES.md` |
| `topic4_algebra/` | 55–64 | Relational algebra/calculus answers and Python dependency routines, `NOTES.md` |
| `topic5_storage/` | 65–78 | Python storage/hashing/index simulations and MySQL index experiments, `NOTES.md` |
| `topic6_query_processing/` | 79–90 | Cost models, sort/join algorithms, EXPLAIN script, Python DB connectivity, `NOTES.md` |
| `topic7_transactions/` | 91–102 | Scheduling, locking, timestamp ordering, recovery, shadow paging, `NOTES.md` |

## Prerequisites

- MySQL 8.0.16+ (`EXPLAIN FORMAT=TREE` needs 8.0.16+, `INTERSECT`/`EXCEPT` need 8.0.31+).
- Python 3.9+; `mysql-connector-python` only for exercises 87–90.
- All other Python programs use the standard library only.

## Running

Load the baseline before any Topic 2 or Topic 3 script:

```sh
mysql -u root -p < sql/00_baseline.sql
mysql -u root -p < topic3_queries/exercise_29.sql
```

Topic 2 scripts that create their own database (`exercise_15`, `16`, `19`, `24`, `27`) are independent. Scripts using `DELIMITER` must be run through the `mysql` CLI. Reload the baseline between independent update experiments.

Python simulations read from standard input; input formats, sample runs and explanations are in each topic's `NOTES.md`:

```sh
python3 topic5_storage/exercise_65.py <<'EOF'
1000 40 512
EOF
```

Connectivity scripts (87–90) read credentials from `DB_HOST`, `DB_USER`, `DB_PASSWORD` and `DB_NAME`; no password is hard-coded. Exercise 25 uses an explicitly labelled placeholder password.

## Notes

- ER diagrams use Mermaid `erDiagram`; Chen-specific symbols that Mermaid cannot draw are described in each file's legend.
- Index and optimizer results in exercises 77, 78 and 86 are environment-dependent; eligibility and optimizer choice are reported separately.
- Exercises 91–102 read one schedule per line from standard input and print deterministic labelled results.

## Exercise index

| # | File | # | File | # | File |
|---|---|---|---|---|---|
| 1 | `topic1_er/exercise_01.md` | 35 | `topic3_queries/exercise_35.sql` | 69 | `topic5_storage/exercise_69.py` |
| 2 | `topic1_er/exercise_02.md` | 36 | `topic3_queries/exercise_36.sql` | 70 | `topic5_storage/exercise_70.py` |
| 3 | `topic1_er/exercise_03.md` | 37 | `topic3_queries/exercise_37.sql` | 71 | `topic5_storage/exercise_71.py` |
| 4 | `topic1_er/exercise_04.md` | 38 | `topic3_queries/exercise_38.sql` | 72 | `topic5_storage/exercise_72.py` |
| 5 | `topic1_er/exercise_05.md` | 39 | `topic3_queries/exercise_39.sql` | 73 | `topic5_storage/exercise_73.py` |
| 6 | `topic1_er/exercise_06.md` | 40 | `topic3_queries/exercise_40.sql` | 74 | `topic5_storage/exercise_74.py` |
| 7 | `topic1_er/exercise_07.md` | 41 | `topic3_queries/exercise_41.sql` | 75 | `topic5_storage/exercise_75.py` |
| 8 | `topic1_er/exercise_08.md` | 42 | `topic3_queries/exercise_42.sql` | 76 | `topic5_storage/exercise_76.py` |
| 9 | `topic1_er/exercise_09.md` | 43 | `topic3_queries/exercise_43.sql` | 77 | `topic5_storage/exercise_77.sql` |
| 10 | `topic1_er/exercise_10.md` | 44 | `topic3_queries/exercise_44.sql` | 78 | `topic5_storage/exercise_78.sql` |
| 11 | `topic1_er/exercise_11.md` | 45 | `topic3_queries/exercise_45.sql` | 79 | `topic6_query_processing/exercise_79.py` |
| 12 | `topic1_er/exercise_12.md` | 46 | `topic3_queries/exercise_46.sql` | 80 | `topic6_query_processing/exercise_80.py` |
| 13 | `topic1_er/exercise_13.md` | 47 | `topic3_queries/exercise_47.sql` | 81 | `topic6_query_processing/exercise_81.py` |
| 14 | `topic1_er/exercise_14.md` | 48 | `topic3_queries/exercise_48.sql` | 82 | `topic6_query_processing/exercise_82.py` |
| 15 | `topic2_ddl/exercise_15.sql` | 49 | `topic3_queries/exercise_49.sql` | 83 | `topic6_query_processing/exercise_83.py` |
| 16 | `topic2_ddl/exercise_16.sql` | 50 | `topic3_queries/exercise_50.sql` | 84 | `topic6_query_processing/exercise_84.py` |
| 17 | `topic2_ddl/exercise_17.sql` | 51 | `topic3_queries/exercise_51.sql` | 85 | `topic6_query_processing/exercise_85.py` |
| 18 | `topic2_ddl/exercise_18.sql` | 52 | `topic3_queries/exercise_52.sql` | 86 | `topic6_query_processing/exercise_86.sql` |
| 19 | `topic2_ddl/exercise_19.sql` | 53 | `topic3_queries/exercise_53.sql` | 87 | `topic6_query_processing/exercise_87.py` |
| 20 | `topic2_ddl/exercise_20.sql` | 54 | `topic3_queries/exercise_54.sql` | 88 | `topic6_query_processing/exercise_88.py` |
| 21 | `topic2_ddl/exercise_21.sql` | 55 | `topic4_algebra/exercise_55.md` | 89 | `topic6_query_processing/exercise_89.py` |
| 22 | `topic2_ddl/exercise_22.sql` | 56 | `topic4_algebra/exercise_56.md` | 90 | `topic6_query_processing/exercise_90.py` |
| 23 | `topic2_ddl/exercise_23.sql` | 57 | `topic4_algebra/exercise_57.md` | 91 | `topic7_transactions/exercise_91.py` |
| 24 | `topic2_ddl/exercise_24.sql` | 58 | `topic4_algebra/exercise_58.py` | 92 | `topic7_transactions/exercise_92.py` |
| 25 | `topic2_ddl/exercise_25.sql` | 59 | `topic4_algebra/exercise_59.py` | 93 | `topic7_transactions/exercise_93.py` |
| 26 | `topic2_ddl/exercise_26.sql` | 60 | `topic4_algebra/exercise_60.py` | 94 | `topic7_transactions/exercise_94.py` |
| 27 | `topic2_ddl/exercise_27.sql` | 61 | `topic4_algebra/exercise_61.py` | 95 | `topic7_transactions/exercise_95.py` |
| 28 | `topic2_ddl/exercise_28.sql` | 62 | `topic4_algebra/exercise_62.py` | 96 | `topic7_transactions/exercise_96.py` |
| 29 | `topic3_queries/exercise_29.sql` | 63 | `topic4_algebra/exercise_63.py` | 97 | `topic7_transactions/exercise_97.py` |
| 30 | `topic3_queries/exercise_30.sql` | 64 | `topic4_algebra/exercise_64.py` | 98 | `topic7_transactions/exercise_98.sql` |
| 31 | `topic3_queries/exercise_31.sql` | 65 | `topic5_storage/exercise_65.py` | 99 | `topic7_transactions/exercise_99.py` |
| 32 | `topic3_queries/exercise_32.sql` | 66 | `topic5_storage/exercise_66.py` | 100 | `topic7_transactions/exercise_100.py` |
| 33 | `topic3_queries/exercise_33.sql` | 67 | `topic5_storage/exercise_67.py` | 101 | `topic7_transactions/exercise_101.py` |
| 34 | `topic3_queries/exercise_34.sql` | 68 | `topic5_storage/exercise_68.py` | 102 | `topic7_transactions/exercise_102.py` |
