import csv
import os
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


DEFAULT_OUTPUT = "hospitality_counts.csv"
HEADER = ["PackageID", "LinkCount"]
EXPECTED_PACKAGES = 7

LINK_QUERY = (
    "SELECT p.PackageID, COUNT(r.GuestID) AS LinkCount "
    "FROM PACKAGE AS p "
    "LEFT JOIN RESERVATION AS r ON r.PackageID = p.PackageID "
    "GROUP BY p.PackageID, p.Title "
    "ORDER BY p.PackageID"
)


def connection_params():
    return {
        "host": os.environ.get("DB_HOST", "localhost"),
        "user": os.environ.get("DB_USER", "root"),
        "password": os.environ.get("DB_PASSWORD", ""),
        "database": os.environ.get("DB_NAME", "hospitality_s2"),
    }


def fetch_links(cursor):
    cursor.execute(LINK_QUERY)
    rows = []
    while True:
        batch = cursor.fetchmany(4)
        if not batch:
            break
        rows.extend(batch)
    return rows


def write_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(HEADER)
        writer.writerows(rows)


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        header = next(reader, None)
        rows = [row for row in reader if row]
    return header, rows


def main():
    if mysql is None:
        print("mysql-connector-python is not installed; install it to run this exercise")
        return
    supplied = sys.stdin.readline().strip()
    output_path = supplied if supplied else DEFAULT_OUTPUT
    try:
        cnx = mysql.connector.connect(**connection_params())
    except mysql.Error as exc:
        print("cannot connect: {}".format(exc))
        return
    cursor = cnx.cursor()
    try:
        rows = fetch_links(cursor)
        write_csv(output_path, rows)
        header, restored = read_csv(output_path)
        cursor.execute("SELECT COUNT(*) FROM RESERVATION")
        total_in_db = cursor.fetchone()[0]
        total_in_csv = sum(int(row[1]) for row in restored)
        print("wrote {} to {}".format(output_path, HEADER))
        for row in restored:
            print("  {} | {}".format(row[0], row[1]))
        print("package rows = {} (expected {})".format(len(restored), EXPECTED_PACKAGES))
        print("total links = {} in CSV, {} in RESERVATION".format(total_in_csv, total_in_db))
        verified = (header == HEADER and len(restored) == EXPECTED_PACKAGES
                    and total_in_csv == total_in_db)
        print("verification passed = {}".format(verified))
    except (mysql.Error, OSError, ValueError) as exc:
        print("export failed: {}".format(exc))
    finally:
        cursor.close()
        cnx.close()


if __name__ == "__main__":
    main()
