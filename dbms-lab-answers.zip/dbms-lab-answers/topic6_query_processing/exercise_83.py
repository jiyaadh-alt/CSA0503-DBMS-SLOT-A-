import csv
import os
import sys
import tempfile
import zlib
from collections import Counter

try:
    import mysql.connector
except ImportError:
    mysql = None


DEFAULT_MASTER = "HOSPITALITY_MASTER.csv"
DEFAULT_DETAIL = "HOSPITALITY_DETAIL.csv"
PARTITIONS = 8

DEMO_MASTER = [
    ["RecordID", "Region", "Amount"],
    ["R1", "East", "10"],
    ["R2", "South", "20"],
    ["R1", "East", "11"],
    ["R4", "North", "40"],
]
DEMO_DETAIL = [
    ["RecordID", "Note", "Qty"],
    ["R1", "first", "2"],
    ["R3", "orphan", "9"],
    ["R1", "second", "3"],
]


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        try:
            header = [name.strip() for name in next(reader)]
        except StopIteration:
            raise ValueError("empty CSV file: {}".format(path))
        if "RecordID" not in header:
            raise ValueError("missing RecordID column in {}".format(path))
        key_index = header.index("RecordID")
        rows = [tuple(value.strip() for value in row) for row in reader if row]
    return header, key_index, rows


def make_demo_files(tmpdir):
    master_path = os.path.join(tmpdir, "demo_master.csv")
    detail_path = os.path.join(tmpdir, "demo_detail.csv")
    for path, rows in ((master_path, DEMO_MASTER), (detail_path, DEMO_DETAIL)):
        with open(path, "w", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerows(rows)
    return master_path, detail_path


def partition_of(key, count):
    try:
        return int(key) % count
    except ValueError:
        return zlib.crc32(key.encode("utf-8")) % count


def write_partition(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as handle:
        csv.writer(handle).writerows(rows)


def read_partition(path):
    with open(path, newline="", encoding="utf-8") as handle:
        return [tuple(row) for row in csv.reader(handle) if row]


def hash_join(master_rows, master_key, detail_rows, detail_key, count, tmpdir):
    master_parts = [[] for _ in range(count)]
    detail_parts = [[] for _ in range(count)]
    for row in master_rows:
        master_parts[partition_of(row[master_key], count)].append(row)
    for row in detail_rows:
        detail_parts[partition_of(row[detail_key], count)].append(row)
    master_paths = []
    detail_paths = []
    for index in range(count):
        master_path = os.path.join(tmpdir, "master_{}.csv".format(index))
        detail_path = os.path.join(tmpdir, "detail_{}.csv".format(index))
        write_partition(master_path, master_parts[index])
        write_partition(detail_path, detail_parts[index])
        master_paths.append(master_path)
        detail_paths.append(detail_path)
    result = []
    for index in range(count):
        buckets = {}
        for row in read_partition(detail_paths[index]):
            buckets.setdefault(row[detail_key], []).append(row)
        for row in read_partition(master_paths[index]):
            for match in buckets.get(row[master_key], []):
                result.append((row, match))
    return result, [len(part) for part in master_parts], [len(part) for part in detail_parts]


def nested_loop(master_rows, master_key, detail_rows, detail_key):
    result = []
    for row in master_rows:
        for match in detail_rows:
            if row[master_key] == match[detail_key]:
                result.append((row, match))
    return result


def report(master_rows, master_key, detail_rows, detail_key, result, reference,
           m_sizes, d_sizes, count):
    master_keys = {row[master_key] for row in master_rows}
    detail_keys = {row[detail_key] for row in detail_rows}
    unmatched_master = [row for row in master_rows if row[master_key] not in detail_keys]
    unmatched_detail = [row for row in detail_rows if row[detail_key] not in master_keys]
    print("Partitioned hash equijoin on RecordID")
    print("partitions = {}, master rows = {}, detail rows = {}".format(count, len(master_rows), len(detail_rows)))
    print("master partition sizes = {}".format(m_sizes))
    print("detail partition sizes = {}".format(d_sizes))
    print("hash-join output rows = {}".format(len(result)))
    print("nested-loop output rows = {}".format(len(reference)))
    print("full-row multisets equal = {}".format(Counter(result) == Counter(reference)))
    duplicates = {row: n for row, n in Counter(result).items() if n > 1}
    print("joined rows with multiplicity > 1 = {}".format(len(duplicates)))
    print("unmatched master rows = {}: {}".format(len(unmatched_master), unmatched_master))
    print("unmatched detail rows = {}: {}".format(len(unmatched_detail), unmatched_detail))
    for pair in result:
        print("  {} | {}".format(",".join(pair[0]), ",".join(pair[1])))


def main():
    args = [arg for arg in sys.argv[1:] if arg != "--demo"]
    demo = "--demo" in sys.argv[1:]
    tokens = sys.stdin.read().split() if not demo else []
    master_path = tokens[0] if tokens else DEFAULT_MASTER
    detail_path = tokens[1] if len(tokens) > 1 else DEFAULT_DETAIL
    try:
        count = int(tokens[2]) if len(tokens) > 2 else PARTITIONS
        if count < 1:
            raise ValueError("partition count must be positive")
    except ValueError as exc:
        print("invalid partition count: {}".format(exc))
        return
    with tempfile.TemporaryDirectory(prefix="ex83_") as tmpdir:
        try:
            if demo:
                master_path, detail_path = make_demo_files(tmpdir)
            if not os.path.isfile(master_path) or not os.path.isfile(detail_path):
                print("CSV files not found: {} , {}".format(master_path, detail_path))
                print("supply both paths on stdin or run with --demo")
                return
            master_header, master_key, master_rows = read_csv(master_path)
            detail_header, detail_key, detail_rows = read_csv(detail_path)
        except (OSError, ValueError) as exc:
            print("cannot read CSV input: {}".format(exc))
            return
        result, m_sizes, d_sizes = hash_join(master_rows, master_key, detail_rows, detail_key, count, tmpdir)
        reference = nested_loop(master_rows, master_key, detail_rows, detail_key)
        report(master_rows, master_key, detail_rows, detail_key, result, reference,
               m_sizes, d_sizes, count)


if __name__ == "__main__":
    main()
