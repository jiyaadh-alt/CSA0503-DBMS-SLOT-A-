import os
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


SOURCE_STORE = "S1"
TARGET_STORE = "S2"
TRANSFER_QTY = 5
BASE_QTY = {SOURCE_STORE: 20, TARGET_STORE: 5}


def connection_params():
    return {
        "host": os.environ.get("DB_HOST", "localhost"),
        "user": os.environ.get("DB_USER", "root"),
        "password": os.environ.get("DB_PASSWORD", ""),
        "database": os.environ.get("DB_NAME", "hospitality_s2"),
    }


def reset_baseline(cnx, cursor):
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS STOCK ("
        "StoreID VARCHAR(10) NOT NULL PRIMARY KEY, "
        "Qty INT NOT NULL)"
    )
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS STOCK_AUDIT ("
        "AuditID INT AUTO_INCREMENT PRIMARY KEY, "
        "FromStore VARCHAR(10) NOT NULL, "
        "ToStore VARCHAR(10) NOT NULL, "
        "Qty INT NOT NULL, "
        "Outcome VARCHAR(20) NOT NULL)"
    )
    cursor.execute("DELETE FROM STOCK_AUDIT")
    cursor.execute("DELETE FROM STOCK")
    for store, qty in BASE_QTY.items():
        cursor.execute(
            "INSERT INTO STOCK (StoreID, Qty) VALUES (%s, %s)", (store, qty)
        )
    cnx.commit()


def run_transfer(cnx, cursor, inject_failure):
    cursor.execute("START TRANSACTION")
    outcome = "committed"
    try:
        quantities = {}
        for store in sorted((SOURCE_STORE, TARGET_STORE)):
            cursor.execute(
                "SELECT Qty FROM STOCK WHERE StoreID = %s FOR UPDATE", (store,)
            )
            row = cursor.fetchone()
            if row is None:
                raise RuntimeError("store {} is missing".format(store))
            quantities[store] = row[0]
        if quantities[SOURCE_STORE] < TRANSFER_QTY:
            raise RuntimeError("insufficient stock at {}".format(SOURCE_STORE))
        cursor.execute(
            "UPDATE STOCK SET Qty = Qty - %s WHERE StoreID = %s",
            (TRANSFER_QTY, SOURCE_STORE),
        )
        if inject_failure:
            raise RuntimeError("injected exception after debit")
        cursor.execute(
            "UPDATE STOCK SET Qty = Qty + %s WHERE StoreID = %s",
            (TRANSFER_QTY, TARGET_STORE),
        )
        cursor.execute(
            "INSERT INTO STOCK_AUDIT (FromStore, ToStore, Qty, Outcome) "
            "VALUES (%s, %s, %s, %s)",
            (SOURCE_STORE, TARGET_STORE, TRANSFER_QTY, "COMMITTED"),
        )
        cnx.commit()
    except Exception as exc:
        cnx.rollback()
        outcome = "rolled back: {}".format(exc)
    return outcome


def snapshot(cursor):
    cursor.execute(
        "SELECT StoreID, Qty FROM STOCK WHERE StoreID IN (%s, %s) ORDER BY StoreID",
        (SOURCE_STORE, TARGET_STORE),
    )
    stock = cursor.fetchall()
    cursor.execute("SELECT COUNT(*) FROM STOCK_AUDIT")
    audit_rows = cursor.fetchone()[0]
    return stock, audit_rows


def report(label, outcome, stock, audit_rows):
    print("{}: {}".format(label, outcome))
    print("  stock after transaction: {}".format(stock))
    print("  audit rows: {}".format(audit_rows))


def main():
    if mysql is None:
        print("mysql-connector-python is not installed; install it to run this exercise")
        return
    choice = sys.stdin.readline().strip().lower()
    scenarios = {
        "ok": [("success", False)],
        "fail": [("injected failure", True)],
    }.get(choice, [("success", False), ("injected failure", True)])
    try:
        cnx = mysql.connector.connect(**connection_params())
    except mysql.Error as exc:
        print("cannot connect: {}".format(exc))
        return
    cursor = cnx.cursor()
    try:
        for label, inject in scenarios:
            reset_baseline(cnx, cursor)
            outcome = run_transfer(cnx, cursor, inject)
            stock, audit_rows = snapshot(cursor)
            report(label, outcome, stock, audit_rows)
    except mysql.Error as exc:
        cnx.rollback()
        print("database error: {}".format(exc))
    finally:
        cursor.close()
        cnx.close()


if __name__ == "__main__":
    main()
