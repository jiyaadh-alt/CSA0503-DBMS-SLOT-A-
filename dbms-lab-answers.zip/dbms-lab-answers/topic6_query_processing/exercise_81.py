import math
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


DEFAULTS = {"blocks": 10000, "levels": 3, "fraction": 0.10, "matches": 50}


def estimate(blocks, levels, fraction, matches):
    if blocks < 0 or levels < 0 or matches < 0:
        raise ValueError("blocks, levels and matches must be non-negative")
    if not 0.0 <= fraction <= 1.0:
        raise ValueError("range fraction must be between 0 and 1")
    return [
        ("full scan (no usable index)", blocks, "read all b data blocks"),
        ("successful unique-key linear search", math.ceil(blocks / 2) if blocks else 0,
         "average b/2 data blocks for an unordered heap"),
        ("primary-index equality", levels + 1, "h index blocks plus one data block"),
        ("clustered range scan", levels + math.ceil(fraction * blocks),
         "h index blocks plus ceil(f*b) contiguous data blocks"),
        ("unclustered secondary equality", levels + matches,
         "h index blocks plus one data-block read per match"),
    ]


def report(rows, blocks, levels, fraction, matches):
    print("CLAIM_ARCHIVE selection costs in block transfers")
    print("b = {}, h = {}, f = {}, s = {}".format(blocks, levels, fraction, matches))
    for name, cost, formula in rows:
        print("{:<38} {:>8}  {}".format(name, cost, formula))
    best = min(rows, key=lambda row: row[1])
    print("minimum-cost access path = {} ({})".format(best[0], best[1]))


def main():
    tokens = sys.stdin.read().split()
    if not tokens:
        print("empty input: using example catalog values b={}, h={}, f={}, s={}".format(
            DEFAULTS["blocks"], DEFAULTS["levels"], DEFAULTS["fraction"], DEFAULTS["matches"]))
        values = DEFAULTS
    else:
        try:
            values = {
                "blocks": int(tokens[0]),
                "levels": int(tokens[1]) if len(tokens) > 1 else DEFAULTS["levels"],
                "fraction": float(tokens[2]) if len(tokens) > 2 else DEFAULTS["fraction"],
                "matches": int(tokens[3]) if len(tokens) > 3 else DEFAULTS["matches"],
            }
        except ValueError as exc:
            print("invalid input: {}".format(exc))
            print("expected: <b> <h> <f> <s>")
            return
    try:
        rows = estimate(values["blocks"], values["levels"], values["fraction"], values["matches"])
    except ValueError as exc:
        print("invalid input: {}".format(exc))
        return
    report(rows, values["blocks"], values["levels"], values["fraction"], values["matches"])


if __name__ == "__main__":
    main()
