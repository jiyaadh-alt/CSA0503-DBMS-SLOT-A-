import math
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


DEFAULTS = {"masters": 10000, "regions": 10, "details": 30000, "record_ids": 10000}

CAVEAT = (
    "skew limitation: uniform region sizes are assumed; if one region holds a much larger "
    "share of masters, or details per master correlate with region, N_D/V_R is wrong and a "
    "region histogram or most-common-value list is needed"
)


def estimate(masters, regions, details, record_ids):
    if min(masters, regions, details, record_ids) <= 0:
        raise ValueError("catalog counts must be positive")
    if regions > masters:
        raise ValueError("region count cannot exceed master cardinality")
    region_selectivity = 1 / regions
    region_masters = masters / regions
    details_per_master = details / masters
    full_join_general = masters * details / max(record_ids, 1)
    full_join_fk = details
    region_join = details / regions
    return {
        "region_selectivity": region_selectivity,
        "region_masters": region_masters,
        "details_per_master": details_per_master,
        "full_join_general": full_join_general,
        "full_join_fk": full_join_fk,
        "region_join": region_join,
    }


def report(values, result):
    print("Selectivity estimates from the hospitality catalog")
    print("N_M={}, V_region={}, N_D={}, V_RecordID={}".format(
        values["masters"], values["regions"], values["details"], values["record_ids"]))
    print("sel(region = r) = 1/V_region = {:.6f}".format(result["region_selectivity"]))
    print("|sigma_region(MASTER)| = N_M/V_region = {:.2f} rows (about {})".format(
        result["region_masters"], math.ceil(result["region_masters"])))
    print("mean details per master = N_D/N_M = {:.4f}".format(result["details_per_master"]))
    print("equijoin by uniformity = N_M*N_D/max(V_M,V_D) = {:.2f} rows".format(
        result["full_join_general"]))
    print("equijoin with valid detail foreign keys = N_D = {:.0f} rows".format(
        result["full_join_fk"]))
    print("region-filtered join = N_D/V_region = {:.2f} rows (about {})".format(
        result["region_join"], math.ceil(result["region_join"])))
    print("pushing the region filter below the join removes a factor of {}".format(
        values["regions"]))


def main():
    tokens = sys.stdin.read().split()
    if not tokens:
        print("empty input: using example catalog values N_M={}, V_region={}, N_D={}, V_RecordID={}".format(
            DEFAULTS["masters"], DEFAULTS["regions"], DEFAULTS["details"], DEFAULTS["record_ids"]))
        values = dict(DEFAULTS)
    else:
        try:
            values = {
                "masters": int(tokens[0]),
                "regions": int(tokens[1]) if len(tokens) > 1 else DEFAULTS["regions"],
                "details": int(tokens[2]) if len(tokens) > 2 else DEFAULTS["details"],
                "record_ids": int(tokens[3]) if len(tokens) > 3 else DEFAULTS["record_ids"],
            }
        except ValueError as exc:
            print("invalid input: {}".format(exc))
            print("expected: <master rows> <distinct regions> <detail rows> <distinct RecordIDs>")
            return
    try:
        result = estimate(values["masters"], values["regions"], values["details"], values["record_ids"])
    except ValueError as exc:
        print("invalid input: {}".format(exc))
        return
    report(values, result)
    print(CAVEAT)


if __name__ == "__main__":
    main()
