# Topic 6 — Query Processing, Optimization and Database Connectivity (79–90)

All answers live in this directory. The shared baseline is `../sql/00_baseline.sql`; load it
before any SQL exercise that uses `hospitality_s2`. Python 3 is used for 79–85 and 87–90;
83 is stdlib-only CSV processing. Every Python file guards the `mysql-connector-python`
import, so `python3 -m py_compile exercise_*.py` succeeds without the driver installed.
No code comments are used; explanations are here instead.

Connectivity programs read `DB_HOST`, `DB_USER`, `DB_PASSWORD` and `DB_NAME` from the
environment. Defaults are `localhost`, `root`, an empty password and `hospitality_s2`.
No password is hard-coded. Example:

```
export DB_HOST=localhost DB_USER=root DB_PASSWORD='your-secret' DB_NAME=hospitality_s2
```

## 79 — External merge-sort I/O (`exercise_79.py`)

```
printf '1024 8\n' | python3 exercise_79.py
```

Input: two whitespace-separated values, `<file blocks b> <memory blocks M>`; extra tokens
are ignored, a missing `M` defaults to 8, and empty input reports the zero-block boundary
case (`0` runs, `0` passes, `0` transfers, `0` seeks). `M` must be at least 3 so the fan-in
`M-1` is at least 2; blocks must be non-negative.

Initial runs are `ceil(b/M)`. Merge passes are found by repeatedly replacing the run
count `n` with `ceil(n/(M-1))` until one run remains. Run generation transfers `2b`
blocks; every merge pass reads and writes all `b` blocks, so transfers are
`2b(1 + passes)`. Seeks follow the wording of the exercise: one seek per initial run
read and one per initial run write (`2 * runs`), plus one seek per block read and write
during merges (`2b * passes`). For `b=1024, M=8`: 128 runs, widths `128 -> 19 -> 3 -> 1`,
3 passes, 8192 transfers and 6400 seeks.

## 80 — External sort with temp files (`exercise_80.py`)

```
printf 'E007,2026-01-15T11:00:00\nE002,2026-01-15T09:30:00\nE002,2026-01-15T09:30:00\n' | python3 exercise_80.py
python3 exercise_80.py --demo
```

Input: CSV lines with at least two columns, `EventID,EventTime[,extra columns...]`, one
event per line; no header is expected. ISO timestamps are normalized with
`datetime.fromisoformat`, other strings are kept as-is; the sort key is
`(EventTime, EventID)`. Initial runs hold 2000 records and are written as JSON lines into
a temporary directory. Each merge pass combines 11 run files with a streaming
`heapq.merge`, so memory use stays bounded and duplicate keys are never discarded. The
final file is read back and compared with an in-memory `sorted` on the full fixture,
including duplicates and extra columns. The report gives run count, pass count, record
reads/writes for the temp files and the equality result. Empty input gives zero runs,
zero passes, two empty results and `matches in-memory sorted result = True`. `--demo`
uses a built-in fixture with duplicate keys.

## 81 — Selection cost formulas (`exercise_81.py`)

```
printf '10000 3 0.10 50\n' | python3 exercise_81.py
```

Input: `<b> <h> <f> <s>` = data blocks, index blocks traversed (root through leaf),
range fraction, and matching records for the unclustered equality. Missing values fall
back to `10000, 3, 0.10, 50`; empty input uses the same example and says so.

Costs in block transfers: full scan `b`; successful unique-key linear search on an
unordered file `ceil(b/2)` on average (worst case `b`); primary-index equality `h + 1`;
clustered range `h + ceil(f*b)` because the qualifying data blocks are contiguous;
unclustered secondary equality `h + s` because each match can sit in a different data
block. Seeks are omitted because the course uses block transfers as the measure. The
program prints the minimum-cost path for the supplied catalog values.

## 82 — Join algorithm cost comparison (`exercise_82.py`)

```
printf '1000 50000 500 100 4 sorted\n' | python3 exercise_82.py
printf '1000 50000 500 100 none\n' | python3 exercise_82.py
```

Input: `<br> <nr> <bs> <M> <c|none> [sorted]`, where `br`/`nr` are outer Y2 blocks and
records, `bs` is inner Z2 blocks, `M` is memory blocks, `c` is the indexed lookup cost
per outer record (`none` means no inner index), and `sorted` marks both inputs as already
sorted on the join key. Empty input uses the example values and prints a notice.

Costs: tuple nested-loop `br + nr*bs`; block nested-loop `br + ceil(br/(M-2))*bs`
(eligible only for `M >= 3`); indexed nested-loop `br + nr*c` (eligible only with an
index); presorted merge `br + bs` (eligible only when inputs are sorted); Grace hash
`3*(br+bs)` with feasible partitions assumed. Output writes are ignored as required.
In the example, merge join wins when sorted (1500); otherwise Grace hash (4500) beats
block nested-loop (6500) and indexed nested-loop (201000). Ties are broken by name.

## 83 — Partitioned hash equijoin (`exercise_83.py`)

```
printf 'HOSPITALITY_MASTER.csv HOSPITALITY_DETAIL.csv 8\n' | python3 exercise_83.py
python3 exercise_83.py --demo
```

Input: one to three whitespace-separated tokens: master CSV path, detail CSV path and
partition count (default 8). With empty input the two default filenames are looked up in
the current directory; missing files produce a clear message instead of a traceback.
Both CSVs need a `RecordID` header; all other columns are carried through unchanged.

Rows are hashed to partitions with `int(RecordID) mod p` (CRC32 fallback for non-numeric
IDs), written to temp CSVs in insertion order, then each detail partition is loaded into
a hash table of lists and probed by the master partition. Keeping a list per key preserves
duplicate matches. A full nested-loop join over the same rows is used as the reference;
the program compares `collections.Counter` multisets of full joined rows, prints
multiplicity-greater-than-one rows, and lists master rows with no detail match and detail
rows with no master match separately. `--demo` generates temp CSVs where `R1` occurs twice
in each input, producing four joined rows.

## 84 — Selectivity estimation (`exercise_84.py`)

```
printf '10000 10 30000 10000\n' | python3 exercise_84.py
```

Input: `<master rows N_M> <distinct regions V_R> <detail rows N_D> <distinct RecordIDs>`.
Empty input uses `10000, 10, 30000, 10000` with a notice.

Uniform regions give `sel(region=r) = 1/V_R` and `N_M/V_R` master rows. The general
uniform equijoin estimate is `N_M*N_D/max(V_M,V_D)`; with valid detail foreign keys every
detail matches exactly one master, so the full join is `N_D`. Region size is assumed
independent of detail count, so pushing the region filter below the join gives `N_D/V_R`
rows, a reduction by a factor of `V_R`. Skew caveat printed by the program: if one region
holds a much larger share of masters, or detail counts correlate with region, this
estimate is wrong; a region histogram or most-common-value list is required.

## 85 — Query trees and join order (`exercise_85.py`)

```
python3 exercise_85.py
printf '10 7 20 4 7 5 3\n' | python3 exercise_85.py
```

No input is required; empty input uses counts verified from `../sql/00_baseline.sql`.
Optional overrides are `<guests> <packages> <reservations> <NightUnits=4 packages>
<ReviewScore>=83 reservations> <qualified joins> <distinct names>`.

The canonical tree applies one selection above a Cartesian product of GUEST, PACKAGE and
RESERVATION (`10*7*20 = 1400` tuples). The optimized tree pushes `NightUnits = 4` onto
PACKAGE (7 -> 4 rows), `ReviewScore >= 83` onto RESERVATION (20 -> 7 rows), projects away
all columns except the two join keys plus the score, joins on `PackageID` first (5 rows),
then joins on `GuestID` and finally projects `GuestName`. Keeping the naive join order
(GUEST with RESERVATION first) materializes 20 rows before filtering, and the Cartesian
form is far worse. The two filtered inputs are the smallest relations, so they start the
join. Baseline answer names: Abeer, Bina, Hina.

## 86 — EXPLAIN before and after indexes (`exercise_86.sql`)

```
mysql -u root -p < ../sql/00_baseline.sql
mysql -u root -p < exercise_86.sql
```

The file runs the Exercise 85 query twice with `EXPLAIN FORMAT=TREE` and twice with
`EXPLAIN ANALYZE`: first on the untouched baseline, then after
`RESERVATION(PackageID, ReviewScore)` and `PACKAGE(NightUnits)` are created. `EXPLAIN
ANALYZE` executes the query, so it reports real rows, loops and timing.

Honest comparison narrative: the baseline holds only 7 packages and 20 reservations.
For tables this small the optimizer commonly chooses full table scans (or a hash join)
both before and after the indexes, because reading a few leaf pages costs less than an
index lookup plus a table lookup. The two new indexes are *eligible* for the predicates,
but eligibility does not force the optimizer to use them. It is therefore entirely
plausible that estimated rows, actual rows, loops and join order are identical in the two
EXPLAIN outputs, with only the `possible_keys` line changing. Do not claim a speed-up
unless the captured `EXPLAIN ANALYZE` timing actually shows one. Paste the four real
outputs into your lab record: estimated vs actual rows per node, loops per node, join
order and execution time. If the plan is unchanged, state that plainly and explain that
the cost model preferred a scan on a tiny relation; the indexes would matter on a large
CLAIM_ARCHIVE-style table. Reload the baseline before repeating the "before" run, since
the script creates the indexes permanently.

## 87 — HOSPITALITY_REQUEST CRUD menu (`exercise_87.py`)

```
python3 exercise_87.py
```

Menu: 1 create, 2 list, 3 find, 4 update, 5 advance status, 6 delete, 7 exit. All values
are bound with `%s` placeholders; description and status are never interpolated into SQL.
Blank descriptions are rejected. Reads, updates and deletes report `RequestID n not found`
when `rowcount` is zero, and every write is committed after success (rolled back on a
database error). Input exhaustion exits cleanly and the cursor and connection are closed
in `finally`. The lifecycle is `NEW -> IN_PROGRESS -> RESOLVED -> CLOSED`; option 5 moves
one step and refuses to move a CLOSED request. The table is created with
`CREATE TABLE IF NOT EXISTS` if it is absent.

## 88 — Unsafe concatenation vs bound parameters (`exercise_88.py`)

```
python3 exercise_88.py
printf "LAB' OR '1'='1\n" | python3 exercise_88.py
```

The program creates a disposable `hospitality_catalog` database with three harmless
`CATALOG_ITEM` rows, compares a deliberately unsafe concatenated SELECT with a
parameterized SELECT, and drops the database at the end. The first test name is
`O'Reilly`: the concatenated form raises a syntax error while the bound form returns one
row. The second test uses the harmless lab payload `LAB' OR '1'='1`: the concatenated
form changes the WHERE clause and returns all rows, while the bound form returns zero rows
because the whole string is one literal name. Row counts are printed for both forms. The
unsafe SELECT exists only as the lab contrast; use placeholders in real code. Seed inserts
are parameterized. An optional stdin line overrides the payload; empty input keeps the
default.

## 89 — Two-store transfer with ordered locking (`exercise_89.py`)

```
python3 exercise_89.py
printf 'ok\n' | python3 exercise_89.py
printf 'fail\n' | python3 exercise_89.py
```

The program creates `STOCK` and `STOCK_AUDIT`, resets both stores (`S1=20`, `S2=5`), and
transfers 5 units from `S1` to `S2` inside one transaction. Both rows are locked with
`SELECT ... FOR UPDATE` in ascending StoreID order to avoid deadlocks. Insufficient stock
aborts the transfer; a successful transfer writes a `COMMITTED` audit row. With empty
input (or `both`) it runs two scenarios from the same baseline: a normal commit, then a
run where an exception is injected after the debit. The injected run rolls back, so its
stock stays `S1=20, S2=5` and it leaves zero audit rows, while the committed run ends at
`S1=15, S2=10` with one audit row. `ok` and `fail` select a single scenario.

## 90 — Package link count export (`exercise_90.py`)

```
python3 exercise_90.py
printf 'my_counts.csv\n' | python3 exercise_90.py
```

The query uses `PACKAGE LEFT JOIN RESERVATION` with `COUNT(r.GuestID)`, so packages with
no links are still exported with a zero. Rows are fetched with `fetchmany(4)` until empty
and written to `hospitality_counts.csv` (or the optional stdin path) with a
`PackageID,LinkCount` header. The file is read back and verified against 7 package rows
and the database's own `COUNT(*) FROM RESERVATION` (20 on the baseline), with total link
counts recomputed from the CSV. Writes to the CSV are the only file output.

## Verification and caveats

```
python3 -m py_compile exercise_79.py exercise_80.py exercise_81.py exercise_82.py exercise_83.py exercise_84.py exercise_85.py exercise_87.py exercise_88.py exercise_89.py exercise_90.py
```

`py_compile` needs no MySQL driver and no database. Running 87–90 needs a live MySQL
server and the driver; their database changes are local to the configured schema except
for 88, which drops its own disposable database. 85 expects the exact baseline counts;
custom counts can be supplied for sensitivity analysis. 83 needs the two lab CSV files
with a `RecordID` column, or `--demo`. 90 writes a CSV into the current directory.
