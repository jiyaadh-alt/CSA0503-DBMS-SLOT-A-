import os
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


LIFECYCLE = ("NEW", "IN_PROGRESS", "RESOLVED", "CLOSED")


def connection_params():
    return {
        "host": os.environ.get("DB_HOST", "localhost"),
        "user": os.environ.get("DB_USER", "root"),
        "password": os.environ.get("DB_PASSWORD", ""),
        "database": os.environ.get("DB_NAME", "hospitality_s2"),
    }


def prompt(message):
    sys.stdout.write(message)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        return None
    return line.strip()


def ensure_table(cursor):
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS HOSPITALITY_REQUEST ("
        "RequestID INT AUTO_INCREMENT PRIMARY KEY, "
        "Description VARCHAR(255) NOT NULL, "
        "Status VARCHAR(30) NOT NULL)"
    )


def create_request(cnx, cursor):
    description = prompt("Description: ")
    if description is None:
        return False
    if not description:
        print("rejected: description cannot be blank")
        return True
    status = prompt("Status [NEW]: ")
    if status is None:
        return False
    if not status:
        status = "NEW"
    cursor.execute(
        "INSERT INTO HOSPITALITY_REQUEST (Description, Status) VALUES (%s, %s)",
        (description, status),
    )
    cnx.commit()
    print("created RequestID = {}".format(cursor.lastrowid))
    return True


def list_requests(cursor):
    cursor.execute(
        "SELECT RequestID, Description, Status FROM HOSPITALITY_REQUEST ORDER BY RequestID"
    )
    rows = cursor.fetchall()
    if not rows:
        print("no requests stored")
    for row in rows:
        print("{} | {} | {}".format(row[0], row[1], row[2]))


def find_request(cursor):
    raw_id = prompt("RequestID: ")
    if raw_id is None:
        return False
    try:
        request_id = int(raw_id)
    except ValueError:
        print("invalid id")
        return True
    cursor.execute(
        "SELECT RequestID, Description, Status FROM HOSPITALITY_REQUEST WHERE RequestID = %s",
        (request_id,),
    )
    row = cursor.fetchone()
    if row is None:
        print("RequestID {} not found".format(request_id))
    else:
        print("{} | {} | {}".format(row[0], row[1], row[2]))
    return True


def update_request(cnx, cursor):
    raw_id = prompt("RequestID: ")
    if raw_id is None:
        return False
    try:
        request_id = int(raw_id)
    except ValueError:
        print("invalid id")
        return True
    cursor.execute(
        "SELECT Description, Status FROM HOSPITALITY_REQUEST WHERE RequestID = %s",
        (request_id,),
    )
    row = cursor.fetchone()
    if row is None:
        print("RequestID {} not found".format(request_id))
        return True
    description = prompt("New description (blank keeps '{}'): ".format(row[0]))
    if description is None:
        return False
    status = prompt("New status (blank keeps '{}'): ".format(row[1]))
    if status is None:
        return False
    new_description = row[0] if not description else description
    new_status = row[1] if not status else status
    cursor.execute(
        "UPDATE HOSPITALITY_REQUEST SET Description = %s, Status = %s WHERE RequestID = %s",
        (new_description, new_status, request_id),
    )
    if cursor.rowcount == 0:
        print("RequestID {} not found".format(request_id))
    else:
        cnx.commit()
        print("updated {} row(s)".format(cursor.rowcount))
    return True


def advance_request(cnx, cursor):
    raw_id = prompt("RequestID: ")
    if raw_id is None:
        return False
    try:
        request_id = int(raw_id)
    except ValueError:
        print("invalid id")
        return True
    cursor.execute(
        "SELECT Status FROM HOSPITALITY_REQUEST WHERE RequestID = %s", (request_id,)
    )
    row = cursor.fetchone()
    if row is None:
        print("RequestID {} not found".format(request_id))
        return True
    if row[0] not in LIFECYCLE:
        print("unknown current status: {}".format(row[0]))
        return True
    position = LIFECYCLE.index(row[0])
    if position == len(LIFECYCLE) - 1:
        print("RequestID {} is already CLOSED".format(request_id))
        return True
    next_status = LIFECYCLE[position + 1]
    cursor.execute(
        "UPDATE HOSPITALITY_REQUEST SET Status = %s WHERE RequestID = %s",
        (next_status, request_id),
    )
    cnx.commit()
    print("RequestID {} moved {} -> {}".format(request_id, row[0], next_status))
    return True


def delete_request(cnx, cursor):
    raw_id = prompt("RequestID: ")
    if raw_id is None:
        return False
    try:
        request_id = int(raw_id)
    except ValueError:
        print("invalid id")
        return True
    cursor.execute(
        "DELETE FROM HOSPITALITY_REQUEST WHERE RequestID = %s", (request_id,)
    )
    if cursor.rowcount == 0:
        print("RequestID {} not found".format(request_id))
    else:
        cnx.commit()
        print("deleted {} row(s)".format(cursor.rowcount))
    return True


def main():
    if mysql is None:
        print("mysql-connector-python is not installed; install it to run this exercise")
        return
    try:
        cnx = mysql.connector.connect(**connection_params())
    except mysql.Error as exc:
        print("cannot connect: {}".format(exc))
        return
    cursor = cnx.cursor()
    try:
        ensure_table(cursor)
        cnx.commit()
        actions = {
            "1": create_request,
            "2": lambda c, k: (list_requests(k), True)[1],
            "3": find_request,
            "4": update_request,
            "5": advance_request,
            "6": delete_request,
        }
        while True:
            print("1 create  2 list  3 find  4 update  5 advance status  6 delete  7 exit")
            choice = prompt("choice: ")
            if choice is None:
                print("input closed; exiting")
                break
            if choice in ("7", "q", "Q", "exit"):
                break
            if choice in actions:
                try:
                    keep_going = actions[choice](cnx, cursor)
                except mysql.Error as exc:
                    cnx.rollback()
                    print("database error: {}".format(exc))
                    keep_going = True
                if not keep_going:
                    print("input closed; exiting")
                    break
            else:
                print("unknown choice")
    finally:
        cursor.close()
        cnx.close()


if __name__ == "__main__":
    main()
