import math
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


def estimate(blocks, memory):
    if blocks < 0:
        raise ValueError("block count must be non-negative")
    if memory < 3:
        raise ValueError("memory must be at least 3 blocks (fan-in M-1 must be >= 2)")
    fan_in = memory - 1
    runs = math.ceil(blocks / memory) if blocks else 0
    widths = [runs] if runs else []
    current = runs
    passes = 0
    while current > 1:
        current = math.ceil(current / fan_in)
        widths.append(current)
        passes += 1
    initial_transfers = 2 * blocks
    merge_transfers = 2 * blocks * passes
    initial_seeks = 2 * runs
    merge_seeks = 2 * blocks * passes
    return {
        "blocks": blocks,
        "memory": memory,
        "fan_in": fan_in,
        "runs": runs,
        "widths": widths,
        "passes": passes,
        "initial_transfers": initial_transfers,
        "merge_transfers": merge_transfers,
        "transfers": initial_transfers + merge_transfers,
        "initial_seeks": initial_seeks,
        "merge_seeks": merge_seeks,
        "seeks": initial_seeks + merge_seeks,
    }


def report(result):
    print("External merge sort estimate")
    print("file blocks b = {}".format(result["blocks"]))
    print("memory blocks M = {} (merge fan-in {})".format(result["memory"], result["fan_in"]))
    print("initial runs = {}".format(result["runs"]))
    if result["widths"]:
        print("run widths by pass: {}".format(" -> ".join(str(w) for w in result["widths"])))
    else:
        print("run widths by pass: none (empty file)")
    print("merge passes = {}".format(result["passes"]))
    print("block transfers = {} = {} (run generation) + {} (merges)".format(
        result["transfers"], result["initial_transfers"], result["merge_transfers"]))
    print("seeks = {} = {} (one per initial run read and write) + {} (one per block in merges)".format(
        result["seeks"], result["initial_seeks"], result["merge_seeks"]))


def main():
    tokens = sys.stdin.read().split()
    if not tokens:
        report(estimate(0, 8))
        print("empty input: zero-block boundary case, no runs, no passes, zero I/O")
        return
    try:
        blocks = int(tokens[0])
        memory = int(tokens[1]) if len(tokens) > 1 else 8
        result = estimate(blocks, memory)
    except (ValueError, TypeError) as exc:
        print("invalid input: {}".format(exc))
        print("expected: <file blocks> <memory blocks M>")
        return
    report(result)


if __name__ == "__main__":
    main()
