import math
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


DEFAULTS = {"br": 1000, "nr": 50000, "bs": 500, "memory": 100, "c": 4, "sorted": False}


def estimate(br, nr, bs, memory, index_cost, sorted_inputs):
    if min(br, nr, bs) < 0 or memory < 0:
        raise ValueError("relation sizes and memory must be non-negative")
    methods = []
    methods.append(("tuple nested-loop", br + nr * bs, True, "br + nr*bs"))
    block_ok = memory >= 3
    block_cost = br + math.ceil(br / (memory - 2)) * bs if block_ok else None
    methods.append(("block nested-loop", block_cost, block_ok, "br + ceil(br/(M-2))*bs"))
    indexed_ok = index_cost is not None and index_cost >= 0
    indexed_cost = br + nr * index_cost if indexed_ok else None
    methods.append(("indexed nested-loop", indexed_cost, indexed_ok, "br + nr*c"))
    methods.append(("presorted merge", br + bs if sorted_inputs else None, sorted_inputs, "br + bs"))
    methods.append(("Grace hash", 3 * (br + bs), True, "3*(br+bs)"))
    return methods


def report(methods, values):
    print("Y2 (outer) join Z2 cost comparison in block transfers")
    print("br={}, nr={}, bs={}, M={}, c={}, inputs sorted={}".format(
        values["br"], values["nr"], values["bs"], values["memory"],
        values["c"], values["sorted"]))
    for name, cost, eligible, formula in methods:
        shown = "ineligible" if not eligible else str(cost)
        print("{:<22} {:>12}  {}".format(name, shown, formula))
    eligible = [(name, cost) for name, cost, ok, _ in methods if ok]
    eligible.sort(key=lambda item: (item[1], item[0]))
    if eligible:
        print("recommended minimum-cost eligible method = {} ({})".format(
            eligible[0][0], eligible[0][1]))
        print("eligible ranking: {}".format(", ".join(
            "{}:{}".format(name, cost) for name, cost in eligible)))
    else:
        print("no eligible method with the supplied resources")


def parse_index_cost(token):
    if token.lower() in ("none", "no", "na", "-", "-1"):
        return None
    return int(token)


def main():
    tokens = sys.stdin.read().split()
    if not tokens:
        print("empty input: using example sizes br={}, nr={}, bs={}, M={}, c={}, sorted={}".format(
            DEFAULTS["br"], DEFAULTS["nr"], DEFAULTS["bs"], DEFAULTS["memory"],
            DEFAULTS["c"], DEFAULTS["sorted"]))
        values = dict(DEFAULTS)
    else:
        try:
            values = {
                "br": int(tokens[0]),
                "nr": int(tokens[1]) if len(tokens) > 1 else DEFAULTS["nr"],
                "bs": int(tokens[2]) if len(tokens) > 2 else DEFAULTS["bs"],
                "memory": int(tokens[3]) if len(tokens) > 3 else DEFAULTS["memory"],
                "c": parse_index_cost(tokens[4]) if len(tokens) > 4 else DEFAULTS["c"],
                "sorted": (len(tokens) > 5 and tokens[5].lower() in ("sorted", "yes", "1", "true"))
                or (len(tokens) <= 5 and DEFAULTS["sorted"]),
            }
        except ValueError as exc:
            print("invalid input: {}".format(exc))
            print("expected: <br> <nr> <bs> <M> <c|none> [sorted]")
            return
    try:
        methods = estimate(values["br"], values["nr"], values["bs"], values["memory"],
                           values["c"], values["sorted"])
    except (ValueError, ZeroDivisionError) as exc:
        print("invalid input: {}".format(exc))
        return
    report(methods, values)


if __name__ == "__main__":
    main()
