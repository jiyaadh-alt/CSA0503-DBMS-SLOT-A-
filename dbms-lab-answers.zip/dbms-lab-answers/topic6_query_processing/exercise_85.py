import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


BASELINE = {
    "guest": 10,
    "package": 7,
    "reservation": 20,
    "package_night4": 4,
    "reservation_score83": 7,
    "joined_qualified": 5,
    "distinct_names": 3,
}

CANONICAL_TREE = """  pi GuestName
    sigma P.NightUnits=4 AND R.ReviewScore>=83
      Cartesian product
        GUEST ({guest})   PACKAGE ({package})   RESERVATION ({reservation})"""

OPTIMIZED_TREE = """  pi GuestName
    join on GuestID
      pi GuestID,GuestName
        GUEST ({guest}) -> {guest}
      join on PackageID
        pi PackageID
          sigma NightUnits=4
            PACKAGE ({package}) -> {package_night4}
        pi GuestID,PackageID,ReviewScore
          sigma ReviewScore>=83
            RESERVATION ({reservation}) -> {reservation_score83}"""


def build(values):
    cross = values["guest"] * values["package"] * values["reservation"]
    naive_guest_res = values["reservation"]
    naive_all = values["reservation"]
    return {
        "cross": cross,
        "naive_guest_res": naive_guest_res,
        "naive_all": naive_all,
        "first_join": min(values["package_night4"], values["reservation_score83"]),
        "qualified": values["joined_qualified"],
    }


def report(values, costs):
    print("Exercise 85: canonical and optimized query trees")
    print("canonical Cartesian-package tree:")
    print(CANONICAL_TREE.format(**values))
    print("optimized tree with pushed filters and projections:")
    print(OPTIMIZED_TREE.format(**values))
    print("intermediate cardinalities from the baseline catalog")
    print("  canonical cross product = {} * {} * {} = {} tuples".format(
        values["guest"], values["package"], values["reservation"], costs["cross"]))
    print("  GUEST join RESERVATION = {} rows (every reservation has a valid guest key)".format(
        costs["naive_guest_res"]))
    print("  then join PACKAGE = {} rows, filter last = {} rows".format(
        costs["naive_all"], costs["qualified"]))
    print("  sigma(RESERVATION) = {} rows; sigma(PACKAGE) = {} rows".format(
        values["reservation_score83"], values["package_night4"]))
    print("  joining the two filtered inputs first yields {} qualifying rows".format(
        costs["qualified"]))
    print("  joining the result to GUEST keeps {} rows and projects {} distinct names".format(
        costs["qualified"], values["distinct_names"]))
    print("join-order justification")
    print("  the two filtered inputs are the smallest ({} and {} rows versus {} guests),".format(
        values["reservation_score83"], values["package_night4"], values["guest"]))
    print("  so joining them first minimizes the largest intermediate relation;")
    print("  GuestID and PackageID are retained as join keys, and all other columns are")
    print("  projected away before the joins; the final projection removes duplicates.")
    print("expected baseline names: Abeer, Bina, Hina")


def main():
    tokens = sys.stdin.read().split()
    if not tokens:
        values = dict(BASELINE)
        print("empty input: using verified counts from sql/00_baseline.sql")
    else:
        try:
            keys = ["guest", "package", "reservation", "package_night4",
                    "reservation_score83", "joined_qualified", "distinct_names"]
            values = {key: int(token) for key, token in zip(keys, tokens)}
            for key in keys:
                values.setdefault(key, BASELINE[key])
        except ValueError as exc:
            print("invalid input: {}".format(exc))
            print("expected: <guests> <packages> <reservations> <night4 packages> "
                  "<score83 reservations> <qualified joins> <distinct names>")
            return
    if min(values.values()) < 0:
        print("invalid input: counts must be non-negative")
        return
    report(values, build(values))


if __name__ == "__main__":
    main()
