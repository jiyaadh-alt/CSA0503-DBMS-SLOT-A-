import csv
import heapq
import json
import os
import sys
import tempfile
from datetime import datetime

try:
    import mysql.connector
except ImportError:
    mysql = None


RUN_SIZE = 2000
FAN_IN = 11

DEMO_ROWS = [
    ["E007", "2026-01-15T11:00:00"],
    ["E002", "2026-01-15T09:30:00"],
    ["E004", "2026-01-15T10:15:00"],
    ["E002", "2026-01-15T09:30:00"],
    ["E001", "2026-01-14T08:00:00"],
    ["E003", "2026-01-15T09:30:00"],
    ["E005", "2026-01-15T10:15:00"],
    ["E006", "2026-01-15T10:15:00", "duplicate extra field"],
]


def make_record(fields):
    raw_time = fields[1].strip()
    try:
        event_time = datetime.fromisoformat(raw_time).isoformat()
    except ValueError:
        event_time = raw_time
    return {"event_id": fields[0].strip(), "event_time": event_time, "fields": fields}


def sort_key(record):
    return (record["event_time"], record["event_id"])


def read_rows(demo):
    if demo:
        return [make_record(row) for row in DEMO_ROWS]
    records = []
    for fields in csv.reader(sys.stdin):
        if not fields or not any(field.strip() for field in fields):
            continue
        if len(fields) < 2:
            print("skipping row with fewer than two columns: {}".format(fields))
            continue
        records.append(make_record(fields))
    return records


def write_run(path, records, stats):
    with open(path, "w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record) + "\n")
            stats["writes"] += 1


def iter_run(path, stats):
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                stats["reads"] += 1
                yield json.loads(line)


def build_runs(records, tmpdir, stats):
    paths = []
    chunk = []
    for record in records:
        chunk.append(record)
        if len(chunk) == RUN_SIZE:
            path = os.path.join(tmpdir, "run_{:04d}.jsonl".format(len(paths)))
            write_run(path, sorted(chunk, key=sort_key), stats)
            paths.append(path)
            chunk = []
    if chunk:
        path = os.path.join(tmpdir, "run_{:04d}.jsonl".format(len(paths)))
        write_run(path, sorted(chunk, key=sort_key), stats)
        paths.append(path)
    return paths


def merge_all(paths, tmpdir, stats):
    level = 0
    while len(paths) > 1:
        next_paths = []
        for offset in range(0, len(paths), FAN_IN):
            group = paths[offset:offset + FAN_IN]
            merged_path = os.path.join(tmpdir, "merge_{:04d}_{:04d}.jsonl".format(level, offset // FAN_IN))
            streams = [iter_run(path, stats) for path in group]
            with open(merged_path, "w", encoding="utf-8") as handle:
                for record in heapq.merge(*streams, key=sort_key):
                    handle.write(json.dumps(record) + "\n")
                    stats["writes"] += 1
            next_paths.append(merged_path)
        paths = next_paths
        level += 1
    return paths[0] if paths else None


def report(records, paths, passes, stats):
    external = []
    if paths:
        final_stats = {"reads": 0, "writes": 0}
        external = list(iter_run(paths[0], final_stats))
        stats["reads"] += final_stats["reads"]
    expected = sorted(records, key=sort_key)
    print("External sort by (EventTime, EventID)")
    print("records = {} (duplicate keys retained)".format(len(records)))
    run_count = (len(records) + RUN_SIZE - 1) // RUN_SIZE if records else 0
    print("initial runs = {} (run size {})".format(run_count, RUN_SIZE))
    print("merge fan-in = {}, merge passes = {}".format(FAN_IN, passes))
    print("temp-file record writes = {}, reads = {}".format(stats["writes"], stats["reads"]))
    print("matches in-memory sorted result = {}".format(external == expected))
    if external:
        print("first keys:")
        for record in external[:min(5, len(external))]:
            print("  ({}, {})".format(record["event_time"], record["event_id"]))
    else:
        print("empty input: zero runs, zero passes, both results empty and equal")


def main():
    demo = "--demo" in sys.argv[1:]
    records = read_rows(demo)
    stats = {"reads": 0, "writes": 0}
    with tempfile.TemporaryDirectory(prefix="ex80_") as tmpdir:
        paths = build_runs(records, tmpdir, stats)
        passes = 0
        current = len(paths)
        while current > 1:
            current = (current + FAN_IN - 1) // FAN_IN
            passes += 1
        final_path = merge_all(paths, tmpdir, stats)
        report(records, [final_path] if final_path else [], passes, stats)


if __name__ == "__main__":
    main()
