import os
import sys

try:
    import mysql.connector
except ImportError:
    mysql = None


CATALOG_DATABASE = "hospitality_catalog"
LAB_PAYLOAD = "LAB' OR '1'='1"
SEED_ROWS = [
    (1, "Notebook"),
    (2, "O'Reilly Guide"),
    (3, "Laptop Stand"),
]


def connection_params():
    return {
        "host": os.environ.get("DB_HOST", "localhost"),
        "user": os.environ.get("DB_USER", "root"),
        "password": os.environ.get("DB_PASSWORD", ""),
        "database": os.environ.get("DB_NAME", "hospitality_s2"),
    }


def unsafe_lookup(cursor, value):
    statement = "SELECT ItemID, ItemName FROM CATALOG_ITEM WHERE ItemName = '" + value + "'"
    cursor.execute(statement)
    return cursor.fetchall()


def safe_lookup(cursor, value):
    cursor.execute(
        "SELECT ItemID, ItemName FROM CATALOG_ITEM WHERE ItemName = %s", (value,)
    )
    return cursor.fetchall()


def show(label, value, unsafe_rows, safe_rows):
    print("{}: input={!r}".format(label, value))
    print("  unsafe concatenated lookup returned {} row(s)".format(len(unsafe_rows)))
    for row in unsafe_rows:
        print("    {}".format(row))
    print("  parameterized lookup returned {} row(s)".format(len(safe_rows)))
    for row in safe_rows:
        print("    {}".format(row))


def main():
    if mysql is None:
        print("mysql-connector-python is not installed; install it to run this exercise")
        return
    supplied = sys.stdin.readline().strip()
    payload = supplied if supplied else LAB_PAYLOAD
    params = connection_params()
    params.pop("database", None)
    try:
        cnx = mysql.connector.connect(**params)
    except mysql.Error as exc:
        print("cannot connect: {}".format(exc))
        return
    cursor = cnx.cursor()
    try:
        cursor.execute("DROP DATABASE IF EXISTS " + CATALOG_DATABASE)
        cursor.execute("CREATE DATABASE " + CATALOG_DATABASE)
        cursor.execute("USE " + CATALOG_DATABASE)
        cursor.execute(
            "CREATE TABLE CATALOG_ITEM ("
            "ItemID INT NOT NULL PRIMARY KEY, "
            "ItemName VARCHAR(100) NOT NULL)"
        )
        for item_id, name in SEED_ROWS:
            cursor.execute(
                "INSERT INTO CATALOG_ITEM (ItemID, ItemName) VALUES (%s, %s)",
                (item_id, name),
            )
        cnx.commit()
        for label, value in (("ordinary quote", "O'Reilly"), ("harmless lab OR payload", payload)):
            try:
                unsafe_rows = unsafe_lookup(cursor, value)
            except mysql.Error as exc:
                print("{}: unsafe lookup raised a database error: {}".format(label, exc))
                unsafe_rows = []
            safe_rows = safe_lookup(cursor, value)
            show(label, value, unsafe_rows, safe_rows)
        print("bound parameters keep the entire input as literal data; the quote and the")
        print("OR text are compared as one name, so no unintended rows are returned")
    except mysql.Error as exc:
        cnx.rollback()
        print("database error: {}".format(exc))
    finally:
        try:
            cursor.execute("DROP DATABASE IF EXISTS " + CATALOG_DATABASE)
        except mysql.Error as exc:
            print("cleanup warning: {}".format(exc))
        cursor.close()
        cnx.close()


if __name__ == "__main__":
    main()
