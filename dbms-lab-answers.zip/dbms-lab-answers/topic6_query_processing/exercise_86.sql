USE hospitality_s2;

EXPLAIN FORMAT=TREE
SELECT g.GuestName
FROM GUEST AS g
JOIN RESERVATION AS r ON r.GuestID = g.GuestID
JOIN PACKAGE AS p ON p.PackageID = r.PackageID
WHERE p.NightUnits = 4
  AND r.ReviewScore >= 83;

EXPLAIN ANALYZE
SELECT g.GuestName
FROM GUEST AS g
JOIN RESERVATION AS r ON r.GuestID = g.GuestID
JOIN PACKAGE AS p ON p.PackageID = r.PackageID
WHERE p.NightUnits = 4
  AND r.ReviewScore >= 83;

CREATE INDEX idx_res_pkg_score ON RESERVATION (PackageID, ReviewScore);
CREATE INDEX idx_pkg_nightunits ON PACKAGE (NightUnits);

EXPLAIN FORMAT=TREE
SELECT g.GuestName
FROM GUEST AS g
JOIN RESERVATION AS r ON r.GuestID = g.GuestID
JOIN PACKAGE AS p ON p.PackageID = r.PackageID
WHERE p.NightUnits = 4
  AND r.ReviewScore >= 83;

EXPLAIN ANALYZE
SELECT g.GuestName
FROM GUEST AS g
JOIN RESERVATION AS r ON r.GuestID = g.GuestID
JOIN PACKAGE AS p ON p.PackageID = r.PackageID
WHERE p.NightUnits = 4
  AND r.ReviewScore >= 83;
